package com.loopconnect.engine

import kotlin.math.max

const val START_HINTS = 3
const val MAX_HINTS = 9
const val LEVELS_PER_HINT = 3
const val WEEK_STREAK_HINTS = 2
const val AD_HINTS = 1

object Scoring {
    fun stars(moves: Int, par: Int): Int = when {
        moves <= par -> 3
        moves <= par + max(2, par / 2) -> 2
        else -> 1
    }
}

data class LevelResult(val stars: Int, val bestMoves: Int)

data class Progress(
    val results: Map<Int, LevelResult> = emptyMap(),
    val totalMoves: Long = 0,
    val totalSolved: Int = 0,
    val dailyDays: Set<Long> = emptySet(),
    val lastDailyDay: Long = -1,
    val dailyStreak: Int = 0,
    val recentSignatures: List<Long> = emptyList(),
    val hints: Int = START_HINTS,
    val unlockedIds: Set<String> = emptySet()
) {
    val levelsCompleted: Int get() = results.size

    /** Levels unlock one after another; unlimited. */
    val highestUnlocked: Int
        get() {
            var n = 0
            while (results.containsKey(n + 1)) n++
            return n + 1
        }

    val perfectLevels: Int get() = results.values.count { it.stars == 3 }

    fun isUnlocked(level: Int) = level in 1..highestUnlocked
    fun isCompleted(level: Int) = results.containsKey(level)

    /** Streak that is still alive on [today]. */
    fun streakOn(today: Long): Int = if (lastDailyDay >= today - 1) dailyStreak else 0

    fun withMoves(count: Int) = copy(totalMoves = totalMoves + count)

    fun withHints(delta: Int) = copy(hints = (hints + delta).coerceIn(0, MAX_HINTS))

    fun spendHint() = if (hints > 0) copy(hints = hints - 1) else this

    private fun grant(gain: Int) = if (hints >= MAX_HINTS) hints else minOf(MAX_HINTS, hints + gain)

    /** Hints are earned by progress: one per 3 newly completed levels, one for a first 3-star result. */
    fun withLevelCompleted(level: Int, moves: Int, stars: Int): Progress {
        val old = results[level]
        val merged = if (old == null) LevelResult(stars, moves)
        else LevelResult(max(old.stars, stars), minOf(old.bestMoves, moves))
        var gain = 0
        if (old == null && (results.size + 1) % LEVELS_PER_HINT == 0) gain += 1
        if (stars == 3 && (old == null || old.stars < 3)) gain += 1
        return copy(results = results + (level to merged), totalSolved = totalSolved + 1, hints = grant(gain))
    }

    fun withDailyCompleted(day: Long): Progress {
        if (day in dailyDays) return copy(totalSolved = totalSolved + 1)
        val streak = if (lastDailyDay == day - 1) dailyStreak + 1 else 1
        val newStreak = if (day >= lastDailyDay) streak else dailyStreak
        val gain = if (day >= lastDailyDay && newStreak % 7 == 0) WEEK_STREAK_HINTS else 0
        return copy(
            dailyDays = dailyDays + day,
            lastDailyDay = max(lastDailyDay, day),
            dailyStreak = newStreak,
            totalSolved = totalSolved + 1,
            hints = grant(gain)
        )
    }

    /** Marks achievements as permanently unlocked and pays their hint rewards. */
    fun withUnlocked(newly: List<Achievement>): Progress =
        if (newly.isEmpty()) this
        else copy(unlockedIds = unlockedIds + newly.map { it.id }, hints = grant(newly.sumOf { it.reward }))

    fun withSignature(sig: Long, keep: Int = 40) =
        copy(recentSignatures = (recentSignatures.filter { it != sig } + sig).takeLast(keep))
}

enum class Tier(val reward: Int) { BRONZE(1), SILVER(2), GOLD(3) }

enum class AchievementCategory(val title: String) {
    PROGRESS("Progress"), SKILL("Skill"), DAILY("Daily"), DEDICATION("Dedication")
}

/** [icon] is a plain key so the engine stays free of Android types; the UI maps it to a vector. */
data class Achievement(
    val id: String, val title: String, val description: String,
    val category: AchievementCategory, val tier: Tier, val goal: Int, val icon: String,
    val value: (Progress) -> Int
) {
    val reward: Int get() = tier.reward
    fun current(p: Progress): Int = value(p).coerceIn(0, goal)
    /** Once unlocked it stays unlocked, even if a streak later resets. */
    fun unlocked(p: Progress): Boolean = id in p.unlockedIds || value(p) >= goal
}

object Achievements {
    private val P = AchievementCategory.PROGRESS
    private val S = AchievementCategory.SKILL
    private val D = AchievementCategory.DAILY
    private val X = AchievementCategory.DEDICATION

    val all = listOf(
        Achievement("first_win", "First Loop", "Complete your first level", P, Tier.BRONZE, 1, "flag") { it.levelsCompleted },
        Achievement("first", "First Steps", "Complete 5 levels", P, Tier.BRONZE, 5, "flag") { it.levelsCompleted },
        Achievement("master", "Solution Master", "Complete 25 levels", P, Tier.SILVER, 25, "grid") { it.levelsCompleted },
        Achievement("loop", "Loop Expert", "Complete 50 levels", P, Tier.GOLD, 50, "trophy") { it.levelsCompleted },
        Achievement("centurion", "Centurion", "Complete 100 levels", P, Tier.GOLD, 100, "crown") { it.levelsCompleted },
        Achievement("eye", "Sharp Eye", "Earn 3 stars on 5 levels", S, Tier.BRONZE, 5, "star") { it.perfectLevels },
        Achievement("perfect", "Perfectionist", "Earn 3 stars on 10 levels", S, Tier.SILVER, 10, "star") { it.perfectLevels },
        Achievement("flawless", "Flawless", "Earn 3 stars on 25 levels", S, Tier.GOLD, 25, "bolt") { it.perfectLevels },
        Achievement("collector", "Star Collector", "Collect 50 stars", S, Tier.SILVER, 50, "star") { p -> p.results.values.sumOf { it.stars } },
        Achievement("daily", "Daily Player", "Complete 7 daily puzzles", D, Tier.BRONZE, 7, "calendar") { it.dailyDays.size },
        Achievement("daily30", "Daily Devotee", "Complete 30 daily puzzles", D, Tier.GOLD, 30, "calendar") { it.dailyDays.size },
        Achievement("streak3", "On Fire", "Reach a 3-day daily streak", D, Tier.BRONZE, 3, "fire") { it.dailyStreak },
        Achievement("streak7", "Unstoppable", "Reach a 7-day daily streak", D, Tier.SILVER, 7, "fire") { it.dailyStreak },
        Achievement("moves", "Tapper", "Make 1,000 moves", X, Tier.BRONZE, 1000, "touch") { it.totalMoves.coerceAtMost(Int.MAX_VALUE.toLong()).toInt() },
        Achievement("moves5k", "Marathon", "Make 5,000 moves", X, Tier.SILVER, 5000, "touch") { it.totalMoves.coerceAtMost(Int.MAX_VALUE.toLong()).toInt() },
        Achievement("addict", "Puzzle Addict", "Solve 100 puzzles", X, Tier.GOLD, 100, "bolt") { it.totalSolved }
    )

    /** Reached the goal but not yet recorded as unlocked, i.e. the player should be told now. */
    fun newlyUnlocked(p: Progress): List<Achievement> = all.filter { it.value(p) >= it.goal && it.id !in p.unlockedIds }

    fun unlockedCount(p: Progress): Int = all.count { it.unlocked(p) }
}
