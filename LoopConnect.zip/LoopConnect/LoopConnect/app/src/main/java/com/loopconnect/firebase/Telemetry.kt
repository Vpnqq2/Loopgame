package com.loopconnect.firebase

import android.content.Context
import android.os.Bundle
import com.google.firebase.FirebaseApp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.crashlytics.FirebaseCrashlytics

/**
 * Analytics + Crashlytics behind one switch. Collection is OFF by default (see manifest) and only turns on
 * when BOTH the player's setting and the consent flow allow it. If `google-services.json` is missing the
 * Firebase SDKs are not initialised and every call here is a harmless no-op, so the game still builds and runs.
 */
class Telemetry(private val app: Context) {
    private val available: Boolean = runCatching { FirebaseApp.getApps(app).isNotEmpty() }.getOrDefault(false)
    private var userAllowed = true
    private var consentOk = false
    private val enabled: Boolean get() = available && userAllowed && consentOk

    fun setUserAllowed(allowed: Boolean) { userAllowed = allowed; apply() }
    fun setConsent(allowed: Boolean) { consentOk = allowed; apply() }

    private fun apply() {
        if (!available) return
        runCatching {
            FirebaseAnalytics.getInstance(app).setAnalyticsCollectionEnabled(enabled)
            FirebaseCrashlytics.getInstance().setCrashlyticsCollectionEnabled(enabled)
        }
    }

    private fun log(name: String, vararg params: Pair<String, Any?>) {
        if (!enabled) return
        runCatching {
            val b = Bundle()
            for ((k, v) in params) when (v) {
                is String -> b.putString(k, v)
                is Int -> b.putLong(k, v.toLong())
                is Long -> b.putLong(k, v)
                is Boolean -> b.putLong(k, if (v) 1L else 0L)
                is Double -> b.putDouble(k, v)
            }
            FirebaseAnalytics.getInstance(app).logEvent(name, b)
        }
    }

    // ---- screens ----
    fun screen(route: String?) {
        if (route == null) return
        log(FirebaseAnalytics.Event.SCREEN_VIEW, FirebaseAnalytics.Param.SCREEN_NAME to route, FirebaseAnalytics.Param.SCREEN_CLASS to "MainActivity")
    }

    // ---- gameplay ----
    fun levelStart(level: Int, objective: String, width: Int, height: Int, daily: Boolean, resumed: Boolean) {
        setKey("level", level)
        breadcrumb("level_start $level daily=$daily resumed=$resumed")
        log("level_start", "level" to level, "objective" to objective, "grid" to "${width}x$height", "daily" to daily, "resumed" to resumed)
    }

    fun levelComplete(level: Int, moves: Int, par: Int, stars: Int, hintUsed: Boolean, daily: Boolean) {
        breadcrumb("level_complete $level moves=$moves")
        log("level_complete", "level" to level, "moves" to moves, "par" to par, "stars" to stars, "hint_used" to hintUsed, "daily" to daily)
    }

    fun hintUsed(level: Int, hintsLeft: Int) = log("hint_used", "level" to level, "hints_left" to hintsLeft)
    fun rewardedHintEarned() = log("rewarded_hint_earned")
    fun interstitialShown() = log("interstitial_shown")
    fun achievement(id: String, tier: String) =
        log(FirebaseAnalytics.Event.UNLOCK_ACHIEVEMENT, FirebaseAnalytics.Param.ACHIEVEMENT_ID to id, "tier" to tier)
    fun tutorialBegin() = log(FirebaseAnalytics.Event.TUTORIAL_BEGIN)
    fun tutorialComplete() = log(FirebaseAnalytics.Event.TUTORIAL_COMPLETE)

    // ---- crashes ----
    fun setKey(key: String, value: Int) {
        if (enabled) runCatching { FirebaseCrashlytics.getInstance().setCustomKey(key, value) }
    }

    fun breadcrumb(message: String) {
        if (enabled) runCatching { FirebaseCrashlytics.getInstance().log(message) }
    }

    /** Non-fatal errors (e.g. a level that failed to load). Fatal crashes are captured automatically. */
    fun recordError(t: Throwable) {
        if (enabled) runCatching { FirebaseCrashlytics.getInstance().recordException(t) }
    }
}
