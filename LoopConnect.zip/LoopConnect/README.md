# Loop Connect

An original, fully offline Android puzzle game in the Infinity Loop genre. Rotate tiles, connect every line,
close every loop. Native Kotlin + Jetpack Compose, MVVM, Canvas-drawn board, DataStore persistence.

## Build and run
1. Open this folder in **Android Studio Koala (2024.1) or newer**. Let Gradle sync (it downloads Gradle 8.9 and the Android SDK 34 platform).
2. Press **Run** on a device or emulator (Android 8.0+), or from a terminal:
   ```
   ./gradlew assembleDebug        # app/build/outputs/apk/debug/app-debug.apk
   ./gradlew assembleRelease      # installable APK, signed with the debug key
   ./gradlew test                 # engine unit tests (pure JVM)
   ```
   If `gradlew` is missing the wrapper jar, run `gradle wrapper --gradle-version 8.9` once, or just use Android Studio.

## Structure
- `engine/` pure Kotlin, no Android imports: `Tile`, `Rules`, `LevelGenerator`, `Solver`, `PuzzleBoard`, `SaveCodec`, `Progress`.
- `data/Repository.kt` DataStore persistence (save game, progress, settings). Errors fall back to defaults.
- `audio/SoundFx.kt` synthesised tick, chime and ambient music (no asset files).
- `ui/` theme, shared components, `GameViewModel`, and `screens/` (Home, LevelSelect, Game, Daily, Stats, Settings).

## Procedural generation
1. Grow a random connected network with controlled branching (`maxDegree`, `branchingPm`, `fillPm` from the level number).
2. LOOPS levels: add edges until no tile has a loose end.
3. Check the solved board against `Rules.isSolved`, then scramble each tile by 0-3 rotations (never already solved).
4. Verify with the independent backtracking `Solver`; reject if proven unsolvable.
5. Everything derives from `LevelSpec.seed` (splitmix64 + `kotlin.random.Random`), so a saved spec rebuilds the exact level.
6. `create(base, avoid)` retries derived seeds to avoid recently used layout signatures. Level N works for any N; nothing is authored by hand.
7. Daily puzzle: seed comes from the calendar day only, so everyone gets the same board.

Saved state per game: spec (number, size, objective, parameters, effective seed), current tile masks, move history, daily flag.

## Hints and rewarded ads (AdMob)
- Hints are a limited balance (start 3, cap 9). Earned: 1 per 3 newly completed levels, +1 for a first 3-star result, +2 for a 7-day daily streak, +1 per rewarded ad. Using a hint caps the level at 2 stars.
- `ads/AdManager.kt` shows a rewarded ad only when the player taps **Watch ad**. Consent is requested through Google UMP in `MainActivity`.
- The AdMob ids live in `app/src/main/res/values/strings.xml` (`admob_app_id`, `admob_interstitial_id`, `admob_rewarded_id`) and currently hold Google's **test** ids. Before publishing, replace all three with your own, complete the Play Console ads declaration and Data safety form, and never tap your own live ads.

## Splash and tutorial
- System splash via `androidx.core:core-splashscreen` (no white flash), then an animated in-app splash (`Splash.kt`) where the logo draws itself. Tap to skip.
- `HowTo.kt`: five animated pages. The demos reuse the real piece renderer, so colours and glow match the game. Shown automatically on first launch and from the Home dock ("How to play").

## Awards
Separate **Stats** and **Awards** pages. 16 awards in four categories and three tiers (bronze +1, silver +2, gold +3 hints). Unlocks are stored permanently, detected after each solved puzzle, and celebrated with an animated popup (`ui/AchievementUi.kt`) shown over any screen. Tapping an earned award replays its popup.

## Ad limits (`engine/AdPolicy.kt`, all constants)
- Rewarded hint ads: max 3 per day, 5 min cooldown, only on request when out of hints.
- Interstitials: none for the first 8 completed levels, then at most one every 4 levels, max 4 per day, min 3 min gap (also after a rewarded ad), only when tapping "Next Level" and only if already loaded. Never on app start, back, or during a level.
- Counters survive "Reset progress" so limits cannot be bypassed. Replace the test ad ids in `app/build.gradle.kts` before publishing.

## Firebase (Analytics, Crashlytics, Cloud Messaging)
1. Create a Firebase project, add an Android app with package `com.loopconnect.game`, download **`google-services.json`** into `app/`. Without this file the project still builds and every Firebase call is a no-op.
2. In the console enable Crashlytics and Analytics. Send notifications to the topics **`daily_puzzle`** and **`news`** (Messaging > New campaign > topic). Optional data key `channel=daily` selects the daily channel.
3. Privacy: all collection is off by default (manifest). Analytics/Crashlytics turn on only if the player's "Share usage & crash data" switch is on AND the UMP consent flow allows it. Push token creation (`auto_init`) is off until the player enables notifications (soft prompt after 3 levels, or Settings); turning it off deletes the token.
4. Events: `screen_view`, `level_start`, `level_complete`, `hint_used`, `rewarded_hint_earned`, `interstitial_shown`, `unlock_achievement`, `tutorial_begin/complete`. Non-fatal errors are recorded for level load failures. No personal data is sent.

## Level-up map
After a Classic or Challenge level the result card's "Next Level" opens `ui/screens/LevelMapTransition.kt`: the same winding level map, where the cleared node turns blue and its stars pop in, a spark travels along the connector while the camera pans, and the next node's padlock shakes, opens and the node flips to the gold PLAY state with a burst (haptic + chime). On a replay (next level already open) only the travel plays; with Animation off the final state shows at once. Once the animation ends, tap the gold PLAY node to start (system Back returns to the result card). `GameUiState.unlockedNext` tells it whether the clear opened the next level. The interstitial ad slot moved from the result card to this Play press.

## Game modes
- **Classic**: campaign levels with stars, plus the daily puzzle. From level 6 the campaign teaches new rules one at a time (see "Classic rules" below).
- **Zen**: endless relaxed puzzles in three board sizes. No timer, move limit or stars. Saved and resumable.
- **Challenge** (unlocks after 3 Classic levels): same difficulty curve with a move limit (`ModeRules.moveLimit`). Fail at the limit, retry. Own level map, unlocks in order, +1 hint every 5th level. Saved and resumable.
- **Rush** (unlocks after 5 Classic levels): 90 s clock, +8 s per solved puzzle, difficulty ramps quickly, no hints, best score tracked. The clock only runs while the player can play (pausing, backgrounding and puzzle transitions stop it). Runs are not saved; quitting abandons the run.
All numbers live in `engine/GameMode.kt` (`ModeRules`). Interstitial ads and star/ad counters apply to Classic only.

## Classic rules (`engine/Twist.kt`, `engine/Shapes.kt`)
Classic levels use rules that change how a board must be planned, not just its size. `Twist.forLevel` decides which rules a level uses (stored as a bit mask in `LevelSpec.rules`, saved as `v5`; older saves load as plain boards). Every rule debuts alone on its intro level, then returns on a beat so later levels mix them. Challenge, Spark, Rush, Zen and Daily never use them.

| Rule | Debut | Beat | What it does |
| --- | --- | --- | --- |
| Padlocked pieces | level 6 | every 3rd level | Some pieces start in place and never turn (they shake when tapped). 1 at first, up to 8, growing with the level. |
| Long winding route | level 10 | every 5th level (not loop levels) | Branch-free boards before level 30 (few branches after), so the board is one long path. |
| Odd board shapes | level 11 | every 5th level | Wall cells (cut corners, ring, L, octagon, waist) that lines cannot enter. Shape comes from the seed. |
| Twin pieces | level 14 | every 4th level | Pairs with the same coloured link badge turn together on one tap. More pairs (up to 4) as levels progress. |

- Solvability: locked pieces start in their solved orientation; twins are scrambled with one shared tap count; `LevelGenerator.verifyPlay` replays the level with the real board rules and `Solver` respects padlocks. If a rule combination ever fails 400 times, `create` falls back to the plain board.
- Par counts a twin pair once; hints never point at a padlocked piece and give the shared tap count for twins.
- First-time instructions: `GameViewModel.tip` -> `TwistTipDialog` (`ui/screens/BoardMarks.kt`). Read rules are stored in `Progress.seenTwists` (cleared by Reset). A one-line reminder under the board names the newest rule of the level. The tutorial has three extra playable pages.
