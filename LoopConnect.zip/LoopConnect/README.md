# Loop Connect

An original, fully offline Android puzzle game in the Infinity Loop genre. Rotate tiles, connect every line,
close every loop. Native Kotlin + Jetpack Compose, MVVM, Canvas-drawn board, DataStore persistence.

## Build and run
1. Open this folder in **Android Studio Koala (2024.1) or newer**. Let Gradle sync (it downloads Gradle 8.9 and the Android SDK 34 platform).
2. Press **Run** on a device or emulator (Android 8.0+), or from a terminal:
   ```
   ./gradlew assembleDebug        # app/build/outputs/apk/debug/app-debug.apk
   ./gradlew assembleRelease      # installable APK, signed with the debug key
   ./gradlew test                 # engine unit tests (pure JVM)
   ```
   If `gradlew` is missing the wrapper jar, run `gradle wrapper --gradle-version 8.9` once, or just use Android Studio.

## Structure
- `engine/` pure Kotlin, no Android imports: `Tile`, `Rules`, `LevelGenerator`, `Solver`, `PuzzleBoard`, `SaveCodec`, `Progress`.
- `data/Repository.kt` DataStore persistence (save game, progress, settings). Errors fall back to defaults.
- `audio/SoundFx.kt` synthesised tick, chime and ambient music (no asset files).
- `ui/` theme, shared components, `GameViewModel`, and `screens/` (Home, LevelSelect, Game, Daily, Stats, Settings).

## Procedural generation
1. Grow a random connected network with controlled branching (`maxDegree`, `branchingPm`, `fillPm` from the level number).
2. LOOPS levels: add edges until no tile has a loose end.
3. Check the solved board against `Rules.isSolved`, then scramble each tile by 0-3 rotations (never already solved).
4. Verify with the independent backtracking `Solver`; reject if proven unsolvable.
5. Everything derives from `LevelSpec.seed` (splitmix64 + `kotlin.random.Random`), so a saved spec rebuilds the exact level.
6. `create(base, avoid)` retries derived seeds to avoid recently used layout signatures. Level N works for any N; nothing is authored by hand.
7. Daily puzzle: seed comes from the calendar day only, so everyone gets the same board.

Saved state per game: spec (number, size, objective, parameters, effective seed), current tile masks, move history, daily flag.
