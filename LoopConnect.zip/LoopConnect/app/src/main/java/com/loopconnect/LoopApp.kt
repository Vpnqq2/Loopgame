package com.loopconnect

import android.app.Application
import com.loopconnect.firebase.Push
import com.loopconnect.firebase.Telemetry

class LoopApp : Application() {
    lateinit var telemetry: Telemetry
        private set

    override fun onCreate() {
        super.onCreate()
        telemetry = Telemetry(this)
        Push.createChannels(this)
    }
}
