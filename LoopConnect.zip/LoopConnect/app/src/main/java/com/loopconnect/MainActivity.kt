package com.loopconnect

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import com.loopconnect.ui.screens.HowToScreen
import com.loopconnect.ui.screens.SplashScreen
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.compose.runtime.CompositionLocalProvider
import com.loopconnect.data.AnimationMode
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import com.loopconnect.ads.AdManager
import com.loopconnect.ui.GameViewModel
import com.loopconnect.ui.LocalAnimations
import com.loopconnect.ui.LoopTheme
import com.loopconnect.ui.ScreenBackground
import com.loopconnect.ui.screens.DailyScreen
import com.loopconnect.ui.screens.GameScreen
import com.loopconnect.ui.screens.HomeScreen
import com.loopconnect.ui.screens.LevelSelectScreen
import com.loopconnect.ui.screens.SettingsScreen
import com.loopconnect.ui.screens.StatsScreen

class MainActivity : ComponentActivity() {
    private val vm: GameViewModel by viewModels()
    private val ads by lazy { AdManager(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setupAds()
        setContent {
            val settings by vm.settings.collectAsStateWithLifecycle()
            LoopTheme(settings.theme) {
                CompositionLocalProvider(LocalAnimations provides (settings.animation != AnimationMode.OFF)) {
                    ScreenBackground { AppNav(vm, ads) }
                }
            }
        }
    }

    /** Ask for consent where required (UMP), then start the ads SDK. The game never depends on it. */
    private fun setupAds() {
        val info = UserMessagingPlatform.getConsentInformation(this)
        info.requestConsentInfoUpdate(
            this, ConsentRequestParameters.Builder().build(),
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(this) { _ ->
                    if (info.canRequestAds()) ads.start()
                }
            },
            { _ -> if (info.canRequestAds()) ads.start() }
        )
        if (info.canRequestAds()) ads.start()
    }

    override fun onStart() {
        super.onStart()
        vm.sound.setForeground(true)
    }

    override fun onStop() {
        super.onStop()
        vm.sound.setForeground(false)
        vm.flush()
    }
}

@Composable
private fun AppNav(vm: GameViewModel, ads: AdManager) {
    val nav = rememberNavController()
    fun go(route: String) = nav.navigate(route) { launchSingleTop = true }

    val scope = rememberCoroutineScope()

    NavHost(nav, startDestination = "splash") {
        composable("splash") {
            SplashScreen(onFinished = {
                scope.launch {
                    val seen = vm.howToSeen()
                    nav.navigate(if (seen) "home" else "welcome") { popUpTo("splash") { inclusive = true } }
                }
            })
        }
        composable("welcome") {
            HowToScreen(firstRun = true, onDone = {
                vm.markHowToSeen()
                nav.navigate("home") { popUpTo("welcome") { inclusive = true } }
            })
        }
        composable("howto") {
            HowToScreen(firstRun = false, onDone = { vm.markHowToSeen(); nav.popBackStack() })
        }
        composable("home") {
            HomeScreen(
                vm,
                onPlay = { vm.startLevel(vm.progress.value.highestUnlocked); go("game") },
                onContinue = { vm.continueGame(); go("game") },
                onDaily = { go("daily") },
                onLevels = { go("levels") },
                onStats = { go("stats") },
                onHowTo = { go("howto") },
                onSettings = { go("settings") }
            )
        }
        composable("levels") { LevelSelectScreen(vm, onBack = { nav.popBackStack() }, onPlay = { go("game") }) }
        composable("daily") { DailyScreen(vm, onBack = { nav.popBackStack() }, onPlay = { go("game") }) }
        composable("game") {
            GameScreen(
                vm, ads,
                onBack = { nav.popBackStack() },
                onSettings = { go("settings") },
                onHome = { nav.popBackStack("home", inclusive = false) }
            )
        }
        composable("stats") { StatsScreen(vm, onBack = { nav.popBackStack() }) }
        composable("settings") { SettingsScreen(vm, onBack = { nav.popBackStack() }) }
    }
}
