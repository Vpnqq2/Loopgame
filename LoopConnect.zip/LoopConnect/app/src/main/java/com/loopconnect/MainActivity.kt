package com.loopconnect

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.loopconnect.ui.GameViewModel
import com.loopconnect.ui.LoopTheme
import com.loopconnect.ui.ScreenBackground
import com.loopconnect.ui.screens.DailyScreen
import com.loopconnect.ui.screens.GameScreen
import com.loopconnect.ui.screens.HomeScreen
import com.loopconnect.ui.screens.LevelSelectScreen
import com.loopconnect.ui.screens.SettingsScreen
import com.loopconnect.ui.screens.StatsScreen

class MainActivity : ComponentActivity() {
    private val vm: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContent {
            val settings by vm.settings.collectAsStateWithLifecycle()
            LoopTheme(settings.theme) {
                ScreenBackground { AppNav(vm) }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        vm.sound.setForeground(true)
    }

    override fun onStop() {
        super.onStop()
        vm.sound.setForeground(false)
        vm.flush()
    }
}

@Composable
private fun AppNav(vm: GameViewModel) {
    val nav = rememberNavController()
    fun go(route: String) = nav.navigate(route) { launchSingleTop = true }

    NavHost(nav, startDestination = "home") {
        composable("home") {
            HomeScreen(
                vm,
                onPlay = { vm.startLevel(vm.progress.value.highestUnlocked); go("game") },
                onContinue = { vm.continueGame(); go("game") },
                onDaily = { go("daily") },
                onLevels = { go("levels") },
                onStats = { go("stats") },
                onSettings = { go("settings") }
            )
        }
        composable("levels") { LevelSelectScreen(vm, onBack = { nav.popBackStack() }, onPlay = { go("game") }) }
        composable("daily") { DailyScreen(vm, onBack = { nav.popBackStack() }, onPlay = { go("game") }) }
        composable("game") {
            GameScreen(
                vm,
                onBack = { nav.popBackStack() },
                onSettings = { go("settings") },
                onHome = { nav.popBackStack("home", inclusive = false) }
            )
        }
        composable("stats") { StatsScreen(vm, onBack = { nav.popBackStack() }) }
        composable("settings") { SettingsScreen(vm, onBack = { nav.popBackStack() }) }
    }
}
