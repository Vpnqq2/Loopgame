package com.loopconnect

import android.graphics.Color
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.gms.games.PlayGames
import com.google.android.gms.games.PlayGamesSdk
import com.loopconnect.R
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import com.loopconnect.ui.UnlockHost
import com.loopconnect.ui.screens.AwardsScreen
import com.loopconnect.engine.GameMode
import com.loopconnect.ui.screens.HowToScreen
import com.loopconnect.ui.screens.ModeSelectScreen
import com.loopconnect.ui.screens.SplashScreen
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.compose.runtime.CompositionLocalProvider
import com.loopconnect.data.AnimationMode
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import com.loopconnect.ads.AdManager
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import com.loopconnect.ui.GameViewModel
import com.loopconnect.ui.LocalAnimations
import com.loopconnect.ui.LocalSfx
import com.loopconnect.ui.LoopTheme
import com.loopconnect.ui.ScreenBackground
import com.loopconnect.ui.screens.DailyScreen
import com.loopconnect.ui.screens.GameScreen
import com.loopconnect.ui.screens.HomeScreen
import com.loopconnect.ui.screens.LevelSelectScreen
import com.loopconnect.ui.screens.SettingsScreen
import com.loopconnect.ui.screens.StatsScreen

class MainActivity : ComponentActivity() {
    private val vm: GameViewModel by viewModels()
    private val ads by lazy { AdManager(applicationContext) }
    private val telemetry get() = (application as LoopApp).telemetry

    // Google Play Games Services: the official leaderboard screen opens through this launcher.
    private val leaderboardLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }
    private var gamesSignedIn = false
    private var latestScore = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setupAds()
        setupPlayGames()
        setContent {
            val settings by vm.settings.collectAsStateWithLifecycle()
            val lightTheme = settings.theme.isLight
            // Status/navigation bar icons flip to dark on the light theme so they stay visible.
            DisposableEffect(lightTheme) {
                enableEdgeToEdge(
                    statusBarStyle = if (lightTheme) SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT) else SystemBarStyle.dark(Color.TRANSPARENT),
                    navigationBarStyle = if (lightTheme) SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT) else SystemBarStyle.dark(Color.TRANSPARENT)
                )
                onDispose { }
            }
            LoopTheme(settings.theme, animate = settings.animation != AnimationMode.OFF) {
                CompositionLocalProvider(
                    LocalAnimations provides (settings.animation != AnimationMode.OFF),
                    LocalSfx provides vm.sound
                ) {
                    ScreenBackground {
                        Box(Modifier.fillMaxSize()) {
                            AppNav(vm, ads, onLeaderboard = ::showLeaderboard)
                            UnlockHost(vm)
                        }
                    }
                }
            }
        }
    }

    /** Initialises Play Games Services (automatic sign-in) and keeps the leaderboard in sync with the player's stars. */
    private fun setupPlayGames() {
        PlayGamesSdk.initialize(this)
        PlayGames.getGamesSignInClient(this).isAuthenticated.addOnCompleteListener { task ->
            gamesSignedIn = task.isSuccessful && task.result.isAuthenticated
            if (gamesSignedIn) submitScore(latestScore)
        }
        // Every time a level is cleared the star total changes, so the new total is sent to the leaderboard.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.progress.map { p -> p.results.values.sumOf { it.stars }.toLong() }
                    .distinctUntilChanged()
                    .collect { submitScore(it) }
            }
        }
    }

    /** Sends [score] to the leaderboard. Kept if the player is not signed in yet and sent right after sign-in. */
    private fun submitScore(score: Long) {
        latestScore = maxOf(latestScore, score)
        if (!gamesSignedIn || latestScore <= 0L) return
        PlayGames.getLeaderboardsClient(this).submitScore(getString(R.string.leaderboard_id), latestScore)
    }

    /** Opens the official Google Play Games leaderboard, asking the player to sign in first if needed. */
    private fun showLeaderboard() {
        val signIn = PlayGames.getGamesSignInClient(this)
        signIn.isAuthenticated.addOnCompleteListener { auth ->
            if (auth.isSuccessful && auth.result.isAuthenticated) {
                gamesSignedIn = true
                openLeaderboard()
            } else {
                signIn.signIn().addOnCompleteListener { result ->
                    if (result.isSuccessful && result.result.isAuthenticated) {
                        gamesSignedIn = true
                        submitScore(latestScore)
                        openLeaderboard()
                    } else {
                        Toast.makeText(this, "Sign in to Google Play Games to see the leaderboard", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun openLeaderboard() {
        PlayGames.getLeaderboardsClient(this).getLeaderboardIntent(getString(R.string.leaderboard_id))
            .addOnSuccessListener { leaderboardLauncher.launch(it) }
            .addOnFailureListener { Toast.makeText(this, "Leaderboard is unavailable right now", Toast.LENGTH_SHORT).show() }
    }

    /** Ask for consent where required (UMP), then start the ads SDK. The game never depends on it. */
    private fun setupAds() {
        val info = UserMessagingPlatform.getConsentInformation(this)
        info.requestConsentInfoUpdate(
            this, ConsentRequestParameters.Builder().build(),
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(this) { _ -> onConsent(info.canRequestAds()) }
            },
            { _ -> onConsent(info.canRequestAds()) }
        )
        onConsent(info.canRequestAds())
    }

    /** Ads and Firebase analytics/crash reporting only start once consent allows it. */
    private fun onConsent(allowed: Boolean) {
        if (allowed) ads.start()
        telemetry.setConsent(allowed)
    }

    override fun onStart() {
        super.onStart()
        vm.sound.setForeground(true)
        vm.setForeground(true)
    }

    override fun onStop() {
        super.onStop()
        vm.sound.setForeground(false)
        vm.setForeground(false)
        vm.flush()
    }
}

@Composable
private fun AppNav(vm: GameViewModel, ads: AdManager, onLeaderboard: () -> Unit) {
    val nav = rememberNavController()
    fun go(route: String) = nav.navigate(route) { launchSingleTop = true }

    val scope = rememberCoroutineScope()
    val telemetry = (LocalContext.current.applicationContext as LoopApp).telemetry
    DisposableEffect(nav) {
        val listener = NavController.OnDestinationChangedListener { _, dest, _ -> telemetry.screen(dest.route) }
        nav.addOnDestinationChangedListener(listener)
        onDispose { nav.removeOnDestinationChangedListener(listener) }
    }

    // Screen transitions: a soft horizontal slide + fade between pages, a gentle zoom into/out of the
    // game board and a plain cross-fade around the splash/welcome flow. All off when Animation is off.
    val animate = LocalAnimations.current
    NavHost(
        nav, startDestination = "splash",
        enterTransition = { if (animate) pageEnter(initialState.destination.route, targetState.destination.route) else EnterTransition.None },
        exitTransition = { if (animate) pageExit(initialState.destination.route, targetState.destination.route) else ExitTransition.None },
        popEnterTransition = { if (animate) pagePopEnter(initialState.destination.route) else EnterTransition.None },
        popExitTransition = { if (animate) pagePopExit(initialState.destination.route) else ExitTransition.None }
    ) {
        composable("splash") {
            SplashScreen(onFinished = {
                scope.launch {
                    val seen = vm.howToSeen()
                    nav.navigate(if (seen) "home" else "welcome") { popUpTo("splash") { inclusive = true } }
                }
            })
        }
        composable("welcome") {
            LaunchedEffect(Unit) { telemetry.tutorialBegin() }
            HowToScreen(firstRun = true, onDone = {
                telemetry.tutorialComplete()
                vm.markHowToSeen()
                nav.navigate("home") { popUpTo("welcome") { inclusive = true } }
            })
        }
        composable("howto") {
            HowToScreen(firstRun = false, onDone = { vm.markHowToSeen(); nav.popBackStack() })
        }
        composable("home") {
            HomeScreen(
                vm,
                onPlay = { vm.startLevel(vm.progress.value.highestUnlocked); go("game") },
                onContinue = { vm.continueGame(); go("game") },
                onDaily = { go("daily") },
                onModes = { go("modes") },
                onStats = { go("stats") },
                onAwards = { go("awards") },
                onLeaderboard = onLeaderboard,
                onSettings = { go("settings") }
            )
        }
        composable("levels") { LevelSelectScreen(vm, onBack = { nav.popBackStack() }, onPlay = { go("game") }) }
        composable("modes") {
            ModeSelectScreen(vm, onBack = { nav.popBackStack() }, onClassic = { go("levels") }, onChallenge = { go("challenge") }, onPlay = { go("game") })
        }
        composable("challenge") { LevelSelectScreen(vm, onBack = { nav.popBackStack() }, onPlay = { go("game") }, mode = GameMode.CHALLENGE) }
        composable("daily") { DailyScreen(vm, onBack = { nav.popBackStack() }, onPlay = { go("game") }) }
        composable("game") {
            GameScreen(
                vm, ads,
                onBack = { nav.popBackStack() },
                onSettings = { go("settings") },
                onHome = { nav.popBackStack("home", inclusive = false) }
            )
        }
        composable("stats") { StatsScreen(vm, onBack = { nav.popBackStack() }, onAwards = { go("awards") }) }
        composable("awards") { AwardsScreen(vm, onBack = { nav.popBackStack() }) }
        composable("settings") { SettingsScreen(vm, onBack = { nav.popBackStack() }, onHowTo = { go("howto") }) }
    }
}

private const val PAGE_MS = 360
private fun intro(route: String?) = route == "splash" || route == "welcome"

private fun pageEnter(from: String?, to: String?): EnterTransition = when {
    intro(from) || intro(to) -> fadeIn(tween(450))
    to == "game" -> fadeIn(tween(320, easing = LinearOutSlowInEasing)) + scaleIn(tween(PAGE_MS, easing = FastOutSlowInEasing), initialScale = 0.92f)
    else -> slideInHorizontally(tween(PAGE_MS, easing = FastOutSlowInEasing)) { (it * 0.12f).toInt() } +
        fadeIn(tween(PAGE_MS - 60, delayMillis = 50, easing = LinearOutSlowInEasing))
}

private fun pageExit(from: String?, to: String?): ExitTransition = when {
    intro(from) || intro(to) -> fadeOut(tween(300))
    to == "game" -> fadeOut(tween(220)) + scaleOut(tween(PAGE_MS, easing = FastOutSlowInEasing), targetScale = 1.05f)
    else -> slideOutHorizontally(tween(PAGE_MS, easing = FastOutSlowInEasing)) { -(it * 0.08f).toInt() } + fadeOut(tween(220))
}

private fun pagePopEnter(leaving: String?): EnterTransition =
    if (leaving == "game") fadeIn(tween(320, easing = LinearOutSlowInEasing)) + scaleIn(tween(PAGE_MS, easing = FastOutSlowInEasing), initialScale = 1.05f)
    else slideInHorizontally(tween(PAGE_MS, easing = FastOutSlowInEasing)) { -(it * 0.08f).toInt() } +
        fadeIn(tween(PAGE_MS - 60, delayMillis = 50, easing = LinearOutSlowInEasing))

private fun pagePopExit(leaving: String?): ExitTransition =
    if (leaving == "game") fadeOut(tween(220)) + scaleOut(tween(PAGE_MS, easing = FastOutSlowInEasing), targetScale = 0.92f)
    else slideOutHorizontally(tween(PAGE_MS, easing = FastOutSlowInEasing)) { (it * 0.12f).toInt() } + fadeOut(tween(220))
