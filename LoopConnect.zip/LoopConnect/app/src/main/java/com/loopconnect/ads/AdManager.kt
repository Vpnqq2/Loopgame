package com.loopconnect.ads

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Handler
import android.os.Looper
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.loopconnect.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/**
 * Rewarded ads (AdMob). Ads are only ever shown after the player taps "Watch ad".
 * The game stays fully playable offline: if no ad is available the button simply stays disabled.
 */
class AdManager(context: Context) {
    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready.asStateFlow()
    private var ad: RewardedAd? = null
    private var loading = false
    private var started = false

    /** Call once the user's consent state allows requesting ads. Safe to call repeatedly. */
    fun start() {
        if (started) return
        started = true
        MobileAds.initialize(app) { main.post { load() } }
    }

    fun load() {
        if (!started || loading || ad != null) return
        loading = true
        RewardedAd.load(app, BuildConfig.ADMOB_REWARDED_ID, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(loaded: RewardedAd) {
                ad = loaded
                loading = false
                _ready.value = true
            }

            override fun onAdFailedToLoad(error: LoadAdError) {
                ad = null
                loading = false
                _ready.value = false
                main.postDelayed({ load() }, 30_000)
            }
        })
    }

    fun show(activity: Activity, onRewarded: () -> Unit, onUnavailable: () -> Unit) {
        val current = ad
        if (current == null) {
            onUnavailable()
            load()
            return
        }
        current.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                ad = null
                _ready.value = false
                load()
            }

            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                ad = null
                _ready.value = false
                onUnavailable()
                load()
            }
        }
        current.show(activity) { onRewarded() }
    }
}
