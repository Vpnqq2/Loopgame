package com.loopconnect.ads

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Handler
import android.os.Looper
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.loopconnect.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/**
 * AdMob wrapper. It only loads and shows; WHETHER an ad may be shown is decided by
 * [com.loopconnect.engine.AdPolicy]. Ads are loaded lazily to keep request volume low.
 * The game stays fully playable offline: a missing ad is simply skipped, never awaited.
 */
class AdManager(context: Context) {
    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private var started = false

    // ----- rewarded (hint) -----
    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready.asStateFlow()
    private var rewarded: RewardedAd? = null
    private var loadingRewarded = false

    // ----- interstitial (between levels) -----
    private var interstitial: InterstitialAd? = null
    private var loadingInterstitial = false
    val interstitialReady: Boolean get() = interstitial != null

    /** Call once the user's consent state allows requesting ads. Safe to call repeatedly. */
    fun start() {
        if (started) return
        started = true
        MobileAds.initialize(app) { }
    }

    // ---------------- rewarded ----------------

    fun load() {
        if (!started || loadingRewarded || rewarded != null) return
        loadingRewarded = true
        RewardedAd.load(app, BuildConfig.ADMOB_REWARDED_ID, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(loaded: RewardedAd) {
                rewarded = loaded
                loadingRewarded = false
                _ready.value = true
            }

            override fun onAdFailedToLoad(error: LoadAdError) {
                rewarded = null
                loadingRewarded = false
                _ready.value = false
                // No automatic retry loop: the next request is triggered by the player opening the dialog.
            }
        })
    }

    fun show(activity: Activity, onRewarded: () -> Unit, onUnavailable: () -> Unit) {
        val current = rewarded
        if (current == null) {
            onUnavailable()
            load()
            return
        }
        // Take the ad immediately so a double tap can never show it twice.
        rewarded = null
        _ready.value = false
        current.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                onUnavailable()
            }
        }
        current.show(activity) { onRewarded() }
    }

    // ---------------- interstitial ----------------

    fun loadInterstitial() {
        if (!started || loadingInterstitial || interstitial != null) return
        loadingInterstitial = true
        InterstitialAd.load(app, BuildConfig.ADMOB_INTERSTITIAL_ID, AdRequest.Builder().build(), object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) {
                interstitial = ad
                loadingInterstitial = false
            }

            override fun onAdFailedToLoad(error: LoadAdError) {
                interstitial = null
                loadingInterstitial = false
            }
        })
    }

    /** Shows the interstitial only if it is already loaded; otherwise does nothing (the player never waits). */
    fun showInterstitial(activity: Activity, onShown: () -> Unit) {
        val ad = interstitial ?: return
        interstitial = null
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                onShown()
            }
        }
        main.post { ad.show(activity) }
    }
}
