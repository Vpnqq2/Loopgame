package com.loopconnect.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import com.loopconnect.R
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * A soft synthesised mechanical click for rotations and a chime for completion, plus the looping background
 * track "Old City Theme" by remaxim (CC BY-SA 3.0, credited in About) played quietly at [MUSIC_VOLUME].
 */
class SoundFx(private val context: Context) {
    companion object {
        /** Background music loudness (0..1). 0.15 = 15%, calm enough not to distract. */
        const val MUSIC_VOLUME = 0.15f
    }

    private val rate = 22050
    private var tickIdx = 0
    private var chime: AudioTrack? = null
    private var click: AudioTrack? = null
    private var open: AudioTrack? = null
    private val built = HashMap<String, AudioTrack?>()
    @Volatile private var music: MediaPlayer? = null
    @Volatile private var starting = false
    @Volatile private var musicWanted = false
    @Volatile private var foreground = true
    @Volatile private var released = false
    var sfxEnabled = true

    private fun track(samples: ShortArray, loop: Boolean): AudioTrack? = runCatching {
        AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setTransferMode(AudioTrack.MODE_STATIC)
            .setBufferSizeInBytes(samples.size * 2)
            .build().also {
                it.write(samples, 0, samples.size)
                if (loop) it.setLoopPoints(0, samples.size, -1)
            }
    }.getOrNull()

    private fun tone(freq: Double, seconds: Double, decay: Double, vol: Double, out: ShortArray, startSec: Double = 0.0) {
        val s0 = (startSec * rate).toInt()
        val n = (seconds * rate).toInt()
        for (i in 0 until n) {
            val idx = s0 + i
            if (idx >= out.size) break
            val t = i.toDouble() / rate
            val attack = (t / 0.004).coerceAtMost(1.0)
            val v = sin(2 * PI * freq * t) * exp(-t * decay) * attack * vol
            out[idx] = (out[idx] + (v * 32767).toInt()).coerceIn(-32768, 32767).toShort()
        }
    }

    private fun replay(t: AudioTrack?) {
        if (t == null) return
        runCatching { t.stop(); t.reloadStaticData(); t.play() }
    }

    /** A burst of crisp, quiet noise; [seed] keeps every build of the same sound identical. */
    private fun noise(seconds: Double, decay: Double, vol: Double, out: ShortArray, startSec: Double, seed: Int) {
        val rnd = kotlin.random.Random(seed)
        val s0 = (startSec * rate).toInt()
        val n = (seconds * rate).toInt()
        var prev = 0.0
        for (i in 0 until n) {
            val idx = s0 + i
            if (idx >= out.size) break
            val t = i.toDouble() / rate
            val raw = rnd.nextDouble() * 2 - 1
            val hp = raw - prev * 0.6   // crude high-pass: crisp, not hissy
            prev = raw
            val v = hp * 0.5 * exp(-t * decay) * vol
            out[idx] = (out[idx] + (v * 32767).toInt()).coerceIn(-32768, 32767).toShort()
        }
    }

    /** Soft mechanical click: contact transient, a low muted thump, then a tiny latch snap. */
    private fun mechanicalClick(variant: Int, buf: ShortArray) {
        val body = doubleArrayOf(165.0, 185.0, 205.0)[variant]
        val latch = doubleArrayOf(1750.0, 1900.0, 2050.0)[variant]
        noise(0.012, 450.0, 0.30, buf, 0.0, 11 + variant)
        tone(body, 0.05, 85.0, 0.30, buf)
        noise(0.008, 700.0, 0.16, buf, 0.026, 31 + variant)
        tone(latch, 0.03, 260.0, 0.10, buf, 0.026)
    }

    /** Rotation click. Three slightly different variants take turns so repeated taps never sound identical. */
    fun playTick() {
        if (!sfxEnabled || released) return
        val k = tickIdx
        tickIdx = (tickIdx + 1) % 3
        playBuilt("click$k", 0.09) { mechanicalClick(k, it) }
    }

    /** Short, bright "pop" for every button press; higher and crisper than the rotation tick. */
    fun playClick() {
        if (!sfxEnabled || released) return
        if (click == null) {
            val buf = ShortArray((rate * 0.05).toInt())
            tone(1500.0, 0.035, 170.0, 0.30, buf)
            tone(750.0, 0.05, 90.0, 0.22, buf)
            click = track(buf, false)
        }
        replay(click)
    }

    /** A rising whoosh that lands on two soft plucked notes: played when a level opens. */
    fun playLevelOpen() {
        if (!sfxEnabled || released) return
        if (open == null) {
            val buf = ShortArray((rate * 0.9).toInt())
            // Rising sweep 280 Hz -> 900 Hz over 0.3 s with a smooth bell-shaped envelope.
            val n = (0.3 * rate).toInt()
            var phase = 0.0
            for (i in 0 until n) {
                val x = i.toDouble() / n
                val f = 280.0 + (900.0 - 280.0) * x * x
                phase += 2 * PI * f / rate
                val env = sin(PI * x)
                buf[i] = (sin(phase) * env * 0.26 * 32767).toInt().coerceIn(-32768, 32767).toShort()
            }
            tone(659.25, 0.55, 6.5, 0.26, buf, 0.22)
            tone(987.77, 0.6, 6.0, 0.22, buf, 0.30)
            open = track(buf, false)
        }
        replay(open)
    }

    /** Builds a sound once, caches it and replays it. */
    private fun playBuilt(key: String, seconds: Double, build: (ShortArray) -> Unit) {
        if (!sfxEnabled || released) return
        if (!built.containsKey(key)) built[key] = track(ShortArray((rate * seconds).toInt()).also(build), false)
        replay(built[key])
    }

    /** A bell note with a little shimmer on top: [f] plus a quiet octave and twelfth. */
    private fun bell(f: Double, seconds: Double, decay: Double, vol: Double, out: ShortArray, startSec: Double = 0.0) {
        tone(f, seconds, decay, vol, out, startSec)
        tone(f * 2, seconds * 0.7, decay * 1.6, vol * 0.35, out, startSec)
        tone(f * 3, seconds * 0.4, decay * 2.4, vol * 0.15, out, startSec)
    }

    /** One sparkling bell per star as it pops in; each star is higher than the last (A, C#, E). */
    fun playStar(index: Int) {
        val i = index.coerceIn(0, 2)
        val f = doubleArrayOf(880.0, 1108.73, 1318.51)[i]
        playBuilt("star$i", if (i == 2) 0.9 else 0.5) { buf ->
            bell(f, if (i == 2) 0.85 else 0.45, if (i == 2) 4.5 else 8.0, 0.30, buf)
            if (i == 2) bell(f * 2, 0.6, 7.0, 0.14, buf, 0.05)   // the third star gets an extra glint
        }
    }

    /** Padlock opening: a dry click-clack, then a quick glittering run upwards. */
    fun playLevelUnlock() {
        playBuilt("unlock", 1.1) { buf ->
            tone(2600.0, 0.012, 600.0, 0.35, buf)                 // click
            tone(1700.0, 0.02, 380.0, 0.30, buf, 0.075)           // clack
            listOf(1046.5, 1318.51, 1567.98, 2093.0).forEachIndexed { k, f ->
                bell(f, 0.5, 9.0, 0.22, buf, 0.20 + k * 0.075)    // C6 E6 G6 C7
            }
            bell(2093.0, 0.9, 4.5, 0.18, buf, 0.50)               // lingering top note
        }
    }

    /** Award unlocked: a short brass-like fanfare (da-da-DAAA) that is clearly not the level chime. */
    fun playAward() {
        playBuilt("award", 1.6) { buf ->
            fun brass(f: Double, sec: Double, start: Double, vol: Double) {
                tone(f, sec, 2.2, vol, buf, start)
                tone(f * 2, sec, 2.6, vol * 0.5, buf, start)
                tone(f * 3, sec, 3.4, vol * 0.28, buf, start)
                tone(f * 4, sec, 4.4, vol * 0.14, buf, start)
            }
            brass(392.0, 0.22, 0.00, 0.20)   // G4
            brass(523.25, 0.22, 0.14, 0.20)  // C5
            listOf(523.25, 659.25, 783.99).forEach { brass(it, 1.1, 0.30, 0.11) }  // held C major
            bell(1567.98, 0.9, 5.0, 0.14, buf, 0.34)
            bell(2093.0, 0.9, 5.0, 0.10, buf, 0.46)
        }
    }

    /**
     * A padlock breaking when a level is solved: a dry metal snap and a dull crack, three little shards falling, then a
     * small sparkle. Same family as the unlock sound, but shorter and more mechanical.
     */
    fun playLockBreak() {
        playBuilt("lockbreak", 1.0) { buf ->
            noise(0.02, 300.0, 0.40, buf, 0.0, 71)
            tone(2300.0, 0.05, 150.0, 0.26, buf)                  // metal snap
            tone(3100.0, 0.04, 220.0, 0.16, buf, 0.004)
            tone(140.0, 0.09, 55.0, 0.30, buf, 0.01)              // dull crack
            listOf(0.10, 0.17, 0.26).forEachIndexed { k, at ->    // shards landing
                noise(0.01, 600.0, 0.18, buf, at, 81 + k)
                tone(1900.0 + k * 260.0, 0.03, 260.0, 0.12, buf, at)
            }
            bell(1567.98, 0.5, 7.0, 0.16, buf, 0.20)
            bell(2093.0, 0.6, 6.0, 0.12, buf, 0.30)
        }
    }

    /** Tapping a padlocked piece: a muted double "tok", clearly different from the rotation click. */
    fun playLockDenied() {
        playBuilt("lockdenied", 0.16) { buf ->
            noise(0.01, 500.0, 0.22, buf, 0.0, 91)
            tone(130.0, 0.06, 70.0, 0.30, buf)
            tone(105.0, 0.07, 70.0, 0.24, buf, 0.065)
        }
    }

    /** Twin pieces turning together: a soft two-note shimmer that follows the rotation click. */
    fun playLink() {
        playBuilt("link", 0.4) { buf ->
            bell(880.0, 0.25, 12.0, 0.13, buf, 0.03)
            bell(1318.51, 0.3, 11.0, 0.11, buf, 0.10)
        }
    }

    fun playComplete() {
        if (!sfxEnabled || released) return
        if (chime == null) {
            val buf = ShortArray((rate * 1.6).toInt())
            listOf(523.25, 659.25, 783.99, 1046.5).forEachIndexed { i, f ->
                tone(f, 1.1, 3.2, 0.28, buf, i * 0.16)
            }
            chime = track(buf, false)
        }
        replay(chime)
    }

    fun setMusic(enabled: Boolean) {
        musicWanted = enabled
        if (enabled) startMusic() else pauseMusic()
    }

    fun setForeground(fg: Boolean) {
        foreground = fg
        if (fg && musicWanted) startMusic() else pauseMusic()
    }

    private fun startMusic() {
        if (released || !musicWanted || !foreground) return
        music?.let { runCatching { if (!it.isPlaying) it.start() }; return }
        if (starting) return
        starting = true
        Thread {
            try {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                val mp = MediaPlayer.create(context, R.raw.old_city_theme, attrs, AudioManager.AUDIO_SESSION_ID_GENERATE)
                    ?: return@Thread
                mp.isLooping = true
                mp.setVolume(MUSIC_VOLUME, MUSIC_VOLUME)
                if (released) { mp.release(); return@Thread }
                music = mp
                if (musicWanted && foreground) runCatching { mp.start() }
            } catch (_: Exception) {
                // Music is optional: the game keeps working silently.
            } finally {
                starting = false
            }
        }.start()
    }

    fun pauseMusic() {
        runCatching { music?.let { if (it.isPlaying) it.pause() } }
    }

    fun release() {
        released = true
        runCatching { chime?.release(); click?.release(); open?.release(); built.values.forEach { it?.release() } }
        runCatching { music?.release() }
        chime = null; click = null; open = null; built.clear(); music = null
    }
}
