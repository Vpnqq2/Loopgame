package com.loopconnect.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Original, synthesised audio: no asset files. A soft tick for rotations, a chime for completion
 * and a slow ambient pad as optional background music.
 */
class SoundFx {
    private val rate = 22050
    private var tick: AudioTrack? = null
    private var chime: AudioTrack? = null
    private var music: AudioTrack? = null
    @Volatile private var musicWanted = false
    @Volatile private var foreground = true
    @Volatile private var released = false
    var sfxEnabled = true

    private fun track(samples: ShortArray, loop: Boolean): AudioTrack? = runCatching {
        AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setTransferMode(AudioTrack.MODE_STATIC)
            .setBufferSizeInBytes(samples.size * 2)
            .build().also {
                it.write(samples, 0, samples.size)
                if (loop) it.setLoopPoints(0, samples.size, -1)
            }
    }.getOrNull()

    private fun tone(freq: Double, seconds: Double, decay: Double, vol: Double, out: ShortArray, startSec: Double = 0.0) {
        val s0 = (startSec * rate).toInt()
        val n = (seconds * rate).toInt()
        for (i in 0 until n) {
            val idx = s0 + i
            if (idx >= out.size) break
            val t = i.toDouble() / rate
            val attack = (t / 0.004).coerceAtMost(1.0)
            val v = sin(2 * PI * freq * t) * exp(-t * decay) * attack * vol
            out[idx] = (out[idx] + (v * 32767).toInt()).coerceIn(-32768, 32767).toShort()
        }
    }

    private fun replay(t: AudioTrack?) {
        if (t == null) return
        runCatching { t.stop(); t.reloadStaticData(); t.play() }
    }

    fun playTick() {
        if (!sfxEnabled || released) return
        if (tick == null) tick = track(ShortArray((rate * 0.06).toInt()).also { tone(620.0, 0.06, 55.0, 0.35, it) }, false)
        replay(tick)
    }

    fun playComplete() {
        if (!sfxEnabled || released) return
        if (chime == null) {
            val buf = ShortArray((rate * 1.6).toInt())
            listOf(523.25, 659.25, 783.99, 1046.5).forEachIndexed { i, f ->
                tone(f, 1.1, 3.2, 0.28, buf, i * 0.16)
            }
            chime = track(buf, false)
        }
        replay(chime)
    }

    fun setMusic(enabled: Boolean) {
        musicWanted = enabled
        if (enabled) startMusic() else pauseMusic()
    }

    fun setForeground(fg: Boolean) {
        foreground = fg
        if (fg && musicWanted) startMusic() else pauseMusic()
    }

    private fun startMusic() {
        if (released || !musicWanted || !foreground) return
        val existing = music
        if (existing != null) { runCatching { existing.play() }; return }
        Thread {
            val seconds = 16
            val buf = ShortArray(rate * seconds)
            val chords = listOf(
                listOf(220.0, 261.63, 329.63, 392.0),  // Am7
                listOf(174.61, 220.0, 261.63, 329.63), // Fmaj7
                listOf(196.0, 261.63, 329.63, 392.0),  // C/G
                listOf(196.0, 246.94, 293.66, 392.0)   // G
            )
            val per = seconds / chords.size
            chords.forEachIndexed { ci, notes ->
                for (i in 0 until rate * per) {
                    val t = i.toDouble() / rate
                    val env = sin(PI * t / per).let { it * it }
                    var v = 0.0
                    for (f in notes) v += sin(2 * PI * f * t) + 0.3 * sin(4 * PI * f * t + 1.0)
                    val idx = ci * rate * per + i
                    buf[idx] = (v / notes.size * env * 0.16 * 32767).toInt().toShort()
                }
            }
            val t = track(buf, true) ?: return@Thread
            if (released) { t.release(); return@Thread }
            music = t
            if (musicWanted && foreground) runCatching { t.play() }
        }.start()
    }

    fun pauseMusic() {
        runCatching { music?.pause() }
    }

    fun release() {
        released = true
        runCatching { tick?.release(); chime?.release(); music?.release() }
        tick = null; chime = null; music = null
    }
}
