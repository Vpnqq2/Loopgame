package com.loopconnect.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import com.loopconnect.R
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * A soft synthesised tick for rotations and a chime for completion, plus the looping background
 * track "Old City Theme" by remaxim (CC BY-SA 3.0, credited in About) played quietly at [MUSIC_VOLUME].
 */
class SoundFx(private val context: Context) {
    companion object {
        /** Background music loudness (0..1). 0.15 = 15%, calm enough not to distract. */
        const val MUSIC_VOLUME = 0.15f
    }

    private val rate = 22050
    private var tick: AudioTrack? = null
    private var chime: AudioTrack? = null
    private var click: AudioTrack? = null
    private var open: AudioTrack? = null
    @Volatile private var music: MediaPlayer? = null
    @Volatile private var starting = false
    @Volatile private var musicWanted = false
    @Volatile private var foreground = true
    @Volatile private var released = false
    var sfxEnabled = true

    private fun track(samples: ShortArray, loop: Boolean): AudioTrack? = runCatching {
        AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setTransferMode(AudioTrack.MODE_STATIC)
            .setBufferSizeInBytes(samples.size * 2)
            .build().also {
                it.write(samples, 0, samples.size)
                if (loop) it.setLoopPoints(0, samples.size, -1)
            }
    }.getOrNull()

    private fun tone(freq: Double, seconds: Double, decay: Double, vol: Double, out: ShortArray, startSec: Double = 0.0) {
        val s0 = (startSec * rate).toInt()
        val n = (seconds * rate).toInt()
        for (i in 0 until n) {
            val idx = s0 + i
            if (idx >= out.size) break
            val t = i.toDouble() / rate
            val attack = (t / 0.004).coerceAtMost(1.0)
            val v = sin(2 * PI * freq * t) * exp(-t * decay) * attack * vol
            out[idx] = (out[idx] + (v * 32767).toInt()).coerceIn(-32768, 32767).toShort()
        }
    }

    private fun replay(t: AudioTrack?) {
        if (t == null) return
        runCatching { t.stop(); t.reloadStaticData(); t.play() }
    }

    fun playTick() {
        if (!sfxEnabled || released) return
        if (tick == null) tick = track(ShortArray((rate * 0.06).toInt()).also { tone(620.0, 0.06, 55.0, 0.35, it) }, false)
        replay(tick)
    }

    /** Short, bright "pop" for every button press; higher and crisper than the rotation tick. */
    fun playClick() {
        if (!sfxEnabled || released) return
        if (click == null) {
            val buf = ShortArray((rate * 0.05).toInt())
            tone(1500.0, 0.035, 170.0, 0.30, buf)
            tone(750.0, 0.05, 90.0, 0.22, buf)
            click = track(buf, false)
        }
        replay(click)
    }

    /** A rising whoosh that lands on two soft plucked notes: played when a level opens. */
    fun playLevelOpen() {
        if (!sfxEnabled || released) return
        if (open == null) {
            val buf = ShortArray((rate * 0.9).toInt())
            // Rising sweep 280 Hz -> 900 Hz over 0.3 s with a smooth bell-shaped envelope.
            val n = (0.3 * rate).toInt()
            var phase = 0.0
            for (i in 0 until n) {
                val x = i.toDouble() / n
                val f = 280.0 + (900.0 - 280.0) * x * x
                phase += 2 * PI * f / rate
                val env = sin(PI * x)
                buf[i] = (sin(phase) * env * 0.26 * 32767).toInt().coerceIn(-32768, 32767).toShort()
            }
            tone(659.25, 0.55, 6.5, 0.26, buf, 0.22)
            tone(987.77, 0.6, 6.0, 0.22, buf, 0.30)
            open = track(buf, false)
        }
        replay(open)
    }

    fun playComplete() {
        if (!sfxEnabled || released) return
        if (chime == null) {
            val buf = ShortArray((rate * 1.6).toInt())
            listOf(523.25, 659.25, 783.99, 1046.5).forEachIndexed { i, f ->
                tone(f, 1.1, 3.2, 0.28, buf, i * 0.16)
            }
            chime = track(buf, false)
        }
        replay(chime)
    }

    fun setMusic(enabled: Boolean) {
        musicWanted = enabled
        if (enabled) startMusic() else pauseMusic()
    }

    fun setForeground(fg: Boolean) {
        foreground = fg
        if (fg && musicWanted) startMusic() else pauseMusic()
    }

    private fun startMusic() {
        if (released || !musicWanted || !foreground) return
        music?.let { runCatching { if (!it.isPlaying) it.start() }; return }
        if (starting) return
        starting = true
        Thread {
            try {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                val mp = MediaPlayer.create(context, R.raw.old_city_theme, attrs, AudioManager.AUDIO_SESSION_ID_GENERATE)
                    ?: return@Thread
                mp.isLooping = true
                mp.setVolume(MUSIC_VOLUME, MUSIC_VOLUME)
                if (released) { mp.release(); return@Thread }
                music = mp
                if (musicWanted && foreground) runCatching { mp.start() }
            } catch (_: Exception) {
                // Music is optional: the game keeps working silently.
            } finally {
                starting = false
            }
        }.start()
    }

    fun pauseMusic() {
        runCatching { music?.let { if (it.isPlaying) it.pause() } }
    }

    fun release() {
        released = true
        runCatching { tick?.release(); chime?.release(); click?.release(); open?.release() }
        runCatching { music?.release() }
        tick = null; chime = null; click = null; open = null; music = null
    }
}
