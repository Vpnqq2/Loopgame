package com.loopconnect.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.loopconnect.engine.LevelResult
import com.loopconnect.engine.Progress
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.store: DataStore<Preferences> by preferencesDataStore(name = "loop_connect")

enum class ThemeId(val label: String) { MIDNIGHT("Midnight"), AMOLED("Amoled"), AURORA("Aurora") }
enum class AnimationMode(val label: String, val rotateMs: Int) {
    SMOOTH("Smooth", 220), QUICK("Quick", 110), OFF("Off", 0)
}

data class Settings(
    val sound: Boolean = true,
    val music: Boolean = true,
    val haptics: Boolean = true,
    val theme: ThemeId = ThemeId.MIDNIGHT,
    val animation: AnimationMode = AnimationMode.SMOOTH
)

/** All persistence. Reads never throw: storage errors fall back to defaults. */
class Repository(context: Context) {
    private val ds = context.applicationContext.store

    private object K {
        val sound = booleanPreferencesKey("sound")
        val music = booleanPreferencesKey("music")
        val haptics = booleanPreferencesKey("haptics")
        val theme = stringPreferencesKey("theme")
        val anim = stringPreferencesKey("anim")
        val save = stringPreferencesKey("save")
        val results = stringPreferencesKey("results")
        val totalMoves = longPreferencesKey("total_moves")
        val totalSolved = intPreferencesKey("total_solved")
        val dailyDays = stringPreferencesKey("daily_days")
        val lastDaily = longPreferencesKey("last_daily")
        val streak = intPreferencesKey("streak")
        val recent = stringPreferencesKey("recent")
    }

    private val safe: Flow<Preferences> = ds.data.catch { emit(emptyPreferences()) }

    val settings: Flow<Settings> = safe.map { p ->
        Settings(
            sound = p[K.sound] ?: true,
            music = p[K.music] ?: true,
            haptics = p[K.haptics] ?: true,
            theme = ThemeId.values().firstOrNull { it.name == p[K.theme] } ?: ThemeId.MIDNIGHT,
            animation = AnimationMode.values().firstOrNull { it.name == p[K.anim] } ?: AnimationMode.SMOOTH
        )
    }.distinctUntilChanged()

    val savedGame: Flow<String?> = safe.map { it[K.save] }.distinctUntilChanged()

    val progress: Flow<Progress> = safe.map { p ->
        Progress(
            results = parseResults(p[K.results]),
            totalMoves = p[K.totalMoves] ?: 0L,
            totalSolved = p[K.totalSolved] ?: 0,
            dailyDays = parseLongs(p[K.dailyDays]).toSet(),
            lastDailyDay = p[K.lastDaily] ?: -1L,
            dailyStreak = p[K.streak] ?: 0,
            recentSignatures = parseLongs(p[K.recent])
        )
    }.distinctUntilChanged()

    suspend fun currentSave(): String? = runCatching { safe.map { it[K.save] }.first() }.getOrNull()

    suspend fun currentProgress(): Progress = runCatching { progress.first() }.getOrDefault(Progress())

    suspend fun writeSave(encoded: String?) = runCatching {
        ds.edit { if (encoded == null) it.remove(K.save) else it[K.save] = encoded }
    }

    suspend fun updateProgress(transform: (Progress) -> Progress) = runCatching {
        ds.edit { p ->
            val cur = Progress(
                results = parseResults(p[K.results]),
                totalMoves = p[K.totalMoves] ?: 0L,
                totalSolved = p[K.totalSolved] ?: 0,
                dailyDays = parseLongs(p[K.dailyDays]).toSet(),
                lastDailyDay = p[K.lastDaily] ?: -1L,
                dailyStreak = p[K.streak] ?: 0,
                recentSignatures = parseLongs(p[K.recent])
            )
            val n = transform(cur)
            p[K.results] = n.results.entries.joinToString(";") { "${it.key}:${it.value.stars}:${it.value.bestMoves}" }
            p[K.totalMoves] = n.totalMoves
            p[K.totalSolved] = n.totalSolved
            p[K.dailyDays] = n.dailyDays.joinToString(",")
            p[K.lastDaily] = n.lastDailyDay
            p[K.streak] = n.dailyStreak
            p[K.recent] = n.recentSignatures.joinToString(",")
        }
    }

    suspend fun updateSettings(transform: (Settings) -> Settings) = runCatching {
        ds.edit { p ->
            val cur = Settings(
                sound = p[K.sound] ?: true, music = p[K.music] ?: true, haptics = p[K.haptics] ?: true,
                theme = ThemeId.values().firstOrNull { it.name == p[K.theme] } ?: ThemeId.MIDNIGHT,
                animation = AnimationMode.values().firstOrNull { it.name == p[K.anim] } ?: AnimationMode.SMOOTH
            )
            val n = transform(cur)
            p[K.sound] = n.sound; p[K.music] = n.music; p[K.haptics] = n.haptics
            p[K.theme] = n.theme.name; p[K.anim] = n.animation.name
        }
    }

    /** Deletes saved game, statistics and level progress. Settings are kept. */
    suspend fun resetProgress() = runCatching {
        ds.edit { p ->
            listOf(K.save, K.results, K.dailyDays, K.recent).forEach { p.remove(it) }
            p.remove(K.totalMoves); p.remove(K.totalSolved); p.remove(K.lastDaily); p.remove(K.streak)
        }
    }

    private fun parseResults(s: String?): Map<Int, LevelResult> {
        if (s.isNullOrBlank()) return emptyMap()
        val out = HashMap<Int, LevelResult>()
        for (part in s.split(";")) {
            val f = part.split(":")
            if (f.size != 3) continue
            val n = f[0].toIntOrNull() ?: continue
            val st = f[1].toIntOrNull() ?: continue
            val mv = f[2].toIntOrNull() ?: continue
            out[n] = LevelResult(st.coerceIn(1, 3), mv)
        }
        return out
    }

    private fun parseLongs(s: String?): List<Long> =
        if (s.isNullOrBlank()) emptyList() else s.split(",").mapNotNull { it.toLongOrNull() }
}

