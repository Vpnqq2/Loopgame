package com.loopconnect.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.loopconnect.engine.AdState
import com.loopconnect.engine.LevelResult
import com.loopconnect.engine.START_HINTS
import com.loopconnect.engine.Progress
import com.loopconnect.engine.RateState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.store: DataStore<Preferences> by preferencesDataStore(name = "loop_connect")

enum class ThemeId(val label: String, val isLight: Boolean = false) {
    ORCHID("Orchid"), MIDNIGHT("Midnight"), AMOLED("Amoled"), AURORA("Aurora"), DAYLIGHT("Daylight", isLight = true)
}
enum class AnimationMode(val label: String, val rotateMs: Int) {
    SMOOTH("Smooth", 220), QUICK("Quick", 110), OFF("Off", 0)
}

data class Settings(
    val sound: Boolean = true,
    val music: Boolean = true,
    val haptics: Boolean = true,
    val theme: ThemeId = ThemeId.ORCHID,
    val animation: AnimationMode = AnimationMode.SMOOTH,
    val howToSeen: Boolean = false,
    val analytics: Boolean = true,
    val notifications: Boolean = false,
    val notifPrompted: Boolean = false,
    val rate: RateState = RateState()
)

/** All persistence. Reads never throw: storage errors fall back to defaults. */
class Repository(context: Context) {
    private val ds = context.applicationContext.store

    private object K {
        val sound = booleanPreferencesKey("sound")
        val music = booleanPreferencesKey("music")
        val haptics = booleanPreferencesKey("haptics")
        val theme = stringPreferencesKey("theme")
        val anim = stringPreferencesKey("anim")
        val save = stringPreferencesKey("save")
        val results = stringPreferencesKey("results")
        val totalMoves = longPreferencesKey("total_moves")
        val totalSolved = intPreferencesKey("total_solved")
        val dailyDays = stringPreferencesKey("daily_days")
        val lastDaily = longPreferencesKey("last_daily")
        val streak = intPreferencesKey("streak")
        val recent = stringPreferencesKey("recent")
        val hints = intPreferencesKey("hints")
        val howTo = booleanPreferencesKey("howto_seen")
        val unlocked = stringPreferencesKey("unlocked")
        val adState = stringPreferencesKey("ad_state")
        val challenge = intPreferencesKey("challenge_cleared")
        val spark = intPreferencesKey("spark_cleared")
        val zen = intPreferencesKey("zen_solved")
        val rushBest = intPreferencesKey("rush_best")
        val rushRuns = intPreferencesKey("rush_runs")
        val rushTotal = intPreferencesKey("rush_total")
        val seenTwists = stringPreferencesKey("seen_twists")
        val analytics = booleanPreferencesKey("analytics")
        val notifications = booleanPreferencesKey("notifications")
        val notifPrompted = booleanPreferencesKey("notif_prompted")
        val rateDone = booleanPreferencesKey("rate_done")
        val rateShown = intPreferencesKey("rate_shown")
        val rateLastMs = longPreferencesKey("rate_last_ms")
        val rateLastLevels = intPreferencesKey("rate_last_levels")
    }

    private val safe: Flow<Preferences> = ds.data.catch { emit(emptyPreferences()) }

    val settings: Flow<Settings> = safe.map { p ->
        Settings(
            sound = p[K.sound] ?: true,
            music = p[K.music] ?: true,
            haptics = p[K.haptics] ?: true,
            theme = ThemeId.values().firstOrNull { it.name == p[K.theme] } ?: ThemeId.ORCHID,
            animation = AnimationMode.values().firstOrNull { it.name == p[K.anim] } ?: AnimationMode.SMOOTH,
            howToSeen = p[K.howTo] ?: false,
            analytics = p[K.analytics] ?: true,
            notifications = p[K.notifications] ?: false,
            notifPrompted = p[K.notifPrompted] ?: false,
            rate = readRate(p)
        )
    }.distinctUntilChanged()

    /** Ad limit counters. Kept on purpose when progress is reset. */
    val adState: Flow<AdState> = safe.map { AdState.decode(it[K.adState]) }.distinctUntilChanged()

    suspend fun updateAdState(transform: (AdState) -> AdState) = runCatching {
        ds.edit { p -> p[K.adState] = transform(AdState.decode(p[K.adState])).encode() }
    }

    val savedGame: Flow<String?> = safe.map { it[K.save] }.distinctUntilChanged()

    val progress: Flow<Progress> = safe.map { p ->
        Progress(
            results = parseResults(p[K.results]),
            totalMoves = p[K.totalMoves] ?: 0L,
            totalSolved = p[K.totalSolved] ?: 0,
            dailyDays = parseLongs(p[K.dailyDays]).toSet(),
            lastDailyDay = p[K.lastDaily] ?: -1L,
            dailyStreak = p[K.streak] ?: 0,
            recentSignatures = parseLongs(p[K.recent]),
            hints = p[K.hints] ?: START_HINTS,
            unlockedIds = parseStrings(p[K.unlocked]).toSet(),
            challengeCleared = p[K.challenge] ?: 0,
            sparkCleared = p[K.spark] ?: 0,
            zenSolved = p[K.zen] ?: 0,
            rushBest = p[K.rushBest] ?: 0,
            rushRuns = p[K.rushRuns] ?: 0,
            rushTotal = p[K.rushTotal] ?: 0,
            seenTwists = parseStrings(p[K.seenTwists]).toSet()
        )
    }.distinctUntilChanged()

    suspend fun currentSettings(): Settings = runCatching { settings.first() }.getOrDefault(Settings())

    suspend fun currentSave(): String? = runCatching { safe.map { it[K.save] }.first() }.getOrNull()

    suspend fun currentProgress(): Progress = runCatching { progress.first() }.getOrDefault(Progress())

    suspend fun writeSave(encoded: String?) = runCatching {
        ds.edit { if (encoded == null) it.remove(K.save) else it[K.save] = encoded }
    }

    suspend fun updateProgress(transform: (Progress) -> Progress) = runCatching {
        ds.edit { p ->
            val cur = Progress(
                results = parseResults(p[K.results]),
                totalMoves = p[K.totalMoves] ?: 0L,
                totalSolved = p[K.totalSolved] ?: 0,
                dailyDays = parseLongs(p[K.dailyDays]).toSet(),
                lastDailyDay = p[K.lastDaily] ?: -1L,
                dailyStreak = p[K.streak] ?: 0,
                recentSignatures = parseLongs(p[K.recent]),
            hints = p[K.hints] ?: START_HINTS,
            unlockedIds = parseStrings(p[K.unlocked]).toSet(),
            challengeCleared = p[K.challenge] ?: 0,
            sparkCleared = p[K.spark] ?: 0,
            zenSolved = p[K.zen] ?: 0,
            rushBest = p[K.rushBest] ?: 0,
            rushRuns = p[K.rushRuns] ?: 0,
            rushTotal = p[K.rushTotal] ?: 0,
            seenTwists = parseStrings(p[K.seenTwists]).toSet()
            )
            val n = transform(cur)
            p[K.results] = n.results.entries.joinToString(";") { "${it.key}:${it.value.stars}:${it.value.bestMoves}" }
            p[K.totalMoves] = n.totalMoves
            p[K.totalSolved] = n.totalSolved
            p[K.dailyDays] = n.dailyDays.joinToString(",")
            p[K.lastDaily] = n.lastDailyDay
            p[K.streak] = n.dailyStreak
            p[K.recent] = n.recentSignatures.joinToString(",")
            p[K.hints] = n.hints
            p[K.unlocked] = n.unlockedIds.joinToString(",")
            p[K.challenge] = n.challengeCleared; p[K.spark] = n.sparkCleared; p[K.zen] = n.zenSolved
            p[K.rushBest] = n.rushBest; p[K.rushRuns] = n.rushRuns; p[K.rushTotal] = n.rushTotal
            p[K.seenTwists] = n.seenTwists.joinToString(",")
        }
    }

    suspend fun updateSettings(transform: (Settings) -> Settings) = runCatching {
        ds.edit { p ->
            val cur = Settings(
                sound = p[K.sound] ?: true, music = p[K.music] ?: true, haptics = p[K.haptics] ?: true,
                theme = ThemeId.values().firstOrNull { it.name == p[K.theme] } ?: ThemeId.ORCHID,
                animation = AnimationMode.values().firstOrNull { it.name == p[K.anim] } ?: AnimationMode.SMOOTH,
            howToSeen = p[K.howTo] ?: false,
            analytics = p[K.analytics] ?: true,
            notifications = p[K.notifications] ?: false,
            notifPrompted = p[K.notifPrompted] ?: false,
            rate = readRate(p)
            )
            val n = transform(cur)
            p[K.sound] = n.sound; p[K.music] = n.music; p[K.haptics] = n.haptics
            p[K.theme] = n.theme.name; p[K.anim] = n.animation.name; p[K.howTo] = n.howToSeen
            p[K.analytics] = n.analytics; p[K.notifications] = n.notifications; p[K.notifPrompted] = n.notifPrompted
            p[K.rateDone] = n.rate.done; p[K.rateShown] = n.rate.shownCount
            p[K.rateLastMs] = n.rate.lastShownMs; p[K.rateLastLevels] = n.rate.lastShownLevels
        }
    }

    /** Deletes saved game, statistics and level progress. Settings are kept. */
    suspend fun resetProgress() = runCatching {
        ds.edit { p ->
            listOf(K.save, K.results, K.dailyDays, K.recent).forEach { p.remove(it) }
            p.remove(K.hints); p.remove(K.challenge); p.remove(K.spark); p.remove(K.zen); p.remove(K.rushBest); p.remove(K.rushRuns); p.remove(K.rushTotal); p.remove(K.unlocked); p.remove(K.seenTwists); p.remove(K.totalMoves); p.remove(K.totalSolved); p.remove(K.lastDaily); p.remove(K.streak)
        }
    }

    private fun readRate(p: Preferences) = RateState(
        done = p[K.rateDone] ?: false, shownCount = p[K.rateShown] ?: 0,
        lastShownMs = p[K.rateLastMs] ?: 0L, lastShownLevels = p[K.rateLastLevels] ?: 0
    )

    private fun parseResults(s: String?): Map<Int, LevelResult> {
        if (s.isNullOrBlank()) return emptyMap()
        val out = HashMap<Int, LevelResult>()
        for (part in s.split(";")) {
            val f = part.split(":")
            if (f.size != 3) continue
            val n = f[0].toIntOrNull() ?: continue
            val st = f[1].toIntOrNull() ?: continue
            val mv = f[2].toIntOrNull() ?: continue
            out[n] = LevelResult(st.coerceIn(1, 3), mv)
        }
        return out
    }

    private fun parseStrings(s: String?): List<String> =
        if (s.isNullOrBlank()) emptyList() else s.split(",").filter { it.isNotBlank() }

    private fun parseLongs(s: String?): List<Long> =
        if (s.isNullOrBlank()) emptyList() else s.split(",").mapNotNull { it.toLongOrNull() }
}

