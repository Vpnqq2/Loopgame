package com.loopconnect.engine

/**
 * Persistent counters behind the ad limits. They are deliberately NOT cleared by "Reset progress",
 * otherwise the limits could be bypassed by resetting.
 */
data class AdState(
    val day: Long = -1,
    val rewardedToday: Int = 0,
    val interstitialsToday: Int = 0,
    val lastRewardedMs: Long = 0,
    val lastInterstitialMs: Long = 0,
    val levelsSinceInterstitial: Int = 0
) {
    /** Daily counters start again on a new calendar day. */
    fun forDay(today: Long): AdState =
        if (day == today) this else copy(day = today, rewardedToday = 0, interstitialsToday = 0)

    fun levelCompleted(): AdState = copy(levelsSinceInterstitial = levelsSinceInterstitial + 1)

    fun rewardedEarned(now: Long, today: Long): AdState =
        forDay(today).let { it.copy(rewardedToday = it.rewardedToday + 1, lastRewardedMs = now) }

    fun interstitialShown(now: Long, today: Long): AdState =
        forDay(today).let { it.copy(interstitialsToday = it.interstitialsToday + 1, lastInterstitialMs = now, levelsSinceInterstitial = 0) }

    fun encode(): String = listOf(day, rewardedToday, interstitialsToday, lastRewardedMs, lastInterstitialMs, levelsSinceInterstitial).joinToString(",")

    companion object {
        /** Corrupt data falls back to a clean state. */
        fun decode(s: String?): AdState = runCatching {
            val p = s!!.split(",")
            AdState(p[0].toLong(), p[1].toInt(), p[2].toInt(), p[3].toLong(), p[4].toLong(), p[5].toInt())
        }.getOrDefault(AdState())
    }
}

sealed interface RewardedStatus {
    data class Available(val leftToday: Int) : RewardedStatus
    data class Cooldown(val msLeft: Long) : RewardedStatus
    data object DailyLimit : RewardedStatus
}

/** Pure rules, easy to tune and to unit test. All limits are constants. */
object AdPolicy {
    // Rewarded "hint" ads: only on request, capped so nobody can farm impressions.
    const val REWARDED_PER_DAY = 3
    const val REWARDED_COOLDOWN_MS = 5 * 60_000L

    // Interstitials: only between levels, rarely, never for new players.
    const val FREE_LEVELS = 8              // no interstitials until this many levels are completed
    const val INTERSTITIAL_EVERY_LEVELS = 4
    const val INTERSTITIAL_PER_DAY = 4
    const val INTERSTITIAL_GAP_MS = 3 * 60_000L // also applies after a rewarded ad

    /** Time since [last]; a clock set backwards counts as "no time passed" so it cannot be abused. */
    private fun elapsed(now: Long, last: Long): Long = if (last <= 0L) Long.MAX_VALUE else (now - last).coerceAtLeast(0L)

    fun rewardedStatus(state: AdState, today: Long, now: Long): RewardedStatus {
        val s = state.forDay(today)
        if (s.rewardedToday >= REWARDED_PER_DAY) return RewardedStatus.DailyLimit
        val wait = REWARDED_COOLDOWN_MS - elapsed(now, s.lastRewardedMs)
        return if (wait > 0) RewardedStatus.Cooldown(wait) else RewardedStatus.Available(REWARDED_PER_DAY - s.rewardedToday)
    }

    fun canShowInterstitial(state: AdState, today: Long, now: Long, levelsCompleted: Int): Boolean {
        val s = state.forDay(today)
        return levelsCompleted >= FREE_LEVELS &&
            s.levelsSinceInterstitial >= INTERSTITIAL_EVERY_LEVELS &&
            s.interstitialsToday < INTERSTITIAL_PER_DAY &&
            elapsed(now, maxOf(s.lastInterstitialMs, s.lastRewardedMs)) >= INTERSTITIAL_GAP_MS
    }

    /** Load the next interstitial one level ahead so it never makes the player wait. */
    fun shouldPreloadInterstitial(state: AdState, today: Long, levelsCompleted: Int): Boolean {
        val s = state.forDay(today)
        return levelsCompleted + 1 >= FREE_LEVELS &&
            s.levelsSinceInterstitial + 1 >= INTERSTITIAL_EVERY_LEVELS &&
            s.interstitialsToday < INTERSTITIAL_PER_DAY
    }
}
