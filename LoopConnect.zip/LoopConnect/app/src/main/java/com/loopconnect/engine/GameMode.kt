package com.loopconnect.engine

enum class GameMode(val title: String, val tagline: String) {
    CLASSIC("Classic", "Campaign levels, earn up to 3 stars"),
    ZEN("Zen", "Relax. No timer, no pressure"),
    CHALLENGE("Challenge", "Solve each puzzle within a move limit"),
    RUSH("Rush", "Race the clock and solve as many as you can"),
    SPARK("Spark", "Wake the grid: only powered pieces can turn")
}

enum class ZenSize(val label: String, val w: Int, val h: Int) {
    SMALL("Small", 4, 4), MEDIUM("Medium", 6, 6), LARGE("Large", 8, 10);

    companion object {
        fun fromWidth(w: Int): ZenSize = values().firstOrNull { it.w == w } ?: MEDIUM
    }
}

/** Tunable rules for the extra game modes. */
object ModeRules {
    const val CHALLENGE_UNLOCK_LEVELS = 3   // classic levels needed to unlock Challenge
    const val RUSH_UNLOCK_LEVELS = 5        // classic levels needed to unlock Rush
    const val SPARK_UNLOCK_LEVELS = 3       // classic levels needed to unlock Spark
    const val RUSH_START_MS = 90_000L
    const val RUSH_BONUS_MS = 8_000L        // added for every solved puzzle
    const val RUSH_MAX_MS = 150_000L        // the time bank never grows beyond this
    const val RUSH_MAX_LEVEL = 41           // difficulty cap so puzzles stay solvable in seconds

    /** Challenge: the par solution plus some slack. */
    fun moveLimit(par: Int): Int = par + maxOf(2, par / 3)

    /** Rush ramps quickly: puzzle 1 is level 1, puzzle 2 is level 3, ... */
    fun rushDifficultyLevel(index: Int): Int = minOf(RUSH_MAX_LEVEL, 1 + (index - 1) * 2)
}
