package com.loopconnect.engine

enum class Objective(val title: String, val hint: String) {
    NETWORK("Connect all lines", "Join every piece into a single network"),
    LOOPS("Close every loop", "No loose ends: every piece must lie on a loop")
}

enum class Difficulty { EASY, MEDIUM, HARD;
    companion object {
        fun forLevel(n: Int) = when {
            n <= 30 -> EASY
            n <= 70 -> MEDIUM
            else -> HARD
        }
    }
}

/**
 * Everything needed to rebuild a level bit-for-bit. Fractions are stored as permille so the
 * spec can be saved as integers.
 */
data class LevelSpec(
    val number: Int,
    val width: Int,
    val height: Int,
    val objective: Objective,
    val maxDegree: Int,
    val fillPm: Int,
    val branchingPm: Int,
    val seed: Long,
    /** Picture id (see [Shapes.get]) for a picture level, or -1 for an ordinary random board. */
    val shapeId: Int = -1
)

class Level(val spec: LevelSpec, val solved: IntArray, val scramble: IntArray) {
    val width get() = spec.width
    val height get() = spec.height
    val size get() = solved.size

    /** The initial, scrambled board. */
    val initialMasks: IntArray = IntArray(solved.size) { Tile.rotateCw(solved[it], scramble[it]) }

    /** Minimum number of taps needed to reach the known solution. */
    val par: Int = solved.indices.sumOf { Tile.clicksToReach(initialMasks[it], solved[it]).coerceAtLeast(0) }

    /** Fingerprint of the solved layout, used to avoid repeating recent layouts. */
    val signature: Long by lazy {
        var h = -3750763034362895579L // FNV offset basis
        fun mixIn(v: Long) { h = (h xor v) * 1099511628211L }
        mixIn(spec.width.toLong()); mixIn(spec.height.toLong()); mixIn(spec.objective.ordinal.toLong())
        for (m in solved) mixIn(m.toLong())
        h
    }
}
