package com.loopconnect.engine

enum class Objective(val title: String, val hint: String) {
    NETWORK("Connect all lines", "Join every piece into a single network"),
    LOOPS("Close every loop", "No loose ends: every piece must lie on a loop")
}

enum class Difficulty { EASY, MEDIUM, HARD;
    companion object {
        fun forLevel(n: Int) = when {
            n <= 30 -> EASY
            n <= 70 -> MEDIUM
            else -> HARD
        }
    }
}

/**
 * Everything needed to rebuild a level bit-for-bit. Fractions are stored as permille so the
 * spec can be saved as integers.
 */
data class LevelSpec(
    val number: Int,
    val width: Int,
    val height: Int,
    val objective: Objective,
    val maxDegree: Int,
    val fillPm: Int,
    val branchingPm: Int,
    val seed: Long,
    /** Bit mask of [Twist]s this level uses (0 for an ordinary board). */
    val rules: Int = 0
)

/**
 * [locked] pieces never turn (they start in their solved orientation). [partner] links twin pieces: tapping
 * one turns both ([partner] holds the other index, or -1). [playable] is false for wall cells.
 */
class Level(
    val spec: LevelSpec,
    val solved: IntArray,
    val scramble: IntArray,
    val locked: BooleanArray = BooleanArray(solved.size),
    val partner: IntArray = IntArray(solved.size) { -1 },
    val playable: BooleanArray = BooleanArray(solved.size) { true }
) {
    val width get() = spec.width
    val height get() = spec.height
    val size get() = solved.size

    /** The initial, scrambled board. */
    val initialMasks: IntArray = IntArray(solved.size) { Tile.rotateCw(solved[it], scramble[it]) }

    /** Minimum number of taps needed to reach the known solution (a twin pair counts once). */
    val par: Int = run {
        var total = 0
        for (i in solved.indices) {
            val p = partner[i]
            if (p < 0) total += Tile.clicksToReach(initialMasks[i], solved[i]).coerceAtLeast(0)
            else if (i < p) total += pairTaps(initialMasks, solved, i, p).coerceAtLeast(0)
        }
        total
    }

    /** Fingerprint of the solved layout, used to avoid repeating recent layouts. */
    val signature: Long by lazy {
        var h = -3750763034362895579L // FNV offset basis
        fun mixIn(v: Long) { h = (h xor v) * 1099511628211L }
        mixIn(spec.width.toLong()); mixIn(spec.height.toLong()); mixIn(spec.objective.ordinal.toLong())
        for (m in solved) mixIn(m.toLong())
        h
    }
}

/** Taps that bring twin pieces [a] and [b] (which always turn together) to their solved shapes, or -1 if impossible. */
fun pairTaps(masks: IntArray, solved: IntArray, a: Int, b: Int): Int =
    (0..3).firstOrNull { t -> Tile.rotateCw(masks[a], t) == solved[a] && Tile.rotateCw(masks[b], t) == solved[b] } ?: -1
