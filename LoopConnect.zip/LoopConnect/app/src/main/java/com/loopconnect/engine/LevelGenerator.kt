package com.loopconnect.engine

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * Procedural level generation.
 *
 * 1. Grow a random connected network (spanning tree) with controllable branching.
 * 2. For LOOPS levels add edges until no tile has a loose end.
 * 3. Verify the solved board against the real rules.
 * 4. Scramble every tile by a random number of rotations.
 * 5. Independently verify with [Solver] before the level is returned.
 *
 * Everything is derived from [LevelSpec.seed], so a saved spec recreates the level exactly.
 */
object LevelGenerator {
    private const val GOLDEN = -7046029254386353131L

    /** splitmix64 */
    fun mix(x: Long): Long {
        var z = x + GOLDEN
        z = (z xor (z ushr 30)) * -4658895280553007687L
        z = (z xor (z ushr 27)) * -7723592293110705685L
        return z xor (z ushr 31)
    }

    /** Difficulty parameters for an arbitrary (unlimited) level number. The seed is the base seed. */
    fun specFor(levelNumber: Int): LevelSpec {
        val lv = max(1, levelNumber)
        val width = min(3 + (lv - 1) / 10, 8)
        val height = min(width + (lv - 1) / 25, 11)
        val objective = if (lv >= 8 && lv % 4 == 0) Objective.LOOPS else Objective.NETWORK
        val maxDegree = when {
            lv <= 6 -> 2
            lv <= 15 -> 3
            else -> 4
        }
        val fill = when {
            objective == Objective.LOOPS -> 1000
            lv <= 6 -> 750
            lv <= 15 -> 900
            else -> 1000 - ((lv / 7) % 3) * 80
        }
        val branching = min(950, 150 + lv * 9)
        return LevelSpec(lv, width, height, objective, maxDegree, fill, branching, mix(lv.toLong() * 7919L + 17L))
    }

    /**
     * The Classic campaign: steadily harder boards (see [specFor]) plus, from level 6, new rules that are taught one at
     * a time (see [Twist]): padlocked pieces, long winding routes, odd board shapes and twin pieces, and a loop level
     * every 4th level from level 8. Other modes keep using the plain [specFor] curve.
     */
    fun campaignSpec(levelNumber: Int): LevelSpec {
        val base = specFor(max(1, levelNumber))
        val rules = Twist.forLevel(base.number, base.objective)
        if (rules == 0) return base
        val spec = base.copy(rules = rules)
        // A winding route: thin pieces (no branches at all before level 30), low branching and a little more empty room.
        return if (Twist.has(rules, Twist.WINDING))
            spec.copy(maxDegree = if (base.number < 30) 2 else 3, fillPm = 800, branchingPm = 100)
        else spec
    }

    /** Challenge uses the campaign difficulty curve but different layouts. */
    fun challengeSpec(n: Int): LevelSpec = specFor(n).let { it.copy(seed = mix(it.seed xor 0x5C4A11E96EL)) }

    /** Spark follows the campaign curve with its own layouts. */
    fun sparkSpec(n: Int): LevelSpec = specFor(max(1, n)).let { it.copy(seed = mix(it.seed xor 0x57A4C0DEL)) }

    /** Zen: the player picks the size; every puzzle is fresh. */
    fun zenSpec(size: ZenSize, counter: Int, entropy: Long): LevelSpec = LevelSpec(
        number = counter, width = size.w, height = size.h,
        objective = if (counter % 3 == 0) Objective.LOOPS else Objective.NETWORK,
        maxDegree = 4, fillPm = 1000, branchingPm = 450 + size.ordinal * 150,
        seed = mix(entropy + counter * 31L)
    )

    /** Rush puzzle [index] (1-based) of a session. */
    fun rushSpec(index: Int, sessionSeed: Long): LevelSpec =
        specFor(ModeRules.rushDifficultyLevel(index)).copy(number = index, seed = mix(sessionSeed + index * 7919L))

    /** The one puzzle everybody gets for a given calendar day (epoch day). */
    fun dailySpec(epochDay: Long): LevelSpec {
        val width = 5 + (epochDay % 3).toInt().let { if (it < 0) it + 3 else it }
        return LevelSpec(
            number = 0, width = width, height = width + 1,
            objective = if (Math.floorMod(epochDay, 2L) == 0L) Objective.LOOPS else Objective.NETWORK,
            maxDegree = 4, fillPm = 1000, branchingPm = 600,
            seed = mix(epochDay * 104729L + 99991L)
        )
    }

    /**
     * Creates a verified level from a base spec. Tries successive derived seeds until generation
     * succeeds, the layout is not in [avoid], and the independent solver agrees. The returned
     * level's spec carries the effective seed and can be passed to [build] to recreate it.
     */
    fun create(base: LevelSpec, avoid: Set<Long> = emptySet()): Level {
        var fallback: Level? = null
        for (attempt in 0 until 400) {
            val spec = base.copy(
                seed = if (attempt == 0) base.seed else mix(base.seed + attempt),
                maxDegree = min(4, base.maxDegree + attempt / 25)
            )
            val level = build(spec) ?: continue
            if (!verify(level)) continue
            if (level.signature in avoid && attempt < 60) { fallback = fallback ?: level; continue }
            return level
        }
        if (fallback != null) return fallback
        // A rare combination of rules and board size that never worked: play the plain board instead of failing.
        if (base.rules != 0) return create(base.copy(rules = 0), avoid)
        error("Level generation failed for ${base.number}")
    }

    /**
     * Spark level: the solved layout of [build], but scrambled so that every piece (except the
     * power source) still has the side that faces its parent in the power tree open. Waking the
     * pieces in breadth-first order from the source then always works, whatever the player did.
     */
    fun buildSpark(spec: LevelSpec): Level? {
        val base = build(spec) ?: return null
        val w = spec.width
        val h = spec.height
        val n = w * h
        val solved = base.solved
        val src = Spark.sourceOf(solved, w, h)
        if (src < 0) return null
        val parentSide = IntArray(n)
        val seen = BooleanArray(n)
        val queue = ArrayDeque<Int>()
        seen[src] = true
        queue.addLast(src)
        while (queue.isNotEmpty()) {
            val c = queue.removeFirst()
            for (d in Dir.ALL) {
                if (!Rules.isMatched(solved, w, h, c, d)) continue
                val nb = Rules.neighbor(c, d, w, h)
                if (!seen[nb]) { seen[nb] = true; parentSide[nb] = Dir.opposite(d); queue.addLast(nb) }
            }
        }
        if (seen.count { it } != solved.count { it != 0 }) return null
        val rnd = Random(mix(spec.seed xor 0x5EA4C1L))
        for (retry in 0 until 20) {
            val scramble = IntArray(n) { i ->
                when {
                    solved[i] == 0 -> 0
                    i == src -> rnd.nextInt(4)
                    else -> {
                        val options = (0..3).filter { Tile.has(Tile.rotateCw(solved[i], it), parentSide[i]) }
                        options[rnd.nextInt(options.size)]
                    }
                }
            }
            val level = Level(spec, solved.copyOf(), scramble)
            if (!Rules.isSolved(level.initialMasks, w, h, spec.objective) && level.par > 0) return level
        }
        return null
    }

    /** Plays the level the way a patient player would (always turn a powered piece that is wrong) and checks it ends solved. */
    fun verifySpark(level: Level): Boolean {
        val w = level.width
        val h = level.height
        if (!Rules.isSolved(level.solved, w, h, level.spec.objective)) return false
        val src = Spark.sourceOf(level)
        if (src < 0) return false
        val b = PuzzleBoard(level, sparkSource = src)
        var guard = 0
        while (guard++ < level.size * 2) {
            val i = (0 until level.size).firstOrNull { b.isAwake(it) && b.mask(it) != level.solved[it] } ?: break
            var taps = 0
            while (b.mask(i) != level.solved[i] && taps++ < 4) b.rotate(i)
        }
        return b.masksCopy().contentEquals(level.solved)
    }

    /** Creates a verified Spark level; like [create], tries successive derived seeds. */
    fun createSpark(base: LevelSpec): Level {
        for (attempt in 0 until 400) {
            val spec = base.copy(
                seed = if (attempt == 0) base.seed else mix(base.seed + attempt),
                maxDegree = min(4, base.maxDegree + attempt / 25)
            )
            val level = buildSpark(spec) ?: continue
            if (verifySpark(level)) return level
        }
        error("Spark level generation failed for ${base.number}")
    }

    fun forLevel(levelNumber: Int, avoid: Set<Long> = emptySet()): Level = create(campaignSpec(levelNumber), avoid)

    fun daily(epochDay: Long): Level = create(dailySpec(epochDay))

    /** Level is valid when its solution obeys the rules, is reachable by rotation, and the solver agrees. */
    fun verify(level: Level): Boolean {
        val w = level.width
        val h = level.height
        if (!Rules.isSolved(level.solved, w, h, level.spec.objective)) return false
        for (i in level.solved.indices) if (Tile.clicksToReach(level.initialMasks[i], level.solved[i]) < 0) return false
        if (Rules.isSolved(level.initialMasks, w, h, level.spec.objective)) return false
        val result = Solver.solve(level)
        if (result.provenUnsolvable) return false
        val found = result.masks
        if (found != null && !Rules.isSolved(found, w, h, level.spec.objective)) return false
        return verifyPlay(level)
    }

    /**
     * Plays the level by tapping, so locks and twin pieces are checked with the real board rules: tap every wrong
     * piece the number of times it needs and make sure the known solution is reached.
     */
    fun verifyPlay(level: Level): Boolean {
        val b = PuzzleBoard(level)
        for (i in 0 until level.size) {
            if (b.mask(i) == level.solved[i]) continue
            if (level.locked[i]) return false
            repeat(b.tapsNeeded(i)) { b.rotate(i) }
        }
        return b.masksCopy().contentEquals(level.solved)
    }

    /** Pure, deterministic build for an exact spec. Returns null if this seed does not give a usable board. */
    fun build(spec: LevelSpec): Level? {
        val w = spec.width
        val h = spec.height
        val n = w * h
        if (w < 3 || h < 3) return null
        val rnd = Random(spec.seed)
        // Wall cells (odd board shapes). Without the SHAPE rule every cell is playable and nothing below changes.
        val playable = if (Twist.has(spec.rules, Twist.SHAPE)) Shapes.pick(w, h, spec.seed) else BooleanArray(n) { true }
        val cells = (0 until n).filter { playable[it] }
        val target = max(2, ceil(cells.size * spec.fillPm / 1000.0).toInt())
        val masks = IntArray(n)
        val inNet = BooleanArray(n)
        val frontier = ArrayList<Int>()

        fun pushEdges(c: Int) {
            for (di in 0..3) {
                val nb = Rules.neighbor(c, Dir.ALL[di], w, h)
                if (nb >= 0 && !inNet[nb] && playable[nb]) frontier.add(c * 4 + di)
            }
        }

        val start = cells[rnd.nextInt(cells.size)]
        inNet[start] = true
        var count = 1
        pushEdges(start)
        while (count < target && frontier.isNotEmpty()) {
            val idx = if (rnd.nextInt(1000) < spec.branchingPm) rnd.nextInt(frontier.size) else frontier.size - 1
            val e = frontier[idx]
            frontier[idx] = frontier[frontier.size - 1]
            frontier.removeAt(frontier.size - 1)
            val c = e / 4
            val d = Dir.ALL[e % 4]
            val nb = Rules.neighbor(c, d, w, h)
            if (inNet[nb]) continue
            if (Tile.degree(masks[c]) >= spec.maxDegree) continue
            masks[c] = masks[c] or d
            masks[nb] = masks[nb] or Dir.opposite(d)
            inNet[nb] = true
            count++
            pushEdges(nb)
        }
        // Boards may stop a little short of their target.
        if (count < max(2, (target * 0.85).toInt())) return null

        if (spec.objective == Objective.LOOPS) {
            if (count != cells.size) return null
            // Remove every loose end by linking it to an unconnected neighbour. Degrees only grow.
            while (true) {
                val leaves = (0 until n).filter { Tile.degree(masks[it]) == 1 }.shuffled(rnd)
                if (leaves.isEmpty()) break
                for (leaf in leaves) {
                    if (Tile.degree(masks[leaf]) != 1) continue
                    val options = Dir.ALL.filter { d ->
                        val nb = Rules.neighbor(leaf, d, w, h)
                        !Tile.has(masks[leaf], d) && nb >= 0 && playable[nb]
                    }
                    if (options.isEmpty()) return null
                    val d = options[rnd.nextInt(options.size)]
                    val nb = Rules.neighbor(leaf, d, w, h)
                    masks[leaf] = masks[leaf] or d
                    masks[nb] = masks[nb] or Dir.opposite(d)
                }
            }
        }

        if (!Rules.isSolved(masks, w, h, spec.objective)) return null

        // New rules: padlocked pieces and twin pieces. They use their own random stream, so boards without
        // these rules are generated exactly as before.
        val locked = BooleanArray(n)
        val partner = IntArray(n) { -1 }
        val trnd = Random(mix(spec.seed xor 0x70C4L))
        if (Twist.has(spec.rules, Twist.LOCKS)) {
            val candidates = (0 until n).filter { Tile.degree(masks[it]) in 1..3 }.shuffled(trnd)
            val occupied = masks.count { it != 0 }
            val sinceIntro = max(0, spec.number - Twist.LOCKS.introLevel)
            val share = min(250, 110 + sinceIntro * 4)
            val want = ceil(occupied * share / 1000.0).toInt().coerceIn(1, 8)
            for (c in candidates.take(want)) locked[c] = true
            if (locked.none { it }) return null
        }
        if (Twist.has(spec.rules, Twist.TWINS)) {
            val eligible = (0 until n).filter { !locked[it] && masks[it] != 0 && Tile.rotateCw(masks[it]) != masks[it] }.shuffled(trnd)
            val wantPairs = (1 + max(0, spec.number - Twist.TWINS.introLevel) / 8).coerceIn(1, 4)
            var pairs = 0
            fun dist(a: Int, b: Int) = abs(a % w - b % w) + abs(a / w - b / w)
            for (a in eligible) {
                if (pairs >= wantPairs) break
                if (partner[a] >= 0) continue
                val free = eligible.filter { it != a && partner[it] < 0 }
                val near = free.filter { dist(a, it) in 2..4 }
                val b = (if (near.isNotEmpty()) near else free.filter { dist(a, it) in 1..6 }).firstOrNull() ?: continue
                partner[a] = b
                partner[b] = a
                pairs++
            }
            if (pairs == 0) return null
        }

        // Scramble; make sure the starting board is not already a solution.
        for (retry in 0 until 20) {
            val scramble = IntArray(n) { if (masks[it] == 0 || locked[it]) 0 else rnd.nextInt(4) }
            // Twins share one tap count, so they always stay in step with each other and the solution stays reachable.
            for (a in 0 until n) {
                val b = partner[a]
                if (b > a) {
                    val taps = 1 + rnd.nextInt(3)
                    scramble[a] = (4 - taps) % 4
                    scramble[b] = scramble[a]
                }
            }
            val level = Level(spec, masks.copyOf(), scramble, locked.copyOf(), partner.copyOf(), playable)
            if (!Rules.isSolved(level.initialMasks, w, h, spec.objective) && level.par > 0) return level
        }
        return null
    }
}
