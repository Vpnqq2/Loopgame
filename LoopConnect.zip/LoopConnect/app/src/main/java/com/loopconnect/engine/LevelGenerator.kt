package com.loopconnect.engine

import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * Procedural level generation.
 *
 * 1. Grow a random connected network (spanning tree) with controllable branching.
 * 2. For LOOPS levels add edges until no tile has a loose end.
 * 3. Verify the solved board against the real rules.
 * 4. Scramble every tile by a random number of rotations.
 * 5. Independently verify with [Solver] before the level is returned.
 *
 * Everything is derived from [LevelSpec.seed], so a saved spec recreates the level exactly.
 */
object LevelGenerator {
    private const val GOLDEN = -7046029254386353131L

    /** splitmix64 */
    fun mix(x: Long): Long {
        var z = x + GOLDEN
        z = (z xor (z ushr 30)) * -4658895280553007687L
        z = (z xor (z ushr 27)) * -7723592293110705685L
        return z xor (z ushr 31)
    }

    /** Difficulty parameters for an arbitrary (unlimited) level number. The seed is the base seed. */
    fun specFor(levelNumber: Int): LevelSpec {
        val lv = max(1, levelNumber)
        val width = min(3 + (lv - 1) / 10, 8)
        val height = min(width + (lv - 1) / 25, 11)
        val objective = if (lv >= 8 && lv % 4 == 0) Objective.LOOPS else Objective.NETWORK
        val maxDegree = when {
            lv <= 6 -> 2
            lv <= 15 -> 3
            else -> 4
        }
        val fill = when {
            objective == Objective.LOOPS -> 1000
            lv <= 6 -> 750
            lv <= 15 -> 900
            else -> 1000 - ((lv / 7) % 3) * 80
        }
        val branching = min(950, 150 + lv * 9)
        return LevelSpec(lv, width, height, objective, maxDegree, fill, branching, mix(lv.toLong() * 7919L + 17L))
    }

    /** The one puzzle everybody gets for a given calendar day (epoch day). */
    fun dailySpec(epochDay: Long): LevelSpec {
        val width = 5 + (epochDay % 3).toInt().let { if (it < 0) it + 3 else it }
        return LevelSpec(
            number = 0, width = width, height = width + 1,
            objective = if (Math.floorMod(epochDay, 2L) == 0L) Objective.LOOPS else Objective.NETWORK,
            maxDegree = 4, fillPm = 1000, branchingPm = 600,
            seed = mix(epochDay * 104729L + 99991L)
        )
    }

    /**
     * Creates a verified level from a base spec. Tries successive derived seeds until generation
     * succeeds, the layout is not in [avoid], and the independent solver agrees. The returned
     * level's spec carries the effective seed and can be passed to [build] to recreate it.
     */
    fun create(base: LevelSpec, avoid: Set<Long> = emptySet()): Level {
        var fallback: Level? = null
        for (attempt in 0 until 400) {
            val spec = base.copy(
                seed = if (attempt == 0) base.seed else mix(base.seed + attempt),
                maxDegree = min(4, base.maxDegree + attempt / 25)
            )
            val level = build(spec) ?: continue
            if (!verify(level)) continue
            if (level.signature in avoid && attempt < 60) { fallback = fallback ?: level; continue }
            return level
        }
        return fallback ?: error("Level generation failed for ${base.number}")
    }

    fun forLevel(levelNumber: Int, avoid: Set<Long> = emptySet()): Level = create(specFor(levelNumber), avoid)

    fun daily(epochDay: Long): Level = create(dailySpec(epochDay))

    /** Level is valid when its solution obeys the rules, is reachable by rotation, and the solver agrees. */
    fun verify(level: Level): Boolean {
        val w = level.width
        val h = level.height
        if (!Rules.isSolved(level.solved, w, h, level.spec.objective)) return false
        for (i in level.solved.indices) if (Tile.clicksToReach(level.initialMasks[i], level.solved[i]) < 0) return false
        if (Rules.isSolved(level.initialMasks, w, h, level.spec.objective)) return false
        val result = Solver.solve(level)
        if (result.provenUnsolvable) return false
        val found = result.masks
        if (found != null && !Rules.isSolved(found, w, h, level.spec.objective)) return false
        return true
    }

    /** Pure, deterministic build for an exact spec. Returns null if this seed does not give a usable board. */
    fun build(spec: LevelSpec): Level? {
        val w = spec.width
        val h = spec.height
        val n = w * h
        if (w < 3 || h < 3) return null
        val rnd = Random(spec.seed)
        val target = max(2, ceil(n * spec.fillPm / 1000.0).toInt())
        val masks = IntArray(n)
        val inNet = BooleanArray(n)
        val frontier = ArrayList<Int>()

        fun pushEdges(c: Int) {
            for (di in 0..3) {
                val nb = Rules.neighbor(c, Dir.ALL[di], w, h)
                if (nb >= 0 && !inNet[nb]) frontier.add(c * 4 + di)
            }
        }

        val start = rnd.nextInt(n)
        inNet[start] = true
        var count = 1
        pushEdges(start)
        while (count < target && frontier.isNotEmpty()) {
            val idx = if (rnd.nextInt(1000) < spec.branchingPm) rnd.nextInt(frontier.size) else frontier.size - 1
            val e = frontier[idx]
            frontier[idx] = frontier[frontier.size - 1]
            frontier.removeAt(frontier.size - 1)
            val c = e / 4
            val d = Dir.ALL[e % 4]
            val nb = Rules.neighbor(c, d, w, h)
            if (inNet[nb]) continue
            if (Tile.degree(masks[c]) >= spec.maxDegree) continue
            masks[c] = masks[c] or d
            masks[nb] = masks[nb] or Dir.opposite(d)
            inNet[nb] = true
            count++
            pushEdges(nb)
        }
        if (count < max(2, (target * 0.85).toInt())) return null

        if (spec.objective == Objective.LOOPS) {
            if (count != n) return null
            // Remove every loose end by linking it to an unconnected neighbour. Degrees only grow.
            while (true) {
                val leaves = (0 until n).filter { Tile.degree(masks[it]) == 1 }.shuffled(rnd)
                if (leaves.isEmpty()) break
                for (leaf in leaves) {
                    if (Tile.degree(masks[leaf]) != 1) continue
                    val options = Dir.ALL.filter { d ->
                        !Tile.has(masks[leaf], d) && Rules.neighbor(leaf, d, w, h) >= 0
                    }
                    if (options.isEmpty()) return null
                    val d = options[rnd.nextInt(options.size)]
                    val nb = Rules.neighbor(leaf, d, w, h)
                    masks[leaf] = masks[leaf] or d
                    masks[nb] = masks[nb] or Dir.opposite(d)
                }
            }
        }

        if (!Rules.isSolved(masks, w, h, spec.objective)) return null

        // Scramble; make sure the starting board is not already a solution.
        for (retry in 0 until 20) {
            val scramble = IntArray(n) { if (masks[it] == 0) 0 else rnd.nextInt(4) }
            val level = Level(spec, masks.copyOf(), scramble)
            if (!Rules.isSolved(level.initialMasks, w, h, spec.objective) && level.par > 0) return level
        }
        return null
    }
}
