package com.loopconnect.engine

import kotlin.math.max

const val START_HINTS = 3
const val MAX_HINTS = 9
const val LEVELS_PER_HINT = 3
const val WEEK_STREAK_HINTS = 2
const val AD_HINTS = 1

object Scoring {
    fun stars(moves: Int, par: Int): Int = when {
        moves <= par -> 3
        moves <= par + max(2, par / 2) -> 2
        else -> 1
    }
}

data class LevelResult(val stars: Int, val bestMoves: Int)

data class Progress(
    val results: Map<Int, LevelResult> = emptyMap(),
    val totalMoves: Long = 0,
    val totalSolved: Int = 0,
    val dailyDays: Set<Long> = emptySet(),
    val lastDailyDay: Long = -1,
    val dailyStreak: Int = 0,
    val recentSignatures: List<Long> = emptyList(),
    val hints: Int = START_HINTS
) {
    val levelsCompleted: Int get() = results.size

    /** Levels unlock one after another; unlimited. */
    val highestUnlocked: Int
        get() {
            var n = 0
            while (results.containsKey(n + 1)) n++
            return n + 1
        }

    val perfectLevels: Int get() = results.values.count { it.stars == 3 }

    fun isUnlocked(level: Int) = level in 1..highestUnlocked
    fun isCompleted(level: Int) = results.containsKey(level)

    /** Streak that is still alive on [today]. */
    fun streakOn(today: Long): Int = if (lastDailyDay >= today - 1) dailyStreak else 0

    fun withMoves(count: Int) = copy(totalMoves = totalMoves + count)

    fun withHints(delta: Int) = copy(hints = (hints + delta).coerceIn(0, MAX_HINTS))

    fun spendHint() = if (hints > 0) copy(hints = hints - 1) else this

    private fun grant(gain: Int) = if (hints >= MAX_HINTS) hints else minOf(MAX_HINTS, hints + gain)

    /** Hints are earned by progress: one per 3 newly completed levels, one for a first 3-star result. */
    fun withLevelCompleted(level: Int, moves: Int, stars: Int): Progress {
        val old = results[level]
        val merged = if (old == null) LevelResult(stars, moves)
        else LevelResult(max(old.stars, stars), minOf(old.bestMoves, moves))
        var gain = 0
        if (old == null && (results.size + 1) % LEVELS_PER_HINT == 0) gain += 1
        if (stars == 3 && (old == null || old.stars < 3)) gain += 1
        return copy(results = results + (level to merged), totalSolved = totalSolved + 1, hints = grant(gain))
    }

    fun withDailyCompleted(day: Long): Progress {
        if (day in dailyDays) return copy(totalSolved = totalSolved + 1)
        val streak = if (lastDailyDay == day - 1) dailyStreak + 1 else 1
        val newStreak = if (day >= lastDailyDay) streak else dailyStreak
        val gain = if (day >= lastDailyDay && newStreak % 7 == 0) WEEK_STREAK_HINTS else 0
        return copy(
            dailyDays = dailyDays + day,
            lastDailyDay = max(lastDailyDay, day),
            dailyStreak = newStreak,
            totalSolved = totalSolved + 1,
            hints = grant(gain)
        )
    }

    fun withSignature(sig: Long, keep: Int = 40) =
        copy(recentSignatures = (recentSignatures.filter { it != sig } + sig).takeLast(keep))
}

data class Achievement(val id: String, val title: String, val description: String, val goal: Int,
                       val value: (Progress) -> Int) {
    fun unlocked(p: Progress) = value(p) >= goal
}

object Achievements {
    val all = listOf(
        Achievement("first", "First Steps", "Complete 5 levels", 5) { it.levelsCompleted },
        Achievement("master", "Solution Master", "Complete 25 levels", 25) { it.levelsCompleted },
        Achievement("loop", "Loop Expert", "Complete 50 levels", 50) { it.levelsCompleted },
        Achievement("daily", "Daily Player", "Complete 7 daily puzzles", 7) { it.dailyDays.size },
        Achievement("perfect", "Perfectionist", "Earn 3 stars on 10 levels", 10) { it.perfectLevels },
        Achievement("moves", "Tapper", "Make 1,000 moves", 1000) { it.totalMoves.coerceAtMost(1000).toInt() }
    )
}
