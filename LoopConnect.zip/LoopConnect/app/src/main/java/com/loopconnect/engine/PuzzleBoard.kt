package com.loopconnect.engine

data class Hint(val tile: Int, val taps: Int)

/** Mutable game state for one level: tile rotations, move history, undo, restart and hints. */
class PuzzleBoard(
    val level: Level,
    masks: IntArray = level.initialMasks.copyOf(),
    history: List<Int> = emptyList(),
    /** Index of the power source in Spark mode, or -1 for every other mode. */
    val sparkSource: Int = -1
) {
    val width get() = level.width
    val height get() = level.height
    private val current = masks.copyOf()
    private val moveLog = ArrayList<Int>(history)

    /** Spark mode: pieces that have ever been connected to the source. Only these can be turned. */
    private val awake = BooleanArray(level.size)

    init { if (sparkSource >= 0) rebuildAwake() }

    private fun rebuildAwake() {
        java.util.Arrays.fill(awake, false)
        val m = level.initialMasks.copyOf()
        wake(m)
        for (i in moveLog) { m[i] = Tile.rotateCw(m[i]); wake(m) }
    }

    /** Marks every piece connected to the source (through matched sides) as awake. */
    private fun wake(m: IntArray) {
        if (sparkSource !in m.indices || m[sparkSource] == 0) return
        val seen = BooleanArray(m.size)
        val stack = ArrayDeque<Int>()
        seen[sparkSource] = true
        stack.addLast(sparkSource)
        while (stack.isNotEmpty()) {
            val c = stack.removeLast()
            awake[c] = true
            for (d in Dir.ALL) {
                if (!Rules.isMatched(m, width, height, c, d)) continue
                val nb = Rules.neighbor(c, d, width, height)
                if (!seen[nb]) { seen[nb] = true; stack.addLast(nb) }
            }
        }
    }

    /** True when piece [i] may be turned (always true outside Spark mode). */
    fun isAwake(i: Int): Boolean = sparkSource < 0 || awake[i]
    val awakeCount: Int get() = if (sparkSource < 0) 0 else awake.count { it }
    fun awakeCopy(): BooleanArray? = if (sparkSource < 0) null else awake.copyOf()

    val moves: Int get() = moveLog.size
    val canUndo: Boolean get() = moveLog.isNotEmpty()

    fun mask(i: Int): Int = current[i]
    fun masksCopy(): IntArray = current.copyOf()
    fun historyCopy(): List<Int> = moveLog.toList()

    /**
     * Rotate tile [i] 90 degrees clockwise. Empty and fully symmetric tiles ignore taps, locked tiles never
     * turn, and a twin turns together with its partner.
     */
    fun rotate(i: Int): Boolean {
        if (i !in current.indices) return false
        if (sparkSource >= 0 && !awake[i]) return false
        if (level.locked[i]) return false
        val p = level.partner[i]
        val m = current[i]
        val moves = Tile.rotateCw(m) != m || (p >= 0 && Tile.rotateCw(current[p]) != current[p])
        if (!moves) return false
        current[i] = Tile.rotateCw(m)
        if (p >= 0) current[p] = Tile.rotateCw(current[p])
        moveLog.add(i)
        if (sparkSource >= 0) wake(current)
        return true
    }

    /** Undo the last rotation; returns the tile that was rotated back, or null. */
    fun undo(): Int? {
        if (moveLog.isEmpty()) return null
        val i = moveLog.removeAt(moveLog.size - 1)
        current[i] = Tile.rotateCcw(current[i])
        val p = level.partner[i]
        if (p >= 0) current[p] = Tile.rotateCcw(current[p])
        if (sparkSource >= 0) rebuildAwake()
        return i
    }

    fun restart() {
        level.initialMasks.copyInto(current)
        moveLog.clear()
        if (sparkSource >= 0) rebuildAwake()
    }

    fun isSolved(): Boolean = Rules.isSolved(current, width, height, level.spec.objective)

    val occupied: Int get() = Rules.occupiedCount(current)
    fun satisfied(): Int = Rules.satisfiedCount(current, width, height)

    /** Taps needed to bring tile [i] to its solution orientation (a twin and its partner share the same taps). */
    fun tapsNeeded(i: Int): Int {
        val p = level.partner[i]
        return if (p < 0) Tile.clicksToReach(current[i], level.solved[i]).coerceAtLeast(0)
        else pairTaps(current, level.solved, i, p).coerceAtLeast(0)
    }

    /** Points at a tile that is not yet in its solution orientation. */
    fun hint(): Hint? {
        if (isSolved()) return null
        val wrong = current.indices.filter { current[it] != level.solved[it] && isAwake(it) && !level.locked[it] }
        if (wrong.isEmpty()) return null
        // Prefer tiles that currently have a dangling side so the hint is visibly useful.
        val pick = wrong.firstOrNull { !Rules.tileSatisfied(current, width, height, it) } ?: wrong.first()
        return Hint(pick, tapsNeeded(pick))
    }
}
