package com.loopconnect.engine

data class Hint(val tile: Int, val taps: Int)

/** Mutable game state for one level: tile rotations, move history, undo, restart and hints. */
class PuzzleBoard(
    val level: Level,
    masks: IntArray = level.initialMasks.copyOf(),
    history: List<Int> = emptyList()
) {
    val width get() = level.width
    val height get() = level.height
    private val current = masks.copyOf()
    private val moveLog = ArrayList<Int>(history)

    val moves: Int get() = moveLog.size
    val canUndo: Boolean get() = moveLog.isNotEmpty()

    fun mask(i: Int): Int = current[i]
    fun masksCopy(): IntArray = current.copyOf()
    fun historyCopy(): List<Int> = moveLog.toList()

    /** Rotate tile [i] 90 degrees clockwise. Empty and fully symmetric tiles ignore taps. */
    fun rotate(i: Int): Boolean {
        if (i !in current.indices) return false
        val m = current[i]
        if (Tile.rotateCw(m) == m) return false
        current[i] = Tile.rotateCw(m)
        moveLog.add(i)
        return true
    }

    /** Undo the last rotation; returns the tile that was rotated back, or null. */
    fun undo(): Int? {
        if (moveLog.isEmpty()) return null
        val i = moveLog.removeAt(moveLog.size - 1)
        current[i] = Tile.rotateCcw(current[i])
        return i
    }

    fun restart() {
        level.initialMasks.copyInto(current)
        moveLog.clear()
    }

    fun isSolved(): Boolean = Rules.isSolved(current, width, height, level.spec.objective)

    val occupied: Int get() = Rules.occupiedCount(current)
    fun satisfied(): Int = Rules.satisfiedCount(current, width, height)

    /** Taps needed to bring tile [i] to its solution orientation. */
    fun tapsNeeded(i: Int): Int = Tile.clicksToReach(current[i], level.solved[i]).coerceAtLeast(0)

    /** Points at a tile that is not yet in its solution orientation. */
    fun hint(): Hint? {
        if (isSolved()) return null
        val wrong = current.indices.filter { current[it] != level.solved[it] }
        if (wrong.isEmpty()) return null
        // Prefer tiles that currently have a dangling side so the hint is visibly useful.
        val pick = wrong.firstOrNull { !Rules.tileSatisfied(current, width, height, it) } ?: wrong.first()
        return Hint(pick, tapsNeeded(pick))
    }
}
