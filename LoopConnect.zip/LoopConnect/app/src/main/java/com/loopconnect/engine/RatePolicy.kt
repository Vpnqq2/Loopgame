package com.loopconnect.engine

/** Persistent counters behind the "rate this game" card. */
data class RateState(
    val done: Boolean = false,
    val shownCount: Int = 0,
    val lastShownMs: Long = 0,
    val lastShownLevels: Int = 0
)

/**
 * Decides when the rate card may appear. It is deliberately rare and polite:
 * only after a win, never on first launch, never twice in one session, at most 3 times in total.
 */
object RatePolicy {
    const val MIN_LEVELS = 6
    const val MAX_SHOWS = 3
    const val MIN_LEVELS_BETWEEN = 5
    const val MIN_GAP_MS = 3L * 24 * 60 * 60 * 1000

    fun shouldShow(
        s: RateState, levelsCompleted: Int, now: Long,
        wonThisSession: Boolean, shownThisSession: Boolean, otherPromptPending: Boolean
    ): Boolean {
        if (s.done || shownThisSession || otherPromptPending || !wonThisSession) return false
        if (s.shownCount >= MAX_SHOWS || levelsCompleted < MIN_LEVELS) return false
        if (s.shownCount == 0) return true
        val clockBack = now < s.lastShownMs
        if (!clockBack && now - s.lastShownMs < MIN_GAP_MS) return false
        return levelsCompleted - s.lastShownLevels >= MIN_LEVELS_BETWEEN
    }
}
