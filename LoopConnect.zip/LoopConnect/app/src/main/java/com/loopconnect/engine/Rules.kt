package com.loopconnect.engine

/** The actual game rules. Used by the board, the generator and the solver. */
object Rules {
    fun neighbor(i: Int, dir: Int, w: Int, h: Int): Int {
        val x = i % w + Dir.dx(dir)
        val y = i / w + Dir.dy(dir)
        return if (x in 0 until w && y in 0 until h) y * w + x else -1
    }

    /** True if side [dir] of tile [i] is open and the neighbour has the matching opposite side open. */
    fun isMatched(masks: IntArray, w: Int, h: Int, i: Int, dir: Int): Boolean {
        if (!Tile.has(masks[i], dir)) return false
        val nb = neighbor(i, dir, w, h)
        return nb >= 0 && Tile.has(masks[nb], Dir.opposite(dir))
    }

    /** A non-empty tile whose every open side is matched. */
    fun tileSatisfied(masks: IntArray, w: Int, h: Int, i: Int): Boolean {
        if (masks[i] == 0) return false
        return Dir.ALL.all { d -> !Tile.has(masks[i], d) || isMatched(masks, w, h, i, d) }
    }

    fun occupiedCount(masks: IntArray): Int = masks.count { it != 0 }

    fun satisfiedCount(masks: IntArray, w: Int, h: Int): Int =
        masks.indices.count { tileSatisfied(masks, w, h, it) }

    /** All non-empty tiles form one connected network (through matched sides). */
    fun isConnected(masks: IntArray, w: Int, h: Int): Boolean {
        val start = masks.indexOfFirst { it != 0 }
        if (start < 0) return false
        val seen = BooleanArray(masks.size)
        val stack = ArrayDeque<Int>()
        stack.addLast(start)
        seen[start] = true
        var count = 1
        while (stack.isNotEmpty()) {
            val c = stack.removeLast()
            for (d in Dir.ALL) {
                if (!isMatched(masks, w, h, c, d)) continue
                val nb = neighbor(c, d, w, h)
                if (!seen[nb]) {
                    seen[nb] = true
                    count++
                    stack.addLast(nb)
                }
            }
        }
        return count == occupiedCount(masks)
    }

    /**
     * Objective check.
     * NETWORK: every side matched and everything is one connected network.
     * LOOPS:   additionally no loose ends, so every tile lies on a closed loop or between loops.
     */
    fun isSolved(masks: IntArray, w: Int, h: Int, objective: Objective): Boolean {
        if (occupiedCount(masks) == 0) return false
        for (i in masks.indices) {
            if (masks[i] == 0) continue
            for (d in Dir.ALL) if (Tile.has(masks[i], d) && !isMatched(masks, w, h, i, d)) return false
        }
        if (!isConnected(masks, w, h)) return false
        if (objective == Objective.LOOPS && masks.any { Tile.degree(it) == 1 }) return false
        return true
    }
}
