package com.loopconnect.engine

/** A game in progress. The level itself is rebuilt from [spec]; only player state is stored. */
data class SavedGame(
    val spec: LevelSpec,
    val dailyDay: Long?,
    val masks: IntArray,
    val history: List<Int>
)

object SaveCodec {
    private const val VERSION = "v1"

    fun encode(g: SavedGame): String = listOf(
        VERSION, g.spec.number, g.spec.width, g.spec.height, g.spec.objective.ordinal,
        g.spec.maxDegree, g.spec.fillPm, g.spec.branchingPm, g.spec.seed,
        g.dailyDay ?: -1L, g.history.joinToString(","), g.masks.joinToString(",")
    ).joinToString(";")

    /** Returns null for corrupt or tampered data instead of throwing. */
    fun decode(text: String?): SavedGame? {
        if (text.isNullOrBlank()) return null
        return runCatching {
            val p = text.split(";")
            if (p.size != 12 || p[0] != VERSION) return null
            val spec = LevelSpec(
                number = p[1].toInt(), width = p[2].toInt(), height = p[3].toInt(),
                objective = Objective.values()[p[4].toInt()], maxDegree = p[5].toInt(),
                fillPm = p[6].toInt(), branchingPm = p[7].toInt(), seed = p[8].toLong()
            )
            val day = p[9].toLong().takeIf { it >= 0 }
            val hist = if (p[10].isEmpty()) emptyList() else p[10].split(",").map { it.toInt() }
            val masks = p[11].split(",").map { it.toInt() }.toIntArray()
            if (spec.width !in 3..20 || spec.height !in 3..20) return null
            if (masks.size != spec.width * spec.height) return null
            if (masks.any { it !in 0..15 }) return null
            if (hist.any { it !in masks.indices }) return null
            SavedGame(spec, day, masks, hist)
        }.getOrNull()
    }

    /**
     * Rebuilds the board from a save. The level is regenerated from its seed and every stored
     * tile must be a rotation of the regenerated solution tile, otherwise the save is rejected.
     */
    fun restore(g: SavedGame): PuzzleBoard? {
        val level = LevelGenerator.build(g.spec) ?: return null
        for (i in g.masks.indices) {
            if (Tile.clicksToReach(level.solved[i], g.masks[i]) < 0) return null
        }
        return PuzzleBoard(level, g.masks, g.history)
    }

    fun snapshot(board: PuzzleBoard, dailyDay: Long?): SavedGame =
        SavedGame(board.level.spec, dailyDay, board.masksCopy(), board.historyCopy())
}
