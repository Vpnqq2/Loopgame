package com.loopconnect.engine

/** A game in progress. The level itself is rebuilt from [spec]; only player state is stored. */
data class SavedGame(
    val spec: LevelSpec,
    val dailyDay: Long?,
    val masks: IntArray,
    val history: List<Int>,
    val hintUsed: Boolean = false,
    val mode: GameMode = GameMode.CLASSIC
)

object SaveCodec {
    private const val VERSION = "v3"

    fun encode(g: SavedGame): String = listOf(
        VERSION, g.spec.number, g.spec.width, g.spec.height, g.spec.objective.ordinal,
        g.spec.maxDegree, g.spec.fillPm, g.spec.branchingPm, g.spec.seed,
        g.dailyDay ?: -1L, g.history.joinToString(","), g.masks.joinToString(","), if (g.hintUsed) 1 else 0, g.mode.ordinal
    ).joinToString(";")

    /** Reads v3, v2 and the older v1 format (and v4 saves that were not picture levels). Returns null for corrupt or tampered data instead of throwing. */
    fun decode(text: String?): SavedGame? {
        if (text.isNullOrBlank()) return null
        return runCatching {
            val p = text.split(";")
            val ok = (p.size == 15 && p[0] == "v4") || (p.size == 14 && p[0] == "v3") || (p.size == 13 && p[0] == "v2") || (p.size == 12 && p[0] == "v1")
            if (!ok) return null
            val spec = LevelSpec(
                number = p[1].toInt(), width = p[2].toInt(), height = p[3].toInt(),
                objective = Objective.values()[p[4].toInt()], maxDegree = p[5].toInt(),
                fillPm = p[6].toInt(), branchingPm = p[7].toInt(), seed = p[8].toLong()
            )
            // v4 saves carried a picture id; picture levels no longer exist, so such a save is dropped.
            if (p.size == 15 && p[14].toInt() != -1) return null
            val day = p[9].toLong().takeIf { it >= 0 }
            val hist = if (p[10].isEmpty()) emptyList() else p[10].split(",").map { it.toInt() }
            val masks = p[11].split(",").map { it.toInt() }.toIntArray()
            val hintUsed = p.size >= 13 && p[12] == "1"
            val mode = if (p.size >= 14) GameMode.values()[p[13].toInt()] else GameMode.CLASSIC
            if (spec.width !in 3..20 || spec.height !in 3..20) return null
            if (masks.size != spec.width * spec.height) return null
            if (masks.any { it !in 0..15 }) return null
            if (hist.any { it !in masks.indices }) return null
            SavedGame(spec, day, masks, hist, hintUsed, mode)
        }.getOrNull()
    }

    /**
     * Rebuilds the board from a save. The level is regenerated from its seed and every stored
     * tile must be a rotation of the regenerated solution tile, otherwise the save is rejected.
     */
    fun restore(g: SavedGame): PuzzleBoard? {
        val level = LevelGenerator.build(g.spec) ?: return null
        for (i in g.masks.indices) {
            if (Tile.clicksToReach(level.solved[i], g.masks[i]) < 0) return null
        }
        return PuzzleBoard(level, g.masks, g.history)
    }

    fun snapshot(board: PuzzleBoard, dailyDay: Long?, hintUsed: Boolean = false, mode: GameMode = GameMode.CLASSIC): SavedGame =
        SavedGame(board.level.spec, dailyDay, board.masksCopy(), board.historyCopy(), hintUsed, mode)
}
