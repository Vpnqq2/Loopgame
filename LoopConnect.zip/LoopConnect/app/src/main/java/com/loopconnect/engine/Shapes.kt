package com.loopconnect.engine

/**
 * A pixel-art silhouette. On a picture level the solved network occupies exactly the '#' cells, so
 * finishing the puzzle reveals the picture (a heart, a kitten, a fish...).
 * [maxDegree] is the highest number of branches a piece may have while the network is grown.
 */
class Shape(val name: String, val maxDegree: Int, vararg rows: String) {
    val height = rows.size
    val width = rows[0].length
    val cells = BooleanArray(width * height) { rows[it / width][it % width] == '#' }
    val filled = cells.count { it }

    init {
        require(rows.all { it.length == width }) { "Shape $name has uneven rows" }
    }
}

object Shapes {
    /** The picture catalogue. Order here is only an id; difficulty order is derived from [Shape.filled]. */
    val all: List<Shape> = listOf(
        Shape("Heart", 4, ".#.#.", "#####", ".###.", "..#.."),
        Shape("Diamond", 3, "..#..", ".###.", "#####", ".###.", "..#.."),
        Shape("Kitten", 3, "#...#", "#####", "#.#.#", "#####", ".###."),
        Shape("Fish", 3, "#.###.", "######", "######", "#.###."),
        Shape("Bunny", 3, ".#.#.", ".#.#.", "#####", "#.#.#", "#####", ".###."),
        Shape("Star", 3, "...#...", "..###..", "#######", ".#####.", "..###..", ".##.##.", ".#...#."),
        Shape("Tree", 3, "...#...", "..###..", ".#####.", "..###..", ".#####.", "#######", "...#...", "...#..."),
        Shape("Mushroom", 3, ".#####.", "#######", "#######", "..###..", "..###..", "..###.."),
        Shape("Goldfish", 3, "...####.", "##.#####", "#####.##", "##.#####", "...####."),
        Shape("House", 3, "...#...", "..###..", ".#####.", "#######", ".#####.", ".#####.", ".##.##."),
        Shape("Cat", 3, "#.....#", "##...##", "#######", "##.#.##", "#######", ".#####.", "..###.."),
        Shape("Rabbit", 3, ".#...#.", ".#...#.", ".#...#.", ".#####.", "#######", "##.#.##", "#######", ".#####."),
        Shape("Butterfly", 3, "##...##", "###.###", "#######", ".#####.", "#######", "###.###", "##...##")
    )

    /** Shape ids from the simplest picture to the most detailed. */
    private val bySize: List<Int> = all.indices.sortedBy { all[it].filled }

    fun get(id: Int): Shape? = all.getOrNull(id)

    /** Every 3rd campaign level (3, 6, 9...) is a picture level; this returns its shape id or -1. */
    fun idFor(levelNumber: Int): Int {
        if (levelNumber < 3 || levelNumber % 3 != 0) return -1
        val k = levelNumber / 3
        val budget = 14 + levelNumber * 2          // pictures grow with the player
        val eligible = bySize.filter { all[it].filled <= budget }
        return eligible[(k - 1) % eligible.size]   // heart first, then more detailed pictures
    }
}
