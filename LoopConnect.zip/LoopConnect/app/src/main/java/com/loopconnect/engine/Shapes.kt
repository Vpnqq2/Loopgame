package com.loopconnect.engine

import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * A pixel-art silhouette. On a picture level the solved network occupies exactly the filled cells, so
 * finishing the puzzle reveals the picture. Pictures are generated, not hand-drawn: see [Shapes].
 * [maxDegree] is the highest number of branches a piece may have while the network is grown.
 */
class Shape(val name: String, val maxDegree: Int, val width: Int, val height: Int, val cells: BooleanArray) {
    val filled = cells.count { it }

    init {
        require(cells.size == width * height) { "Shape $name has the wrong number of cells" }
    }

    /** The picture as text, one string per row ('#' filled, '.' empty). */
    fun rows(): List<String> = (0 until height).map { y ->
        (0 until width).joinToString("") { x -> if (cells[y * width + x]) "#" else "." }
    }
}

/**
 * Procedural pictures for the campaign's picture levels (every 3rd level: 3, 6, 9...).
 *
 * Each picture is a handful of random bars and blocks that is mirrored left/right (and sometimes top/bottom
 * too), so it always looks balanced and deliberate, like a small emblem. Loose pixels are trimmed, the picture is
 * cropped to its bounding box, and it must be one connected piece of a playable size.
 *
 * Picture number `id` (= level / 3) is generated from a fixed seed, so a level always shows the same picture,
 * and the first [DEDUPE_LIMIT] pictures are guaranteed to be pairwise different (also when flipped).
 */
object Shapes {
    private val NAMES = listOf(
        "Crystal", "Gem", "Emblem", "Mandala", "Rune", "Crest", "Glyph", "Totem", "Sigil", "Charm", "Badge", "Relic"
    )

    /** Beyond this many pictures nobody realistically plays, so we skip the uniqueness bookkeeping. */
    private const val DEDUPE_LIMIT = 2000

    private val made = ArrayList<Shape>()
    private val seen = HashSet<String>()

    /** Picture id for a campaign level, or -1 when the level is an ordinary board. */
    fun idFor(levelNumber: Int): Int = if (levelNumber >= 3 && levelNumber % 3 == 0) levelNumber / 3 else -1

    @Synchronized
    fun get(id: Int): Shape? {
        if (id < 1) return null
        if (id > DEDUPE_LIMIT) return create(id, dedupe = false)
        while (made.size < id) made.add(create(made.size + 1, dedupe = true))
        return made[id - 1]
    }

    private fun create(id: Int, dedupe: Boolean): Shape {
        var last: Shape? = null
        for (attempt in 0 until 1500) {
            val s = generate(id, attempt) ?: continue
            last = s
            if (!dedupe || seen.add(key(s))) return s
        }
        return last ?: fallback()
    }

    /** Smallest of the four flips, so a picture and its mirror image count as the same picture. */
    private fun key(s: Shape): String {
        fun flipped(fx: Boolean, fy: Boolean) = (0 until s.height).joinToString("/") { y ->
            val yy = if (fy) s.height - 1 - y else y
            (0 until s.width).joinToString("") { x ->
                val xx = if (fx) s.width - 1 - x else x
                if (s.cells[yy * s.width + xx]) "#" else "."
            }
        }
        return "${s.width}x${s.height}:" + listOf(flipped(false, false), flipped(true, false), flipped(false, true), flipped(true, true)).sorted().first()
    }

    private fun generate(id: Int, attempt: Int): Shape? {
        val rnd = Random(LevelGenerator.mix(id * 1_000_003L + attempt * 7919L + 4242L))
        // Pictures grow with the player; extra attempts widen the grid a little to make room for new designs.
        val base = min(5 + (id - 1) / 5 + attempt / 150, 9)
        val w0 = max(5, base - (if (base > 5) rnd.nextInt(2) else 0))
        val h0 = min(w0 + rnd.nextInt(3), 11)
        val quad = rnd.nextInt(100) < 35            // mirrored both ways, or only left/right
        val hw = (w0 + 1) / 2
        val hh = if (quad) (h0 + 1) / 2 else h0

        // Build one half (or quarter) out of a few overlapping bars and blocks. The right-hand column of
        // that half is the mirror axis, so everything that touches it joins its mirror image.
        val half = BooleanArray(hw * hh)
        fun fill(x0: Int, y0: Int, rw: Int, rh: Int) {
            for (y in max(0, y0) until min(hh, y0 + rh)) for (x in max(0, x0) until min(hw, x0 + rw)) half[y * hw + x] = true
        }
        val bodyW = 1 + rnd.nextInt(max(1, hw))
        val bodyH = 2 + rnd.nextInt(max(1, hh - 1))
        fill(hw - bodyW, if (quad) hh - bodyH else hh / 2 - bodyH / 2, bodyW, bodyH)
        repeat(2 + rnd.nextInt(4)) {
            // Every new part overlaps a cell that is already filled, so the picture stays in one piece.
            val filledCells = half.indices.filter { half[it] }
            val anchor = filledCells[rnd.nextInt(filledCells.size)]
            val ax = anchor % hw
            val ay = anchor / hw
            val rw: Int
            val rh: Int
            when (rnd.nextInt(3)) {
                0 -> { rw = 2 + rnd.nextInt(hw); rh = 1 + rnd.nextInt(2) }                 // horizontal bar
                1 -> { rw = 1 + rnd.nextInt(2); rh = 2 + rnd.nextInt(max(1, hh - 1)) }     // vertical bar
                else -> { rw = 2 + rnd.nextInt(2); rh = 2 + rnd.nextInt(2) }               // block
            }
            fill(ax - rnd.nextInt(rw), ay - rnd.nextInt(rh), rw, rh)
        }

        // Mirror into the full grid.
        val full = BooleanArray(w0 * h0) { i ->
            val x = i % w0
            val y = i / w0
            half[(if (quad) min(y, h0 - 1 - y) else y) * hw + min(x, w0 - 1 - x)]
        }
        fun neighbours(c: BooleanArray, x: Int, y: Int): Int {
            var n = 0
            if (x > 0 && c[y * w0 + x - 1]) n++
            if (x < w0 - 1 && c[y * w0 + x + 1]) n++
            if (y > 0 && c[(y - 1) * w0 + x]) n++
            if (y < h0 - 1 && c[(y + 1) * w0 + x]) n++
            return n
        }
        // Trim loose single pixels at the tips of thin bars (a symmetric pass, so the picture stays balanced).
        val trimmed = BooleanArray(w0 * h0) { full[it] && neighbours(full, it % w0, it / w0) >= 2 }

        // Crop to the bounding box; the crop keeps the mirror symmetry.
        var minX = w0; var maxX = -1; var minY = h0; var maxY = -1
        for (i in trimmed.indices) if (trimmed[i]) {
            minX = min(minX, i % w0); maxX = max(maxX, i % w0)
            minY = min(minY, i / w0); maxY = max(maxY, i / w0)
        }
        if (maxX < 0) return null
        val w = maxX - minX + 1
        val h = maxY - minY + 1
        val cells = BooleanArray(w * h) { trimmed[(minY + it / w) * w0 + minX + it % w] }

        // Size limits: pictures get bigger with the level, but stay playable, compact and not just a solid block.
        val filled = cells.count { it }
        if (w < 4 || h < 4) return null
        if (filled < min(10 + id * 4 / 5, 34) || filled > 48) return null
        if (filled > w * h * 3 / 4 || filled * 100 < w * h * 40) return null

        // One single connected piece.
        val start = cells.indexOfFirst { it }
        val seenCell = BooleanArray(w * h)
        val stack = ArrayDeque<Int>()
        stack.addLast(start)
        seenCell[start] = true
        var reached = 1
        while (stack.isNotEmpty()) {
            val c = stack.removeLast()
            for (d in Dir.ALL) {
                val nb = Rules.neighbor(c, d, w, h)
                if (nb >= 0 && cells[nb] && !seenCell[nb]) { seenCell[nb] = true; reached++; stack.addLast(nb) }
            }
        }
        if (reached != filled) return null

        return Shape(NAMES[rnd.nextInt(NAMES.size)], 3, w, h, cells)
    }

    /** Only reached if 1500 seeds somehow all fail: a plain symmetric diamond. */
    private fun fallback(): Shape {
        val rows = listOf("..#..", ".###.", "#####", ".###.", "..#..")
        return Shape("Gem", 3, 5, 5, BooleanArray(25) { rows[it / 5][it % 5] == '#' })
    }
}
