package com.loopconnect.engine

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Board silhouettes for levels that use [Twist.SHAPE]. A silhouette is a mask of playable cells; every cell
 * outside it is a wall that no line may enter. The shape is chosen from the level seed, so a saved spec
 * recreates it exactly. Every returned mask is connected and keeps most of the board playable.
 */
object Shapes {
    const val KINDS = 5

    private fun carve(w: Int, h: Int, kind: Int): BooleanArray {
        val ok = BooleanArray(w * h) { true }
        fun cut(x0: Int, y0: Int, x1: Int, y1: Int) {
            for (y in y0 until y1) for (x in x0 until x1) if (x in 0 until w && y in 0 until h) ok[y * w + x] = false
        }
        when (kind) {
            0 -> { // cut corners
                val k = max(1, min(w, h) / 3)
                cut(0, 0, k, k); cut(w - k, 0, w, k); cut(0, h - k, k, h); cut(w - k, h - k, w, h)
            }
            1 -> { // ring: a hole in the middle
                var hw = if (w % 2 == 0) 2 else 1
                var hh = if (h % 2 == 0) 2 else 1
                if (w >= 7) hw += 2
                if (h >= 7) hh += 2
                hw = min(hw, w - 2); hh = min(hh, h - 2)
                if (hw > 0 && hh > 0) cut((w - hw) / 2, (h - hh) / 2, (w - hw) / 2 + hw, (h - hh) / 2 + hh)
            }
            2 -> cut(w - w / 2, 0, w, h / 2) // L shape
            3 -> { // octagon / diamond
                val m = max(w, h)
                val limit = m + (m % 2)
                for (y in 0 until h) for (x in 0 until w) {
                    if (abs(2 * x - (w - 1)) + abs(2 * y - (h - 1)) > limit) ok[y * w + x] = false
                }
            }
            else -> { // waist: bites out of both sides
                val k = max(1, w / 4)
                cut(0, h / 3, k, h - h / 3); cut(w - k, h / 3, w, h - h / 3)
            }
        }
        return ok
    }

    private fun usable(ok: BooleanArray, w: Int, h: Int): Boolean {
        val total = ok.count { it }
        if (total < 8 || total * 100 < ok.size * 55) return false
        val start = ok.indexOfFirst { it }
        val seen = BooleanArray(ok.size)
        val stack = ArrayDeque<Int>()
        seen[start] = true
        stack.addLast(start)
        var reached = 1
        while (stack.isNotEmpty()) {
            val c = stack.removeLast()
            for (d in Dir.ALL) {
                val nb = Rules.neighbor(c, d, w, h)
                if (nb >= 0 && ok[nb] && !seen[nb]) { seen[nb] = true; reached++; stack.addLast(nb) }
            }
        }
        return reached == total
    }

    /** The silhouette for a board of [w] x [h] and level seed [seed]. Falls back to the full rectangle. */
    fun pick(w: Int, h: Int, seed: Long): BooleanArray {
        if (w >= 4 && h >= 4) {
            val first = Math.floorMod(seed ushr 7, KINDS.toLong()).toInt()
            for (k in 0 until KINDS) {
                val ok = carve(w, h, (first + k) % KINDS)
                if (usable(ok, w, h)) return ok
            }
        }
        return BooleanArray(w * h) { true }
    }
}
