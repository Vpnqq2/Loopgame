package com.loopconnect.engine

/**
 * Independent backtracking solver. It only looks at the *shape* of each tile (its rotation
 * options) and searches for orientations satisfying the real game rules, so it validates
 * generated levels without trusting the generator.
 */
object Solver {
    class Result(val masks: IntArray?, val nodes: Int, val exhausted: Boolean) {
        val solvable get() = masks != null
        /** True when the search ended without finding a solution and without hitting the node limit. */
        val provenUnsolvable get() = masks == null && exhausted
    }

    fun solve(shapes: IntArray, w: Int, h: Int, objective: Objective, nodeLimit: Int = 200_000): Result {
        val n = w * h
        val options = Array(n) { Tile.distinctRotations(shapes[it]).toIntArray() }
        val cur = IntArray(n)
        var nodes = 0
        var aborted = false

        fun rec(i: Int): Boolean {
            if (++nodes > nodeLimit) { aborted = true; return false }
            if (i == n) return Rules.isSolved(cur, w, h, objective)
            val r = i / w
            val c = i % w
            for (m in options[i]) {
                if (c == 0 && Tile.has(m, Dir.W)) continue
                if (c == w - 1 && Tile.has(m, Dir.E)) continue
                if (r == 0 && Tile.has(m, Dir.N)) continue
                if (r == h - 1 && Tile.has(m, Dir.S)) continue
                if (c > 0 && Tile.has(m, Dir.W) != Tile.has(cur[i - 1], Dir.E)) continue
                if (r > 0 && Tile.has(m, Dir.N) != Tile.has(cur[i - w], Dir.S)) continue
                cur[i] = m
                if (rec(i + 1)) return true
                if (aborted) return false
            }
            return false
        }

        val ok = rec(0)
        return Result(if (ok) cur.copyOf() else null, nodes, !aborted)
    }

    fun solve(level: Level, nodeLimit: Int = 200_000): Result =
        solve(level.initialMasks, level.width, level.height, level.spec.objective, nodeLimit)
}
