package com.loopconnect.engine

/**
 * Spark mode: a power source sits on the board and only pieces that have been connected to it
 * can be turned. Power spreads through matched sides. A piece that has been powered once stays
 * unlocked, so the player can never lock themselves out; sleeping pieces simply keep the
 * orientation they started with until power reaches them.
 *
 * Solvability is guaranteed by construction (see [LevelGenerator.buildSpark]): every sleeping
 * piece starts with the side that faces its parent open, so waking pieces in breadth-first order
 * from the source always works.
 */
object Spark {
    /**
     * The power source: the occupied piece nearest the board centre (lowest index on ties).
     * It depends only on the solved layout, so it never needs to be stored.
     */
    fun sourceOf(solved: IntArray, w: Int, h: Int): Int {
        var best = -1
        var bestD = Int.MAX_VALUE
        for (i in solved.indices) {
            if (solved[i] == 0) continue
            val dx = 2 * (i % w) - (w - 1)
            val dy = 2 * (i / w) - (h - 1)
            val d = dx * dx + dy * dy
            if (d < bestD) { bestD = d; best = i }
        }
        return best
    }

    fun sourceOf(level: Level): Int = sourceOf(level.solved, level.width, level.height)
}
