package com.loopconnect.engine

/** Connection points of a tile are stored as a 4-bit mask. */
object Dir {
    const val N = 1
    const val E = 2
    const val S = 4
    const val W = 8
    val ALL = intArrayOf(N, E, S, W)

    fun opposite(d: Int): Int = when (d) {
        N -> S
        E -> W
        S -> N
        else -> E
    }

    fun dx(d: Int): Int = when (d) {
        E -> 1
        W -> -1
        else -> 0
    }

    fun dy(d: Int): Int = when (d) {
        S -> 1
        N -> -1
        else -> 0
    }
}

enum class TileKind { EMPTY, END, STRAIGHT, CORNER, TEE, CROSS }

object Tile {
    /** Rotate clockwise by 90 degrees [times] times: N->E->S->W->N. */
    fun rotateCw(mask: Int, times: Int = 1): Int {
        var m = mask and 15
        repeat(((times % 4) + 4) % 4) { m = ((m shl 1) or (m shr 3)) and 15 }
        return m
    }

    fun rotateCcw(mask: Int): Int = rotateCw(mask, 3)

    fun degree(mask: Int): Int = Integer.bitCount(mask and 15)

    fun has(mask: Int, dir: Int): Boolean = (mask and dir) != 0

    fun kind(mask: Int): TileKind = when (degree(mask)) {
        0 -> TileKind.EMPTY
        1 -> TileKind.END
        2 -> if (mask == (Dir.N or Dir.S) || mask == (Dir.E or Dir.W)) TileKind.STRAIGHT else TileKind.CORNER
        3 -> TileKind.TEE
        else -> TileKind.CROSS
    }

    /** All visually distinct orientations of this tile. */
    fun distinctRotations(mask: Int): List<Int> = (0..3).map { rotateCw(mask, it) }.distinct()

    /** Number of clockwise taps needed to turn [from] into [to], or -1 if impossible. */
    fun clicksToReach(from: Int, to: Int): Int = (0..3).firstOrNull { rotateCw(from, it) == to } ?: -1
}
