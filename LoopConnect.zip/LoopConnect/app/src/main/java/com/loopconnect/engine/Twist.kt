package com.loopconnect.engine

/**
 * New puzzle rules that the Classic campaign introduces one at a time. A level carries the rules it uses as a
 * bit mask in [LevelSpec.rules]. Each rule shows up alone the first time (at [introLevel]) so the player can
 * learn it, then returns regularly and starts to mix with the others.
 */
enum class Twist(
    val bit: Int,
    val title: String,
    /** The short instruction shown the first time the rule appears. */
    val tip: String,
    /** One line shown under the board while a level uses the rule. */
    val reminder: String,
    val introLevel: Int
) {
    LOCKS(
        1, "Padlocked pieces",
        "Pieces with a padlock are already in place and never turn. Use them as anchors and build the rest around them.",
        "Padlocked pieces never turn. Build around them", 6
    ),
    WINDING(
        2, "Long winding route",
        "This board is mostly one long winding route with few or no branches. Start at an end and follow the path piece by piece.",
        "One long winding route. Follow it from end to end", 10
    ),
    SHAPE(
        4, "Odd board shapes",
        "The board is not a plain rectangle any more. Dark squares are walls: lines can never run into them.",
        "Dark squares are walls. Lines cannot enter them", 11
    ),
    TWINS(
        8, "Twin pieces",
        "Pieces with the same coloured link badge are twins. Tap one and both turn together, so plan the taps.",
        "Matching badges turn together. One tap moves both", 14
    );

    companion object {
        fun has(rules: Int, t: Twist): Boolean = (rules and t.bit) != 0

        /** The rules in [rules], in the order they were introduced. */
        fun list(rules: Int): List<Twist> = values().filter { has(rules, it) }

        /**
         * Which rules campaign level [lv] uses. Every rule debuts on its own level and then comes back on a
         * regular beat (locks every 3rd level, winding and shapes every 5th, twins every 4th), so later
         * levels combine them. Loop levels never use the winding route, which needs branch-free boards.
         */
        fun forLevel(lv: Int, objective: Objective): Int {
            var r = 0
            fun beat(t: Twist, every: Int) {
                if (lv >= t.introLevel && (lv - t.introLevel) % every == 0) r = r or t.bit
            }
            beat(LOCKS, 3)
            if (objective == Objective.NETWORK) beat(WINDING, 5)
            beat(SHAPE, 5)
            beat(TWINS, 4)
            return r
        }
    }
}
