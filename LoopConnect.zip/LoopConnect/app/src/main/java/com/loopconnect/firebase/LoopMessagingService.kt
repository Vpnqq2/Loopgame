package com.loopconnect.firebase

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.loopconnect.data.Repository
import kotlinx.coroutines.runBlocking

class LoopMessagingService : FirebaseMessagingService() {
    override fun onMessageReceived(message: RemoteMessage) {
        // Foreground delivery: respect the in-app notifications switch.
        val allowed = runCatching { runBlocking { Repository(applicationContext).currentSettings().notifications } }.getOrDefault(false)
        if (!allowed) return
        val title = message.notification?.title ?: message.data["title"] ?: return
        val body = message.notification?.body ?: message.data["body"] ?: ""
        val channel = if (message.data["channel"] == Push.CHANNEL_DAILY) Push.CHANNEL_DAILY else Push.CHANNEL_GENERAL
        Push.show(applicationContext, title, body, channel)
    }

    // Only topics are used, so no token is stored or sent anywhere.
    override fun onNewToken(token: String) = Unit
}
