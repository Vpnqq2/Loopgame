package com.loopconnect.firebase

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import com.loopconnect.MainActivity
import com.loopconnect.R

/** Notification channels, topic subscription and display. Everything is opt-in. */
object Push {
    const val CHANNEL_DAILY = "daily"
    const val CHANNEL_GENERAL = "general"
    private const val TOPIC_DAILY = "daily_puzzle"
    private const val TOPIC_NEWS = "news"

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(CHANNEL_DAILY, "Daily puzzle", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "Reminders for the daily puzzle"
        })
        nm.createNotificationChannel(NotificationChannel(CHANNEL_GENERAL, "News and updates", NotificationManager.IMPORTANCE_LOW).apply {
            description = "New features and occasional news"
        })
    }

    /**
     * Opt in: allow FCM to create a token and join the topics. Opt out: leave the topics and delete the token.
     * Auto-init is disabled in the manifest, so no token exists until the player agrees.
     */
    fun setEnabled(ctx: Context, enabled: Boolean) {
        if (runCatching { FirebaseApp.getApps(ctx).isEmpty() }.getOrDefault(true)) return
        runCatching {
            val fm = FirebaseMessaging.getInstance()
            fm.isAutoInitEnabled = enabled
            if (enabled) {
                fm.subscribeToTopic(TOPIC_DAILY)
                fm.subscribeToTopic(TOPIC_NEWS)
            } else {
                fm.unsubscribeFromTopic(TOPIC_DAILY)
                fm.unsubscribeFromTopic(TOPIC_NEWS)
                fm.deleteToken()
            }
        }
    }

    /** Shows a notification while the app is in the foreground (background ones are shown by the FCM SDK). */
    @SuppressLint("MissingPermission")
    fun show(ctx: Context, title: String, body: String, channel: String) {
        if (!NotificationManagerCompat.from(ctx).areNotificationsEnabled()) return
        val intent = Intent(ctx, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP }
        val pi = PendingIntent.getActivity(ctx, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat_notification)
            .setColor(ContextCompat.getColor(ctx, R.color.notification_color))
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        runCatching { NotificationManagerCompat.from(ctx).notify(System.currentTimeMillis().toInt(), n) }
    }
}
