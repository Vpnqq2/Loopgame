package com.loopconnect.ui

import android.os.Build
import android.view.HapticFeedbackConstants
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Spa
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.loopconnect.engine.Tier
import com.loopconnect.ui.screens.Confetti
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

fun achievementIcon(key: String): ImageVector = when (key) {
    "flag" -> Icons.Rounded.Flag
    "grid" -> Icons.Rounded.GridView
    "trophy" -> Icons.Rounded.EmojiEvents
    "crown" -> Icons.Rounded.WorkspacePremium
    "star" -> Icons.Rounded.Star
    "bolt" -> Icons.Rounded.Bolt
    "calendar" -> Icons.Rounded.CalendarMonth
    "fire" -> Icons.Rounded.LocalFireDepartment
    "touch" -> Icons.Rounded.TouchApp
    "timer" -> Icons.Rounded.Timer
    "zen" -> Icons.Rounded.Spa
    else -> Icons.Rounded.EmojiEvents
}

/** Light and dark metal colours for each tier. */
fun tierColors(tier: Tier): Pair<Color, Color> = when (tier) {
    Tier.BRONZE -> Color(0xFFE6A15F) to Color(0xFF9A5A22)
    Tier.SILVER -> Color(0xFFEAF0F8) to Color(0xFF8E9AAF)
    Tier.GOLD -> Color(0xFFFFE066) to Color(0xFFFF9A3D)
}

fun tierName(tier: Tier): String = when (tier) {
    Tier.BRONZE -> "Bronze"
    Tier.SILVER -> "Silver"
    Tier.GOLD -> "Gold"
}

/** Shows queued achievement celebrations on top of whatever screen is open. */
@Composable
fun UnlockHost(vm: GameViewModel) {
    val queue by vm.unlocks.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val view = LocalView.current
    val animated = LocalAnimations.current
    val head = queue.firstOrNull() ?: return
    key(head.id) {
        UnlockPopup(
            event = head, more = queue.size - 1, animated = animated,
            onShown = {
                vm.sound.playAward()
                if (settings.haptics) {
                    view.performHapticFeedback(
                        if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.LONG_PRESS
                    )
                }
            },
            onDismiss = { vm.dismissUnlock() }
        )
    }
}

@Composable
private fun UnlockPopup(event: UnlockEvent, more: Int, animated: Boolean, onShown: () -> Unit, onDismiss: () -> Unit) {
    val c = LocalLoop.current
    val a = event.achievement
    val (light, dark) = tierColors(a.tier)
    val appear = remember { Animatable(if (animated) 0f else 1f) }
    val badge = remember { Animatable(if (animated) 0f else 1f) }
    val burst = remember { Animatable(if (animated) 0f else 1f) }
    val reward = remember { Animatable(if (animated) 0f else 1f) }
    val rot by (if (animated) rememberInfiniteTransition(label = "rays").animateFloat(
        0f, 360f, infiniteRepeatable(tween(16000, easing = LinearEasing)), label = "rot"
    ) else remember { mutableStateOf(0f) })

    LaunchedEffect(Unit) {
        onShown()
        if (animated) {
            launch { appear.animateTo(1f, tween(350, easing = FastOutSlowInEasing)) }
            delay(180)
            launch { badge.animateTo(1f, spring(dampingRatio = 0.42f, stiffness = 220f)) }
            launch { burst.animateTo(1f, tween(1400, easing = FastOutSlowInEasing)) }
            delay(650)
            reward.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 300f))
        }
    }
    BackHandler { onDismiss() }

    Box(
        Modifier.fillMaxSize()
            .drawBehind { drawRect(Color.Black.copy(alpha = 0.8f * appear.value)) }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
        contentAlignment = Alignment.Center
    ) {
        if (animated) Confetti(Modifier.fillMaxSize())
        Column(
            Modifier.padding(28.dp).fillMaxWidth().graphicsLayer {
                alpha = appear.value
                translationY = (1f - appear.value) * 60f
            }.semantics { contentDescription = "Achievement ${if (event.isNew) "unlocked" else ""}: ${a.title}. ${a.description}" },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                if (event.isNew) "ACHIEVEMENT UNLOCKED" else "ACHIEVEMENT",
                color = light, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp
            )
            Spacer(Modifier.height(10.dp))
            Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val radius = size.width / 2f
                    // rotating light rays
                    rotate(rot, center) {
                        for (k in 0 until 12) {
                            rotate(k * 30f, center) {
                                val half = radius * 0.11f
                                val path = Path().apply {
                                    moveTo(center.x, center.y)
                                    lineTo(center.x - half, center.y - radius)
                                    lineTo(center.x + half, center.y - radius)
                                    close()
                                }
                                drawPath(path, Brush.radialGradient(listOf(light.copy(alpha = 0.42f * badge.value.coerceIn(0f, 1f)), Color.Transparent), center, radius))
                            }
                        }
                    }
                    // expanding rings
                    for (ring in 0 until 3) {
                        val p = (burst.value * 1.3f - ring * 0.18f).coerceIn(0f, 1f)
                        if (p > 0f && p < 1f) {
                            drawCircle(light.copy(alpha = 0.65f * (1f - p)), radius * (0.3f + 0.7f * p), center, style = Stroke(5f))
                        }
                    }
                    // sparkles
                    val eased = 1f - (1f - burst.value) * (1f - burst.value)
                    for (k in 0 until 16) {
                        val ang = k * (2f * PI.toFloat() / 16f)
                        val dist = radius * (0.34f + 0.6f * eased) * (if (k % 2 == 0) 1f else 0.78f)
                        drawCircle(
                            (if (k % 3 == 0) Color.White else light).copy(alpha = (1f - burst.value).coerceIn(0f, 1f)),
                            (if (k % 2 == 0) 6f else 4f) * (1f - burst.value * 0.5f),
                            Offset(center.x + cos(ang) * dist, center.y + sin(ang) * dist)
                        )
                    }
                }
                Box(
                    Modifier.size(124.dp).graphicsLayer {
                        scaleX = badge.value; scaleY = badge.value
                        rotationZ = (1f - badge.value) * -120f
                    }.clip(CircleShape).background(Brush.verticalGradient(listOf(light, dark)))
                        .border(4.dp, Color.White.copy(alpha = 0.65f), CircleShape),
                    contentAlignment = Alignment.Center
                ) { Icon(achievementIcon(a.icon), null, tint = Color(0xFF2A1900), modifier = Modifier.size(66.dp)) }
            }
            Text(tierName(a.tier).uppercase(), color = dark, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
            Text(a.title, color = c.text, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            Text(a.description, color = c.textDim, fontSize = 15.sp, textAlign = TextAlign.Center)
            if (event.isNew) {
                Spacer(Modifier.height(16.dp))
                Row(
                    Modifier.graphicsLayer { scaleX = reward.value; scaleY = reward.value; alpha = reward.value.coerceIn(0f, 1f) }
                        .clip(RoundedCornerShape(50)).background(c.gold.copy(alpha = 0.16f))
                        .border(1.dp, c.gold.copy(alpha = 0.6f), RoundedCornerShape(50))
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Lightbulb, null, tint = c.gold, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Reward  +${a.reward} hint${if (a.reward == 1) "" else "s"}", color = c.gold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
            Spacer(Modifier.height(24.dp))
            PrimaryButton(if (more > 0) "NEXT" else "AWESOME!", onDismiss, Modifier.fillMaxWidth())
            if (more > 0) Text("+$more more", color = c.textDim, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
}
