package com.loopconnect.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, icon: ImageVector? = null, enabled: Boolean = true) {
    val c = LocalLoop.current
    Row(
        modifier.heightIn(min = 52.dp).alpha(if (enabled) 1f else 0.4f)
            .clip(RoundedCornerShape(16.dp))
            .background(Brush.horizontalGradient(listOf(c.accent, lerp(c.accent, c.accent2, 0.55f))))
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
    }
}

@Composable
fun OutlineButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, icon: ImageVector? = null, enabled: Boolean = true) {
    val c = LocalLoop.current
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier.heightIn(min = 50.dp).alpha(if (enabled) 1f else 0.4f)
            .clip(shape).background(c.surface.copy(alpha = 0.7f)).border(1.dp, c.accent.copy(alpha = 0.55f), shape)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) { Icon(icon, null, tint = c.text, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, color = c.text, fontWeight = FontWeight.Medium, fontSize = 16.sp)
    }
}

@Composable
fun LoopCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalLoop.current
    val shape = RoundedCornerShape(18.dp)
    Column(modifier.clip(shape).background(c.surface.copy(alpha = 0.92f)).border(1.dp, c.border, shape).padding(14.dp), content = content)
}

@Composable
fun CircleAction(icon: ImageVector, label: String, onClick: () -> Unit, enabled: Boolean = true, highlight: Boolean = false) {
    val c = LocalLoop.current
    Column(
        Modifier.widthIn(min = 72.dp).alpha(if (enabled) 1f else 0.4f)
            .clickable(enabled = enabled, role = Role.Button, onClickLabel = label, onClick = onClick).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(56.dp).clip(CircleShape).background(if (highlight) c.accent.copy(alpha = 0.2f) else c.surface)
                .border(1.dp, if (highlight) c.accent else c.border, CircleShape),
            contentAlignment = Alignment.Center
        ) { Icon(icon, contentDescription = null, tint = if (highlight) c.accent else c.text, modifier = Modifier.size(26.dp)) }
        Spacer(Modifier.height(4.dp))
        Text(label, color = c.textDim, fontSize = 12.sp)
    }
}

@Composable
fun ScreenTopBar(title: String, subtitle: String? = null, onBack: (() -> Unit)? = null, trailing: @Composable (() -> Unit)? = null) {
    val c = LocalLoop.current
    Box(Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(horizontal = 4.dp), contentAlignment = Alignment.Center) {
        if (onBack != null) {
            IconButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterStart)) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = c.text)
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 56.dp)) {
            Text(title, color = c.text, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
            if (subtitle != null) Text(subtitle, color = c.textDim, fontSize = 13.sp, textAlign = TextAlign.Center)
        }
        if (trailing != null) Box(Modifier.align(Alignment.CenterEnd)) { trailing() }
    }
}

@Composable
fun StarRow(stars: Int, size: Dp, total: Int = 3, spacing: Dp = 2.dp) {
    val c = LocalLoop.current
    Row(
        horizontalArrangement = Arrangement.spacedBy(spacing),
        modifier = Modifier.semantics { contentDescription = "$stars of $total stars" }
    ) {
        repeat(total) { Icon(Icons.Rounded.Star, null, tint = if (it < stars) c.gold else c.border, modifier = Modifier.size(size)) }
    }
}

/** Original logo mark drawn with vector paths. */
@Composable
fun LogoMark(size: Dp) {
    val c = LocalLoop.current
    Canvas(Modifier.size(size).semantics { contentDescription = "Loop Connect logo" }) {
        val s = this.size.width / 108f
        val r = 24f * s
        drawRoundRect(Color(0xFF0A1022), cornerRadius = CornerRadius(r, r))
        drawRoundRect(
            Brush.linearGradient(listOf(c.accent, c.accent2, c.gold)), cornerRadius = CornerRadius(r, r),
            style = Stroke(width = 3f * s)
        )
        fun line(color: Color, build: Path.() -> Unit) = drawPath(
            Path().apply(build), color,
            style = Stroke(width = 6f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        line(Color(0xFF3DA5FF)) { moveTo(36 * s, 34 * s); lineTo(36 * s, 50 * s); quadraticBezierTo(36 * s, 56 * s, 42 * s, 56 * s); lineTo(54 * s, 56 * s) }
        line(Color(0xFFB06CFF)) { moveTo(54 * s, 56 * s); lineTo(54 * s, 42 * s); quadraticBezierTo(54 * s, 36 * s, 60 * s, 36 * s); lineTo(66 * s, 36 * s); quadraticBezierTo(72 * s, 36 * s, 72 * s, 42 * s); lineTo(72 * s, 48 * s) }
        line(Color(0xFFFFC93D)) { moveTo(54 * s, 56 * s); lineTo(54 * s, 70 * s); quadraticBezierTo(54 * s, 76 * s, 60 * s, 76 * s); lineTo(72 * s, 76 * s) }
        drawCircle(Color(0xFF3DA5FF), 6f * s, Offset(36 * s, 34 * s))
        drawCircle(Color(0xFFFF6FA8), 6f * s, Offset(72 * s, 48 * s))
        drawCircle(Color(0xFFFFC93D), 6f * s, Offset(72 * s, 76 * s))
    }
}
