package com.loopconnect.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Press feedback shared by every tappable game element: a springy squash instead of a web-style ripple. */
fun Modifier.gamePress(
    enabled: Boolean = true, role: Role? = Role.Button, label: String? = null, onClick: () -> Unit
): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.94f else 1f, spring(dampingRatio = 0.6f, stiffness = 700f), label = "press")
    this.graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, enabled = enabled, role = role, onClickLabel = label, onClick = onClick)
}

/** Chunky 3D button with a darker lower edge, gloss and coloured glow. */
@Composable
fun PrimaryButton(
    text: String, onClick: () -> Unit, modifier: Modifier = Modifier,
    icon: ImageVector? = null, enabled: Boolean = true, big: Boolean = false
) {
    val c = LocalLoop.current
    val shape = RoundedCornerShape(if (big) 26.dp else 20.dp)
    val bottom = lerp(c.accent, c.accent2, 0.6f)
    val edge = lerp(bottom, Color.Black, 0.5f)
    Box(modifier.alpha(if (enabled) 1f else 0.4f).gamePress(enabled = enabled, onClick = onClick)) {
        Box(Modifier.padding(bottom = 6.dp)) {
            Box(Modifier.matchParentSize().offset(y = 6.dp).clip(shape).background(edge))
            Row(
                Modifier.fillMaxWidth().heightIn(min = if (big) 66.dp else 54.dp)
                    .shadow(10.dp, shape, ambientColor = c.accent, spotColor = c.accent)
                    .clip(shape)
                    .background(Brush.verticalGradient(listOf(lerp(c.accent, Color.White, 0.28f), c.accent, bottom)))
                    .border(1.dp, Color.White.copy(alpha = 0.4f), shape)
                    .padding(horizontal = 22.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
            ) {
                if (icon != null) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(if (big) 30.dp else 22.dp)); Spacer(Modifier.width(8.dp)) }
                Text(text, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = if (big) 24.sp else 17.sp, letterSpacing = 0.8.sp)
            }
        }
    }
}

/** Glass secondary button. */
@Composable
fun OutlineButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, icon: ImageVector? = null, enabled: Boolean = true) {
    val c = LocalLoop.current
    val shape = RoundedCornerShape(18.dp)
    Box(modifier.alpha(if (enabled) 1f else 0.4f).gamePress(enabled = enabled, onClick = onClick)) {
        Box(Modifier.padding(bottom = 4.dp)) {
            Box(Modifier.matchParentSize().offset(y = 4.dp).clip(shape).background(c.bgBottom.copy(alpha = 0.9f)))
            Row(
                Modifier.fillMaxWidth().heightIn(min = 50.dp).clip(shape)
                    .background(Brush.verticalGradient(listOf(c.surfaceHi, c.surface)))
                    .border(1.dp, Brush.verticalGradient(listOf(c.accent.copy(alpha = 0.7f), c.border)), shape)
                    .padding(horizontal = 18.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
            ) {
                if (icon != null) { Icon(icon, null, tint = c.accent, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
                Text(text, color = c.text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }
}

/** Frosted game panel. */
@Composable
fun LoopCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalLoop.current
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier.clip(shape)
            .background(Brush.verticalGradient(listOf(c.surfaceHi.copy(alpha = 0.88f), c.surface.copy(alpha = 0.92f))))
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.2f), c.border.copy(alpha = 0.6f))), shape)
            .padding(16.dp),
        content = content
    )
}

@Composable
fun GlassIconButton(icon: ImageVector, description: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = LocalLoop.current
    Box(
        modifier.size(46.dp).gamePress(label = description, onClick = onClick).clip(CircleShape)
            .background(Brush.verticalGradient(listOf(c.surfaceHi, c.surface)))
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.25f), c.border)), CircleShape),
        contentAlignment = Alignment.Center
    ) { Icon(icon, contentDescription = description, tint = c.text, modifier = Modifier.size(24.dp)) }
}

/** Round HUD action (undo / hint / restart). */
@Composable
fun CircleAction(icon: ImageVector, label: String, onClick: () -> Unit, enabled: Boolean = true, highlight: Boolean = false, badge: String? = null) {
    val c = LocalLoop.current
    Column(
        Modifier.widthIn(min = 76.dp).alpha(if (enabled) 1f else 0.4f).gamePress(enabled = enabled, label = label, onClick = onClick).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box {
        Box(
            Modifier.size(64.dp)
                .shadow(if (highlight) 14.dp else 4.dp, CircleShape, ambientColor = c.accent, spotColor = c.accent)
                .clip(CircleShape)
                .background(Brush.verticalGradient(listOf(if (highlight) c.accent.copy(alpha = 0.4f) else c.surfaceHi, c.surface)))
                .border(1.5.dp, if (highlight) c.gold else c.border, CircleShape),
            contentAlignment = Alignment.Center
        ) { Icon(icon, contentDescription = null, tint = if (highlight) c.gold else c.text, modifier = Modifier.size(28.dp)) }
        if (badge != null) {
            Text(
                badge, color = Color(0xFF2A1900), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.TopEnd).clip(CircleShape).background(c.gold)
                    .defaultMinSize(minWidth = 20.dp, minHeight = 20.dp).padding(horizontal = 5.dp, vertical = 2.dp)
            )
        }
        }
        Spacer(Modifier.height(4.dp))
        Text(label, color = c.textDim, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

/** Small pill showing a value with an icon (used in Home HUD). */
@Composable
fun HudChip(icon: ImageVector, value: String, tint: Color, modifier: Modifier = Modifier) {
    val c = LocalLoop.current
    val shape = RoundedCornerShape(50)
    Row(
        modifier.clip(shape).background(c.surface.copy(alpha = 0.85f)).border(1.dp, c.border, shape)
            .padding(start = 8.dp, end = 14.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(26.dp).clip(CircleShape).background(tint.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(16.dp))
        }
        Spacer(Modifier.width(8.dp))
        Text(value, color = c.text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
fun ScreenTopBar(title: String, subtitle: String? = null, onBack: (() -> Unit)? = null, trailing: @Composable (() -> Unit)? = null) {
    val c = LocalLoop.current
    Box(Modifier.fillMaxWidth().heightIn(min = 64.dp).padding(horizontal = 14.dp, vertical = 6.dp), contentAlignment = Alignment.Center) {
        if (onBack != null) GlassIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onBack, Modifier.align(Alignment.CenterStart))
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 60.dp)) {
            Text(title, color = c.text, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.5.sp, textAlign = TextAlign.Center)
            if (subtitle != null) Text(subtitle, color = c.accent, fontSize = 12.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
        }
        if (trailing != null) Box(Modifier.align(Alignment.CenterEnd)) { trailing() }
    }
}

@Composable
fun StarRow(stars: Int, size: Dp, total: Int = 3, spacing: Dp = 2.dp) {
    val c = LocalLoop.current
    Row(
        horizontalArrangement = Arrangement.spacedBy(spacing),
        modifier = Modifier.semantics { contentDescription = "$stars of $total stars" }
    ) {
        repeat(total) { Icon(Icons.Rounded.Star, null, tint = if (it < stars) c.gold else c.border, modifier = Modifier.size(size)) }
    }
}

/** Original logo mark with a breathing aura. */
@Composable
fun LogoMark(size: Dp) {
    val c = LocalLoop.current
    val animate = LocalAnimations.current
    val pulse by (if (animate) rememberInfiniteTransition(label = "logo").animateFloat(
        0.55f, 1f, infiniteRepeatable(tween(2200), RepeatMode.Reverse), label = "pulse"
    ) else remember { androidx.compose.runtime.mutableStateOf(0.8f) })
    Box(Modifier.size(size * 1.5f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.width / 2f
            drawCircle(Brush.radialGradient(listOf(c.accent.copy(alpha = 0.45f * pulse), c.accent2.copy(alpha = 0.18f * pulse), Color.Transparent), center, r), r)
        }
        Canvas(Modifier.size(size).semantics { contentDescription = "Loop Connect logo" }) {
            val s = this.size.width / 108f
            val r = 24f * s
            drawRoundRect(Color(0xFF0A1022), cornerRadius = CornerRadius(r, r))
            drawRoundRect(
                Brush.linearGradient(listOf(c.accent, c.accent2, c.gold)), cornerRadius = CornerRadius(r, r),
                style = Stroke(width = 3f * s)
            )
            fun line(color: Color, build: Path.() -> Unit) {
                val path = Path().apply(build)
                drawPath(path, color.copy(alpha = 0.25f), style = Stroke(width = 12f * s, cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawPath(path, color, style = Stroke(width = 6f * s, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            line(Color(0xFF3DA5FF)) { moveTo(36 * s, 34 * s); lineTo(36 * s, 50 * s); quadraticBezierTo(36 * s, 56 * s, 42 * s, 56 * s); lineTo(54 * s, 56 * s) }
            line(Color(0xFFB06CFF)) { moveTo(54 * s, 56 * s); lineTo(54 * s, 42 * s); quadraticBezierTo(54 * s, 36 * s, 60 * s, 36 * s); lineTo(66 * s, 36 * s); quadraticBezierTo(72 * s, 36 * s, 72 * s, 42 * s); lineTo(72 * s, 48 * s) }
            line(Color(0xFFFFC93D)) { moveTo(54 * s, 56 * s); lineTo(54 * s, 70 * s); quadraticBezierTo(54 * s, 76 * s, 60 * s, 76 * s); lineTo(72 * s, 76 * s) }
            drawCircle(Color(0xFF3DA5FF), 6f * s, Offset(36 * s, 34 * s))
            drawCircle(Color(0xFFFF6FA8), 6f * s, Offset(72 * s, 48 * s))
            drawCircle(Color(0xFFFFC93D), 6f * s, Offset(72 * s, 76 * s))
        }
    }
}
