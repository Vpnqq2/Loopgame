package com.loopconnect.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.loopconnect.audio.SoundFx
import com.loopconnect.data.AnimationMode
import com.loopconnect.data.Repository
import com.loopconnect.data.Settings
import com.loopconnect.data.ThemeId
import com.loopconnect.engine.Hint
import com.loopconnect.engine.LevelGenerator
import com.loopconnect.engine.Objective
import com.loopconnect.engine.Progress
import com.loopconnect.engine.PuzzleBoard
import com.loopconnect.engine.SaveCodec
import com.loopconnect.engine.SavedGame
import com.loopconnect.engine.Scoring
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

data class GameUiState(
    val loading: Boolean = false,
    val ready: Boolean = false,
    val error: String? = null,
    val levelNumber: Int = 0,
    val isDaily: Boolean = false,
    val dailyDay: Long = 0,
    val objective: Objective = Objective.NETWORK,
    val width: Int = 0,
    val height: Int = 0,
    val masks: IntArray = IntArray(0),
    val key: Long = 0,
    val moves: Int = 0,
    val par: Int = 0,
    val satisfied: Int = 0,
    val occupied: Int = 0,
    val solved: Boolean = false,
    val completed: Boolean = false,
    val stars: Int = 0,
    val bestMoves: Int? = null,
    val newBest: Boolean = false,
    val streak: Int = 0,
    val hint: Hint? = null,
    val canUndo: Boolean = false
)

class GameViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repository(app)
    val sound = SoundFx()

    val settings: StateFlow<Settings> =
        repo.settings.stateIn(viewModelScope, SharingStarted.Eagerly, Settings())
    val progress: StateFlow<Progress> =
        repo.progress.stateIn(viewModelScope, SharingStarted.Eagerly, Progress())
    val hasSave: StateFlow<Boolean> =
        repo.savedGame.map { SaveCodec.decode(it) != null }.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    private val _ui = MutableStateFlow(GameUiState())
    val ui: StateFlow<GameUiState> = _ui.asStateFlow()

    private var board: PuzzleBoard? = null
    private var dailyDay: Long? = null
    private var job: Job? = null
    private var pendingMoves = 0

    init {
        viewModelScope.launch {
            settings.collect {
                sound.sfxEnabled = it.sound
                sound.setMusic(it.music)
            }
        }
    }

    fun today(): Long = LocalDate.now().toEpochDay()

    // ---------- starting games ----------

    /** Starts level [n]; resumes the saved board if the save belongs to this level. */
    fun startLevel(n: Int) = load { 
        val saved = SaveCodec.decode(repo.currentSave())
        var b = if (saved != null && saved.dailyDay == null && saved.spec.number == n) restore(saved) else null
        if (b == null) {
            val prog = repo.currentProgress()
            val avoid = if (prog.isCompleted(n)) emptySet() else prog.recentSignatures.toSet()
            val level = withContext(Dispatchers.Default) { LevelGenerator.forLevel(n, avoid) }
            b = PuzzleBoard(level)
            repo.updateProgress { it.withSignature(level.signature) }
        }
        dailyDay = null
        b
    }

    fun startDaily() = load {
        val day = today()
        val saved = SaveCodec.decode(repo.currentSave())
        var b = if (saved != null && saved.dailyDay == day) restore(saved) else null
        if (b == null) b = PuzzleBoard(withContext(Dispatchers.Default) { LevelGenerator.daily(day) })
        dailyDay = day
        b
    }

    /** Resume whatever was saved, or fall back to the next unfinished level. */
    fun continueGame() {
        job?.cancel()
        job = viewModelScope.launch {
            val saved = SaveCodec.decode(repo.currentSave())
            when {
                saved == null -> startLevel(repo.currentProgress().highestUnlocked)
                saved.dailyDay != null -> {
                    val b = restore(saved)
                    if (b == null) startLevel(repo.currentProgress().highestUnlocked)
                    else { dailyDay = saved.dailyDay; attach(b) }
                }
                else -> startLevel(saved.spec.number)
            }
        }
    }

    /** Called by the game screen; recovers after process death. */
    fun ensureLoaded() {
        if (board == null && !_ui.value.loading) continueGame()
    }

    fun nextLevel() {
        val s = _ui.value
        if (s.isDaily) return
        startLevel(s.levelNumber + 1)
    }

    private suspend fun restore(saved: SavedGame): PuzzleBoard? =
        withContext(Dispatchers.Default) { SaveCodec.restore(saved) }

    private fun load(block: suspend () -> PuzzleBoard) {
        job?.cancel()
        flush()
        _ui.value = GameUiState(loading = true)
        job = viewModelScope.launch {
            try {
                val b = block()
                attach(b)
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                board = null
                _ui.value = GameUiState(error = "This level could not be loaded. Please try again.")
            }
        }
    }

    private fun attach(b: PuzzleBoard) {
        board = b
        persistSave()
        publish(b)
    }

    // ---------- gameplay ----------

    /** Returns true if the tile actually rotated (used for haptics). */
    fun rotate(i: Int): Boolean {
        val b = board ?: return false
        val s = _ui.value
        if (s.solved || s.loading || !s.ready) return false
        if (!b.rotate(i)) return false
        pendingMoves++
        sound.playTick()
        persistSave()
        if (b.isSolved()) onSolved(b) else publish(b)
        return true
    }

    fun undo() {
        val b = board ?: return
        if (_ui.value.solved) return
        if (b.undo() != null) {
            sound.playTick()
            persistSave()
            publish(b)
        }
    }

    fun restart() {
        val b = board ?: return
        b.restart()
        persistSave()
        publish(b)
    }

    fun hint() {
        val b = board ?: return
        if (_ui.value.solved) return
        publish(b, hint = b.hint())
    }

    private fun onSolved(b: PuzzleBoard) {
        val stars = Scoring.stars(b.moves, b.par)
        val spec = b.level.spec
        val day = dailyDay
        val moves = pendingMoves
        pendingMoves = 0
        val previous = progress.value.results[spec.number]?.takeIf { day == null }
        publish(b, solved = true)
        sound.playComplete()
        viewModelScope.launch {
            repo.updateProgress { p ->
                val withMoves = p.withMoves(moves)
                if (day != null) withMoves.withDailyCompleted(day)
                else withMoves.withLevelCompleted(spec.number, b.moves, stars)
            }
            repo.writeSave(null)
            delay(if (settings.value.animation == AnimationMode.OFF) 150 else 600)
            val streak = repo.currentProgress().streakOn(today())
            _ui.value = _ui.value.copy(
                completed = true,
                streak = streak,
                bestMoves = minOf(previous?.bestMoves ?: Int.MAX_VALUE, b.moves),
                newBest = previous == null || b.moves < previous.bestMoves
            )
        }
    }

    /** After completion, play the same board again. */
    fun replay() {
        val b = board ?: return
        b.restart()
        persistSave()
        publish(b)
    }

    private fun persistSave() {
        val b = board ?: return
        val encoded = SaveCodec.encode(SaveCodec.snapshot(b, dailyDay))
        viewModelScope.launch { repo.writeSave(encoded) }
    }

    private fun publish(b: PuzzleBoard, hint: Hint? = null, solved: Boolean = false) {
        val spec = b.level.spec
        _ui.value = GameUiState(
            ready = true,
            levelNumber = spec.number,
            isDaily = dailyDay != null,
            dailyDay = dailyDay ?: 0,
            objective = spec.objective,
            width = spec.width,
            height = spec.height,
            masks = b.masksCopy(),
            key = spec.seed xor spec.number.toLong(),
            moves = b.moves,
            par = b.level.par,
            satisfied = b.satisfied(),
            occupied = b.occupied,
            solved = solved,
            stars = Scoring.stars(b.moves, b.level.par),
            hint = hint,
            canUndo = b.canUndo
        )
    }

    /** Persist pending statistics (called when the app goes to the background). */
    fun flush() {
        if (pendingMoves > 0) {
            val m = pendingMoves
            pendingMoves = 0
            viewModelScope.launch { repo.updateProgress { it.withMoves(m) } }
        }
    }

    // ---------- settings & reset ----------

    fun setSound(v: Boolean) = viewModelScope.launch { repo.updateSettings { it.copy(sound = v) } }
    fun setMusic(v: Boolean) = viewModelScope.launch { repo.updateSettings { it.copy(music = v) } }
    fun setHaptics(v: Boolean) = viewModelScope.launch { repo.updateSettings { it.copy(haptics = v) } }
    fun setTheme(v: ThemeId) = viewModelScope.launch { repo.updateSettings { it.copy(theme = v) } }
    fun setAnimation(v: AnimationMode) = viewModelScope.launch { repo.updateSettings { it.copy(animation = v) } }

    fun resetProgress() {
        job?.cancel()
        board = null
        dailyDay = null
        pendingMoves = 0
        _ui.value = GameUiState()
        viewModelScope.launch { repo.resetProgress() }
    }

    override fun onCleared() {
        sound.release()
    }
}
