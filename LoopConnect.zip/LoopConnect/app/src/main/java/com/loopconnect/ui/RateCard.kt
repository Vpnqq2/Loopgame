package com.loopconnect.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Opens this app's Google Play page (Play Store app first, browser as fallback). */
fun openPlayStore(ctx: Context) {
    val pkg = ctx.packageName
    fun view(uri: String) = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        ctx.startActivity(view("market://details?id=$pkg"))
    } catch (_: Exception) {
        runCatching { ctx.startActivity(view("https://play.google.com/store/apps/details?id=$pkg")) }
    }
}

private val RATE_LABELS = listOf(
    "Tap a star", "We'll work on it", "Thanks for the honesty", "Glad you're playing", "Great, thank you!", "You're awesome!"
)

private class Spark(val angle: Float, val dist: Float, val size: Float, val gold: Boolean)

/**
 * A friendly "rate the game" card. Stars can be tapped or dragged across. "Rate" opens Google Play,
 * "Not now" simply closes it. All motion respects the Animation setting.
 */
@Composable
fun RateDialog(onRate: (stars: Int) -> Unit, onLater: (stars: Int) -> Unit) {
    val c = LocalLoop.current
    val animate = LocalAnimations.current
    var rating by rememberSaveable { mutableIntStateOf(0) }
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }
    val enter by animateFloatAsState(
        if (visible) 1f else 0f, if (animate) spring(dampingRatio = 0.62f, stiffness = 380f) else snap(), label = "rateEnter"
    )

    Dialog(onDismissRequest = { onLater(rating) }) {
        Box(Modifier.graphicsLayer {
            val s = 0.86f + 0.14f * enter
            scaleX = s; scaleY = s; alpha = enter.coerceIn(0f, 1f); translationY = (1f - enter) * 48f
        }) {
            LoopCard(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    LogoMark(76.dp)
                    Spacer(Modifier.height(10.dp))
                    Text("Enjoying Loop Connect?", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "A quick rating helps a small game grow.", color = c.textDim, fontSize = 14.sp,
                        lineHeight = 20.sp, textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(18.dp))
                    StarPicker(rating, animate) { rating = it }
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.height(22.dp), contentAlignment = Alignment.Center) {
                        Crossfade(rating, animationSpec = tween(if (animate) 200 else 0), label = "rateLabel") {
                            Text(
                                RATE_LABELS[it], fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                                color = if (it == 0) c.textDim else c.gold
                            )
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlineButton("Not now", { onLater(rating) }, Modifier.weight(1f))
                        PrimaryButton("Rate", { onRate(rating) }, Modifier.weight(1f), enabled = rating > 0)
                    }
                    Spacer(Modifier.height(2.dp))
                    Text("Opens Google Play", color = c.textDim.copy(alpha = 0.7f), fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun StarPicker(rating: Int, animate: Boolean, onSet: (Int) -> Unit) {
    val c = LocalLoop.current
    var widthPx by remember { mutableIntStateOf(1) }
    val sparks = remember {
        val r = Random(5)
        List(18) { Spark(r.nextFloat() * 6.2832f, 40f + r.nextFloat() * 70f, 2.5f + r.nextFloat() * 3.5f, r.nextBoolean()) }
    }
    val burst = remember { Animatable(0f) }
    LaunchedEffect(rating) {
        if (rating == 5 && animate) { burst.snapTo(0f); burst.animateTo(1f, tween(800, easing = FastOutSlowInEasing)) }
    }
    fun indexAt(x: Float) = ((x / widthPx) * 5f).toInt().coerceIn(0, 4) + 1

    Box(contentAlignment = Alignment.Center) {
        Row(
            Modifier
                .onSizeChanged { widthPx = it.width.coerceAtLeast(1) }
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown()
                        onSet(indexAt(down.position.x))
                        do {
                            val ev = awaitPointerEvent()
                            ev.changes.firstOrNull()?.let { if (it.pressed) onSet(indexAt(it.position.x)) }
                        } while (ev.changes.any { it.pressed })
                    }
                },
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            for (i in 1..5) StarItem(i, rating, animate) { onSet(i) }
        }
        Canvas(Modifier.matchParentSize()) {
            val t = burst.value
            if (t <= 0f || t >= 1f) return@Canvas
            val origin = Offset(size.width / 2f, size.height / 2f)
            for (s in sparks) {
                val d = s.dist * density * t
                val p = Offset(origin.x + cos(s.angle) * d * 1.7f, origin.y + sin(s.angle) * d)
                val col = if (s.gold) c.gold else c.accent
                drawCircle(col.copy(alpha = (1f - t) * 0.9f), s.size * density * (1f - t * 0.5f), p)
            }
        }
    }
}

@Composable
private fun StarItem(index: Int, rating: Int, animate: Boolean, pick: () -> Unit) {
    val c = LocalLoop.current
    val on = index <= rating
    val pop = remember { Animatable(1f) }
    LaunchedEffect(rating) {
        if (on && animate) {
            delay((index - 1) * 45L)
            pop.animateTo(1.35f, tween(110))
            pop.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 500f))
        } else pop.snapTo(1f)
    }
    val tint by animateColorAsState(if (on) c.gold else c.border, tween(if (animate) 160 else 0), label = "starTint")
    val glow by animateFloatAsState(if (on) 1f else 0f, tween(if (animate) 220 else 0), label = "starGlow")
    Box(
        Modifier.size(46.dp)
            .semantics { role = Role.Button; contentDescription = "$index ${if (index == 1) "star" else "stars"}"; onClick { pick(); true } }
            .graphicsLayer { scaleX = pop.value; scaleY = pop.value; rotationZ = (pop.value - 1f) * 14f },
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier.matchParentSize().clip(CircleShape)
                .background(Brush.radialGradient(listOf(c.gold.copy(alpha = 0.32f * glow), Color.Transparent)))
        )
        Icon(Icons.Rounded.Star, null, tint = tint, modifier = Modifier.size(42.dp))
    }
}
