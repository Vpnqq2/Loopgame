package com.loopconnect.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.ui.graphics.lerp
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.loopconnect.data.ThemeId
import androidx.compose.ui.unit.dp
import kotlin.math.sin
import kotlin.math.cos
import kotlin.math.PI

@Immutable
data class LoopColors(
    val bgTop: Color, val bgBottom: Color, val surface: Color, val surfaceHi: Color, val border: Color,
    val tile: Color, val accent: Color, val accent2: Color, val text: Color, val textDim: Color,
    val good: Color, val bad: Color, val gold: Color,
    /** Extra line colours for the board palette (kept readable on both dark and light backgrounds). */
    val pop1: Color = Color(0xFFFF6FA8), val pop2: Color = Color(0xFF35E0FF),
    val isLight: Boolean = false
)

/** Blend two palettes; used to cross-fade smoothly when the theme changes. */
private fun lerpColors(a: LoopColors, b: LoopColors, t: Float): LoopColors = LoopColors(
    bgTop = lerp(a.bgTop, b.bgTop, t), bgBottom = lerp(a.bgBottom, b.bgBottom, t),
    surface = lerp(a.surface, b.surface, t), surfaceHi = lerp(a.surfaceHi, b.surfaceHi, t),
    border = lerp(a.border, b.border, t), tile = lerp(a.tile, b.tile, t),
    accent = lerp(a.accent, b.accent, t), accent2 = lerp(a.accent2, b.accent2, t),
    text = lerp(a.text, b.text, t), textDim = lerp(a.textDim, b.textDim, t),
    good = lerp(a.good, b.good, t), bad = lerp(a.bad, b.bad, t), gold = lerp(a.gold, b.gold, t),
    pop1 = lerp(a.pop1, b.pop1, t), pop2 = lerp(a.pop2, b.pop2, t),
    isLight = if (t < 0.5f) a.isLight else b.isLight
)

private val Midnight = LoopColors(
    bgTop = Color(0xFF111B36), bgBottom = Color(0xFF070C1B), surface = Color(0xFF131D38), surfaceHi = Color(0xFF1B2748),
    border = Color(0xFF2A3965), tile = Color(0xFF16213F), accent = Color(0xFF3DA5FF), accent2 = Color(0xFF8A5CFF),
    text = Color(0xFFF2F5FF), textDim = Color(0xFF8D9AC0), good = Color(0xFF3DDC84), bad = Color(0xFFFF7A6B), gold = Color(0xFFFFC93D)
)
private val Amoled = LoopColors(
    bgTop = Color(0xFF000000), bgBottom = Color(0xFF000000), surface = Color(0xFF0C0C10), surfaceHi = Color(0xFF16161D),
    border = Color(0xFF26262F), tile = Color(0xFF0F0F14), accent = Color(0xFF35E0FF), accent2 = Color(0xFFFF4FA3),
    text = Color(0xFFFFFFFF), textDim = Color(0xFF8A8A99), good = Color(0xFF50F0A0), bad = Color(0xFFFF6B6B), gold = Color(0xFFFFD24D)
)
private val Aurora = LoopColors(
    bgTop = Color(0xFF13262B), bgBottom = Color(0xFF081216), surface = Color(0xFF142A30), surfaceHi = Color(0xFF1D3B42),
    border = Color(0xFF2B5560), tile = Color(0xFF16313A), accent = Color(0xFF4DF0C0), accent2 = Color(0xFFB38CFF),
    text = Color(0xFFEFFFFA), textDim = Color(0xFF86AEB3), good = Color(0xFFA6F55B), bad = Color(0xFFFF8A65), gold = Color(0xFFFFD166)
)

/** Deep violet night with orchid accents. */
private val Orchid = LoopColors(
    bgTop = Color(0xFF241438), bgBottom = Color(0xFF0F0719), surface = Color(0xFF271740), surfaceHi = Color(0xFF33205A),
    border = Color(0xFF4F3685), tile = Color(0xFF2C1A4A), accent = Color(0xFFA66BFF), accent2 = Color(0xFFFF5FA8),
    text = Color(0xFFF7F0FF), textDim = Color(0xFFA595C9), good = Color(0xFF4BE3A0), bad = Color(0xFFFF7B5C), gold = Color(0xFFFFC93D),
    pop1 = Color(0xFFFFA06B), pop2 = Color(0xFF5ED8FF)
)
/** Clean light theme: soft blue-white surfaces, deeper accents so buttons, lines and text stay readable. */
private val Daylight = LoopColors(
    bgTop = Color(0xFFF6F9FF), bgBottom = Color(0xFFE2E9FA), surface = Color(0xFFFFFFFF), surfaceHi = Color(0xFFF0F4FF),
    border = Color(0xFFC5D0EC), tile = Color(0xFFE9EFFD), accent = Color(0xFF2F7BEA), accent2 = Color(0xFF7B4DEB),
    text = Color(0xFF14203F), textDim = Color(0xFF5A6890), good = Color(0xFF1FA85F), bad = Color(0xFFE5484D), gold = Color(0xFFE59A00),
    pop1 = Color(0xFFE0457F), pop2 = Color(0xFF0A97B5), isLight = true
)

fun colorsFor(theme: ThemeId): LoopColors = when (theme) {
    ThemeId.MIDNIGHT -> Midnight
    ThemeId.AMOLED -> Amoled
    ThemeId.AURORA -> Aurora
    ThemeId.ORCHID -> Orchid
    ThemeId.DAYLIGHT -> Daylight
}

val LocalLoop = compositionLocalOf { Orchid }

/**
 * Returns the palette for [target], gliding from the previous one whenever it changes
 * (one 0..1 progress value drives every colour, so the whole app fades together).
 * With animations off the switch is instant.
 */
@Composable
private fun rememberAnimatedColors(target: LoopColors, smooth: Boolean): LoopColors {
    var from by remember { mutableStateOf(target) }
    var to by remember { mutableStateOf(target) }
    var progress by remember { mutableStateOf(1f) }
    LaunchedEffect(target) {
        if (target == to) return@LaunchedEffect
        // Start from whatever is on screen right now, so a change in mid-fade doesn't jump.
        from = if (progress >= 1f) to else lerpColors(from, to, progress)
        to = target
        progress = 0f
        if (smooth) animate(0f, 1f, animationSpec = tween(480, easing = FastOutSlowInEasing)) { v, _ -> progress = v }
        progress = 1f
    }
    return if (progress >= 1f) to else lerpColors(from, to, progress)
}

@Composable
fun LoopTheme(theme: ThemeId, animate: Boolean = true, content: @Composable () -> Unit) {
    val c = rememberAnimatedColors(colorsFor(theme), animate)
    val scheme = if (theme.isLight) {
        lightColorScheme(
            primary = c.accent, onPrimary = Color.White, background = c.bgBottom, surface = c.surface,
            onSurface = c.text, onBackground = c.text, surfaceVariant = c.surfaceHi, outline = c.border
        )
    } else {
        darkColorScheme(
            primary = c.accent, onPrimary = Color.White, background = c.bgBottom, surface = c.surface,
            onSurface = c.text, onBackground = c.text, surfaceVariant = c.surfaceHi, outline = c.border
        )
    }
    CompositionLocalProvider(LocalLoop provides c) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

val LocalAnimations = staticCompositionLocalOf { true }

private class Drift(val x: Float, val y: Float, val size: Float, val kind: Int, val speed: Float, val rot: Float)

/** Slowly drifting line-art and soft glows behind every screen, so menus feel like part of the game. */
@Composable
private fun AmbientBackground() {
    val c = LocalLoop.current
    val animate = LocalAnimations.current
    val items = remember {
        val r = kotlin.random.Random(11)
        List(16) { Drift(r.nextFloat(), r.nextFloat(), 14f + r.nextFloat() * 30f, r.nextInt(3), 0.4f + r.nextFloat() * 0.8f, r.nextFloat() * 360f) }
    }
    val tState: State<Float> = if (animate) {
        rememberInfiniteTransition(label = "ambient").animateFloat(0f, 1f, infiniteRepeatable(tween(90000, easing = LinearEasing)), label = "t")
    } else remember { mutableStateOf(0f) }
    Canvas(Modifier.fillMaxSize()) {
        val t = tState.value
        val topC = Offset(size.width / 2f, size.height * 0.1f)
        drawCircle(Brush.radialGradient(listOf(c.accent.copy(alpha = 0.16f), Color.Transparent), topC, size.width), size.width, topC)
        val botC = Offset(size.width * 0.9f, size.height * 0.97f)
        drawCircle(Brush.radialGradient(listOf(c.accent2.copy(alpha = 0.12f), Color.Transparent), botC, size.width * 0.8f), size.width * 0.8f, botC)
        for (d in items) {
            val v = d.y - t * d.speed * 3f
            val yy = ((v % 1f) + 1f) % 1f
            val x = d.x * size.width
            val y = yy * size.height
            val col = (if (d.kind % 2 == 0) c.accent else c.accent2).copy(alpha = 0.08f)
            when (d.kind) {
                0 -> drawLine(col, Offset(x, y), Offset(x + d.size * 2f, y), 5f, StrokeCap.Round)
                1 -> drawCircle(col, 7f, Offset(x, y))
                else -> drawArc(col, d.rot, 90f, false, Offset(x, y), Size(d.size * 2f, d.size * 2f), style = Stroke(5f, cap = StrokeCap.Round))
            }
        }
    }
}

private class Meteor(val x: Float, val y: Float, val angle: Float, val travel: Float, val tail: Float, val width: Float, val phase: Float, val dur: Float)
private class Twinkle(val x: Float, val y: Float, val r: Float, val k: Int, val phase: Float)

/**
 * A calm night-sky layer behind every screen: tiny stars that twinkle softly and a translucent
 * white shooting star that glides across every few seconds. Everything is driven by one slow
 * looping clock, so the loop is seamless, and it stays very faint to be easy on the eyes.
 */
@Composable
internal fun SkyFx(withStars: Boolean = true) {
    val c = LocalLoop.current
    val animate = LocalAnimations.current
    val meteors = remember {
        val r = kotlin.random.Random(7)
        List(6) { k ->
            Meteor(
                x = 0.3f + r.nextFloat() * 0.75f, y = -0.05f + r.nextFloat() * 0.55f,
                angle = (22f + r.nextFloat() * 16f) * (PI / 180.0).toFloat(),
                travel = 0.55f + r.nextFloat() * 0.3f, tail = 0.18f + r.nextFloat() * 0.1f,
                width = 1.2f + r.nextFloat(), phase = (k + r.nextFloat() * 0.6f) / 6f, dur = 0.08f + r.nextFloat() * 0.03f
            )
        }
    }
    val stars = remember {
        val r = kotlin.random.Random(23)
        List(28) { Twinkle(r.nextFloat(), r.nextFloat(), 0.8f + r.nextFloat() * 1.1f, 5 + r.nextInt(9), r.nextFloat()) }
    }
    val tState: State<Float> = if (animate) {
        rememberInfiniteTransition(label = "sky").animateFloat(0f, 1f, infiniteRepeatable(tween(30000, easing = LinearEasing)), label = "t")
    } else remember { mutableStateOf(0f) }
    Canvas(Modifier.fillMaxSize()) {
        val t = tState.value
        val w = size.width
        val h = size.height
        val dp1 = 1.dp.toPx()
        val ink = if (c.isLight) c.accent else Color.White   // white would vanish on the light theme
        val base = if (c.isLight) 0.10f else 0.08f
        if (withStars) for (s in stars) {
            val tw = 0.5f + 0.5f * sin(2f * PI.toFloat() * (t * s.k + s.phase))
            drawCircle(ink.copy(alpha = base + 0.24f * tw), s.r * dp1, Offset(s.x * w, s.y * h))
        }
        if (!animate) return@Canvas
        for (m in meteors) {
            val p = ((((t - m.phase) % 1f) + 1f) % 1f) / m.dur
            if (p < 0f || p > 1f) continue
            val a = sin(PI.toFloat() * p) * 0.6f            // fades in, glides, fades out
            val dx = -cos(m.angle)
            val dy = sin(m.angle)
            val head = Offset(m.x * w + dx * m.travel * w * p, m.y * h + dy * m.travel * w * p)
            val tailStart = Offset(head.x - dx * m.tail * w, head.y - dy * m.tail * w)
            drawLine(
                Brush.linearGradient(listOf(Color.Transparent, ink.copy(alpha = a)), tailStart, head),
                tailStart, head, strokeWidth = m.width * dp1, cap = StrokeCap.Round
            )
            drawCircle(Brush.radialGradient(listOf(ink.copy(alpha = a * 0.55f), Color.Transparent), head, 9f * dp1), 9f * dp1, head)
            drawCircle(ink.copy(alpha = a), m.width * 0.9f * dp1, head)
        }
    }
}

@Composable
fun ScreenBackground(content: @Composable () -> Unit) {
    val c = LocalLoop.current
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom)))) {
        AmbientBackground()
        SkyFx()
        Box(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) { content() }
    }
}
