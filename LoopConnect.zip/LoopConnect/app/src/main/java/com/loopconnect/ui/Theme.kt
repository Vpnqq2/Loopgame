package com.loopconnect.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.loopconnect.data.ThemeId

@Immutable
data class LoopColors(
    val bgTop: Color, val bgBottom: Color, val surface: Color, val surfaceHi: Color, val border: Color,
    val tile: Color, val accent: Color, val accent2: Color, val text: Color, val textDim: Color,
    val good: Color, val bad: Color, val gold: Color
)

private val Midnight = LoopColors(
    bgTop = Color(0xFF111B36), bgBottom = Color(0xFF070C1B), surface = Color(0xFF131D38), surfaceHi = Color(0xFF1B2748),
    border = Color(0xFF2A3965), tile = Color(0xFF16213F), accent = Color(0xFF3DA5FF), accent2 = Color(0xFF8A5CFF),
    text = Color(0xFFF2F5FF), textDim = Color(0xFF8D9AC0), good = Color(0xFF3DDC84), bad = Color(0xFFFF7A6B), gold = Color(0xFFFFC93D)
)
private val Amoled = LoopColors(
    bgTop = Color(0xFF000000), bgBottom = Color(0xFF000000), surface = Color(0xFF0C0C10), surfaceHi = Color(0xFF16161D),
    border = Color(0xFF26262F), tile = Color(0xFF0F0F14), accent = Color(0xFF35E0FF), accent2 = Color(0xFFFF4FA3),
    text = Color(0xFFFFFFFF), textDim = Color(0xFF8A8A99), good = Color(0xFF50F0A0), bad = Color(0xFFFF6B6B), gold = Color(0xFFFFD24D)
)
private val Aurora = LoopColors(
    bgTop = Color(0xFF13262B), bgBottom = Color(0xFF081216), surface = Color(0xFF142A30), surfaceHi = Color(0xFF1D3B42),
    border = Color(0xFF2B5560), tile = Color(0xFF16313A), accent = Color(0xFF4DF0C0), accent2 = Color(0xFFB38CFF),
    text = Color(0xFFEFFFFA), textDim = Color(0xFF86AEB3), good = Color(0xFFA6F55B), bad = Color(0xFFFF8A65), gold = Color(0xFFFFD166)
)

fun colorsFor(theme: ThemeId): LoopColors = when (theme) {
    ThemeId.MIDNIGHT -> Midnight
    ThemeId.AMOLED -> Amoled
    ThemeId.AURORA -> Aurora
}

val LocalLoop = staticCompositionLocalOf { Midnight }

@Composable
fun LoopTheme(theme: ThemeId, content: @Composable () -> Unit) {
    val c = colorsFor(theme)
    CompositionLocalProvider(LocalLoop provides c) {
        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = c.accent, onPrimary = Color.White, background = c.bgBottom, surface = c.surface,
                onSurface = c.text, onBackground = c.text, surfaceVariant = c.surfaceHi, outline = c.border
            ),
            content = content
        )
    }
}

@Composable
fun ScreenBackground(content: @Composable () -> Unit) {
    val c = LocalLoop.current
    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom)))
            .statusBarsPadding().navigationBarsPadding()
    ) { content() }
}
