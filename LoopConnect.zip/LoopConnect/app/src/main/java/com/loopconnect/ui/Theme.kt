package com.loopconnect.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.loopconnect.data.ThemeId

@Immutable
data class LoopColors(
    val bgTop: Color, val bgBottom: Color, val surface: Color, val surfaceHi: Color, val border: Color,
    val tile: Color, val accent: Color, val accent2: Color, val text: Color, val textDim: Color,
    val good: Color, val bad: Color, val gold: Color
)

private val Midnight = LoopColors(
    bgTop = Color(0xFF111B36), bgBottom = Color(0xFF070C1B), surface = Color(0xFF131D38), surfaceHi = Color(0xFF1B2748),
    border = Color(0xFF2A3965), tile = Color(0xFF16213F), accent = Color(0xFF3DA5FF), accent2 = Color(0xFF8A5CFF),
    text = Color(0xFFF2F5FF), textDim = Color(0xFF8D9AC0), good = Color(0xFF3DDC84), bad = Color(0xFFFF7A6B), gold = Color(0xFFFFC93D)
)
private val Amoled = LoopColors(
    bgTop = Color(0xFF000000), bgBottom = Color(0xFF000000), surface = Color(0xFF0C0C10), surfaceHi = Color(0xFF16161D),
    border = Color(0xFF26262F), tile = Color(0xFF0F0F14), accent = Color(0xFF35E0FF), accent2 = Color(0xFFFF4FA3),
    text = Color(0xFFFFFFFF), textDim = Color(0xFF8A8A99), good = Color(0xFF50F0A0), bad = Color(0xFFFF6B6B), gold = Color(0xFFFFD24D)
)
private val Aurora = LoopColors(
    bgTop = Color(0xFF13262B), bgBottom = Color(0xFF081216), surface = Color(0xFF142A30), surfaceHi = Color(0xFF1D3B42),
    border = Color(0xFF2B5560), tile = Color(0xFF16313A), accent = Color(0xFF4DF0C0), accent2 = Color(0xFFB38CFF),
    text = Color(0xFFEFFFFA), textDim = Color(0xFF86AEB3), good = Color(0xFFA6F55B), bad = Color(0xFFFF8A65), gold = Color(0xFFFFD166)
)

fun colorsFor(theme: ThemeId): LoopColors = when (theme) {
    ThemeId.MIDNIGHT -> Midnight
    ThemeId.AMOLED -> Amoled
    ThemeId.AURORA -> Aurora
}

val LocalLoop = staticCompositionLocalOf { Midnight }

@Composable
fun LoopTheme(theme: ThemeId, content: @Composable () -> Unit) {
    val c = colorsFor(theme)
    CompositionLocalProvider(LocalLoop provides c) {
        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = c.accent, onPrimary = Color.White, background = c.bgBottom, surface = c.surface,
                onSurface = c.text, onBackground = c.text, surfaceVariant = c.surfaceHi, outline = c.border
            ),
            content = content
        )
    }
}

val LocalAnimations = staticCompositionLocalOf { true }

private class Drift(val x: Float, val y: Float, val size: Float, val kind: Int, val speed: Float, val rot: Float)

/** Slowly drifting line-art and soft glows behind every screen, so menus feel like part of the game. */
@Composable
private fun AmbientBackground() {
    val c = LocalLoop.current
    val animate = LocalAnimations.current
    val items = remember {
        val r = kotlin.random.Random(11)
        List(16) { Drift(r.nextFloat(), r.nextFloat(), 14f + r.nextFloat() * 30f, r.nextInt(3), 0.4f + r.nextFloat() * 0.8f, r.nextFloat() * 360f) }
    }
    val tState: State<Float> = if (animate) {
        rememberInfiniteTransition(label = "ambient").animateFloat(0f, 1f, infiniteRepeatable(tween(90000, easing = LinearEasing)), label = "t")
    } else remember { mutableStateOf(0f) }
    Canvas(Modifier.fillMaxSize()) {
        val t = tState.value
        val topC = Offset(size.width / 2f, size.height * 0.1f)
        drawCircle(Brush.radialGradient(listOf(c.accent.copy(alpha = 0.16f), Color.Transparent), topC, size.width), size.width, topC)
        val botC = Offset(size.width * 0.9f, size.height * 0.97f)
        drawCircle(Brush.radialGradient(listOf(c.accent2.copy(alpha = 0.12f), Color.Transparent), botC, size.width * 0.8f), size.width * 0.8f, botC)
        for (d in items) {
            val v = d.y - t * d.speed * 3f
            val yy = ((v % 1f) + 1f) % 1f
            val x = d.x * size.width
            val y = yy * size.height
            val col = (if (d.kind % 2 == 0) c.accent else c.accent2).copy(alpha = 0.08f)
            when (d.kind) {
                0 -> drawLine(col, Offset(x, y), Offset(x + d.size * 2f, y), 5f, StrokeCap.Round)
                1 -> drawCircle(col, 7f, Offset(x, y))
                else -> drawArc(col, d.rot, 90f, false, Offset(x, y), Size(d.size * 2f, d.size * 2f), style = Stroke(5f, cap = StrokeCap.Round))
            }
        }
    }
}

@Composable
fun ScreenBackground(content: @Composable () -> Unit) {
    val c = LocalLoop.current
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom)))) {
        AmbientBackground()
        Box(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) { content() }
    }
}
