package com.loopconnect.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.loopconnect.engine.Achievement
import com.loopconnect.engine.AchievementCategory
import com.loopconnect.engine.Achievements
import com.loopconnect.engine.Progress
import com.loopconnect.engine.Tier
import com.loopconnect.ui.*

@Composable
fun AwardsScreen(vm: GameViewModel, onBack: () -> Unit) {
    val c = LocalLoop.current
    val p by vm.progress.collectAsStateWithLifecycle()
    val all = Achievements.all
    val unlocked = Achievements.unlockedCount(p)

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("AWARDS", "$unlocked of ${all.size} unlocked", onBack)
        LazyColumn(
            Modifier.weight(1f).staggerIn(0), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item(key = "summary") { SummaryCard(p, unlocked, all.size) }
            AchievementCategory.values().forEach { cat ->
                val inCat = all.filter { it.category == cat }
                item(key = "h_${cat.name}") {
                    Row(Modifier.padding(start = 6.dp, top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(cat.title.uppercase(), color = c.textDim, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.weight(1f))
                        Text("${inCat.count { it.unlocked(p) }}/${inCat.size}", color = c.textDim, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 6.dp))
                    }
                }
                items(inCat, key = { it.id }) { a -> AwardCard(a, p) { vm.previewUnlock(a) } }
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun SummaryCard(p: Progress, unlocked: Int, total: Int) {
    val c = LocalLoop.current
    val target = if (total == 0) 0f else unlocked.toFloat() / total
    val fraction by animateFloatAsState(target, tween(900), label = "ring")
    LoopCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(104.dp).semantics { contentDescription = "$unlocked of $total achievements unlocked" }, contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 12.dp.toPx()
                    val inset = stroke / 2f
                    val arcSize = Size(size.width - stroke, size.height - stroke)
                    drawArc(c.bgBottom, 0f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(stroke))
                    drawArc(Brush.sweepGradient(listOf(c.accent, c.accent2, c.gold, c.accent)), -90f, 360f * fraction, false, Offset(inset, inset), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$unlocked", color = c.text, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    Text("of $total", color = c.textDim, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.width(18.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Tier.values().forEach { tier ->
                    val list = Achievements.all.filter { it.tier == tier }
                    val (light, dark) = tierColors(tier)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(16.dp).clip(CircleShape).background(Brush.verticalGradient(listOf(light, dark))))
                        Spacer(Modifier.width(8.dp))
                        Text("${tierName(tier)}  ${list.count { it.unlocked(p) }}/${list.size}", color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }
                }
                Text("Each award pays hints", color = c.textDim, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun AwardCard(a: Achievement, p: Progress, onClick: () -> Unit) {
    val c = LocalLoop.current
    val done = a.unlocked(p)
    val (light, dark) = tierColors(a.tier)
    val v = a.current(p)
    val base = Modifier.fillMaxWidth().semantics {
        contentDescription = "${a.title}, ${a.description}, ${tierName(a.tier)}, " +
            if (done) "unlocked" else "locked, $v of ${a.goal}"
    }
    LoopCard(if (done) base.gamePress(label = "Show ${a.title}", onClick = onClick) else base) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(58.dp).clip(CircleShape)
                    .background(if (done) Brush.verticalGradient(listOf(light, dark)) else Brush.verticalGradient(listOf(c.surfaceHi, c.surface)))
                    .border(2.dp, if (done) Color.White.copy(alpha = 0.6f) else dark.copy(alpha = 0.45f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(achievementIcon(a.icon), null, tint = if (done) Color(0xFF2A1900) else c.textDim.copy(alpha = 0.6f), modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(a.title, color = c.text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(a.description, color = c.textDim, fontSize = 12.sp)
                if (!done) {
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(c.bgBottom)) {
                        Box(
                            Modifier.fillMaxWidth(animatedFraction(v.toFloat() / a.goal)).fillMaxHeight().clip(RoundedCornerShape(4.dp))
                                .background(Brush.horizontalGradient(listOf(light, dark)))
                        )
                    }
                    Text("$v / ${a.goal}", color = c.textDim, fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp))
                } else {
                    Text("Unlocked  ·  tap to view", color = c.good, fontSize = 11.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 4.dp))
                }
            }
            Spacer(Modifier.width(8.dp))
            if (done) {
                Icon(Icons.Rounded.Check, "Unlocked", tint = c.good)
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.Lock, null, tint = c.textDim, modifier = Modifier.size(16.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Lightbulb, null, tint = c.gold, modifier = Modifier.size(14.dp))
                        Text("+${a.reward}", color = c.gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
