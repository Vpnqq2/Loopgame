package com.loopconnect.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.loopconnect.engine.Twist
import com.loopconnect.ui.*

/*
 * Visual marks for the Classic rules (see Twist): wall squares for odd board shapes, plates and padlocks for locked
 * pieces, coloured link badges for twin pieces. Shared by the game board, the tutorial boards and the rule tips.
 */

/** Colour index (0, 1, 2 ...) of every twin piece, so both pieces of a pair share a colour. -1 for pieces without a twin. */
internal fun pairColorIndex(partner: IntArray): IntArray {
    val idx = IntArray(partner.size) { -1 }
    var next = 0
    for (i in partner.indices) {
        val p = partner[i]
        if (p > i && idx[i] < 0) { idx[i] = next; idx[p] = next; next++ }
    }
    return idx
}

internal fun twinPalette(c: LoopColors): List<Color> = listOf(c.gold, c.pop1, c.pop2, c.accent2)

/** Everything that sits behind the line art: wall squares, locked plates and twin outlines. */
internal fun DrawScope.drawPlates(ui: GameUiState, cell: Float, c: LoopColors) {
    val n = ui.width * ui.height
    val pad = cell * 0.07f
    val side = cell - pad * 2
    val corner = CornerRadius(cell * 0.2f)
    fun topLeft(i: Int) = Offset((i % ui.width) * cell + pad, (i / ui.width) * cell + pad)

    ui.playable?.let { pl ->
        for (i in 0 until n) {
            if (pl.getOrNull(i) != false) continue
            drawRoundRect(c.textDim.copy(alpha = 0.14f), topLeft(i), Size(side, side), corner)
            drawRoundRect(c.textDim.copy(alpha = 0.30f), topLeft(i), Size(side, side), corner, style = Stroke(cell * 0.025f))
            // a small cross makes it read as a wall rather than an empty cell
            val m = cell * 0.16f
            val a = Offset((i % ui.width) * cell + cell / 2 - m, (i / ui.width) * cell + cell / 2 - m)
            val b = Offset((i % ui.width) * cell + cell / 2 + m, (i / ui.width) * cell + cell / 2 + m)
            drawLine(c.textDim.copy(alpha = 0.30f), a, b, cell * 0.03f, StrokeCap.Round)
            drawLine(c.textDim.copy(alpha = 0.30f), Offset(a.x, b.y), Offset(b.x, a.y), cell * 0.03f, StrokeCap.Round)
        }
    }
    ui.locked?.let { lk ->
        for (i in 0 until n) {
            if (lk.getOrNull(i) != true) continue
            drawRoundRect(c.gold.copy(alpha = 0.07f), topLeft(i), Size(side, side), corner)
            drawRoundRect(c.gold.copy(alpha = 0.40f), topLeft(i), Size(side, side), corner, style = Stroke(cell * 0.03f))
        }
    }
    ui.partner?.let { pt ->
        val colors = twinPalette(c)
        val idx = pairColorIndex(pt)
        for (i in 0 until n) {
            if (pt.getOrNull(i) == null || pt[i] < 0) continue
            val col = colors[idx[i].coerceAtLeast(0) % colors.size]
            drawRoundRect(col.copy(alpha = 0.10f), topLeft(i), Size(side, side), corner)
            drawRoundRect(col.copy(alpha = 0.70f), topLeft(i), Size(side, side), corner, style = Stroke(cell * 0.04f))
        }
    }
}

/** Padlock and link badges, drawn on top of the line art in the top-right corner of a piece. */
internal fun DrawScope.drawBadges(ui: GameUiState, cell: Float, c: LoopColors) {
    val n = ui.width * ui.height
    fun badge(i: Int) = Offset((i % ui.width) * cell + cell * 0.77f, (i / ui.width) * cell + cell * 0.23f)

    ui.locked?.let { lk ->
        for (i in 0 until n) {
            if (lk.getOrNull(i) != true) continue
            val ctr = badge(i)
            drawCircle(c.bgBottom.copy(alpha = 0.88f), cell * 0.17f, ctr)
            drawPadlock(ctr, cell * 0.27f, c.gold, lerp(c.gold, Color.White, 0.35f))
        }
    }
    ui.partner?.let { pt ->
        val colors = twinPalette(c)
        val idx = pairColorIndex(pt)
        for (i in 0 until n) {
            if (pt.getOrNull(i) == null || pt[i] < 0) continue
            val ctr = badge(i)
            drawCircle(c.bgBottom.copy(alpha = 0.88f), cell * 0.17f, ctr)
            drawLinkGlyph(ctr, cell * 0.075f, colors[idx[i].coerceAtLeast(0) % colors.size])
        }
    }
}

/** Two interlocked rings: the twin-link symbol. [r] is the radius of one ring. */
internal fun DrawScope.drawLinkGlyph(ctr: Offset, r: Float, color: Color) {
    drawCircle(color, r, Offset(ctr.x - r * 0.7f, ctr.y), style = Stroke(r * 0.6f))
    drawCircle(color, r, Offset(ctr.x + r * 0.7f, ctr.y), style = Stroke(r * 0.6f))
}

/** A small padlock centred on [ctr], about [s] tall. */
internal fun DrawScope.drawPadlock(ctr: Offset, s: Float, body: Color, shackle: Color) {
    val bodyW = s * 0.82f
    val bodyH = s * 0.55f
    val bodyTop = ctr.y - s * 0.02f
    val leg = s * 0.24f
    val archY = ctr.y - s * 0.20f
    val arch = Path().apply {
        moveTo(ctr.x - leg, bodyTop)
        lineTo(ctr.x - leg, archY)
        arcTo(Rect(ctr.x - leg, archY - leg, ctr.x + leg, archY + leg), 180f, 180f, false)
        lineTo(ctr.x + leg, bodyTop)
    }
    drawPath(arch, shackle, style = Stroke(s * 0.11f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    drawRoundRect(body, Offset(ctr.x - bodyW / 2, bodyTop), Size(bodyW, bodyH), CornerRadius(s * 0.14f))
    drawCircle(Color.Black.copy(alpha = 0.45f), s * 0.07f, Offset(ctr.x, bodyTop + bodyH * 0.45f))
}

/** The first-time instruction for a new Classic rule: a small picture, the rule in one or two sentences, one button. */
@Composable
fun TwistTipDialog(twist: Twist, onDismiss: () -> Unit) {
    val c = LocalLoop.current
    Dialog(onDismissRequest = onDismiss) {
        LoopCard(Modifier.fillMaxWidth().popIn()) {
            Text(
                "NEW RULE", color = c.gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(6.dp))
            Text(
                twist.title, color = c.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(14.dp))
            TwistArt(twist, Modifier.align(Alignment.CenterHorizontally).size(190.dp, 96.dp))
            Spacer(Modifier.height(14.dp))
            Text(twist.tip, color = c.textDim, fontSize = 15.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(18.dp))
            PrimaryButton("Got it", onDismiss, Modifier.fillMaxWidth())
        }
    }
}

/** A tiny picture of each rule, drawn with the same marks as the board. */
@Composable
private fun TwistArt(twist: Twist, modifier: Modifier) {
    val c = LocalLoop.current
    Canvas(modifier) {
        val line = c.accent
        val stroke = size.height * 0.07f
        fun seg(a: Offset, b: Offset, col: Color = line) = drawLine(col, a, b, stroke, StrokeCap.Round)
        when (twist) {
            Twist.LOCKS -> {
                val cell = size.height * 0.62f
                val x0 = (size.width - cell * 3) / 2
                val y0 = (size.height - cell) / 2
                val cy = y0 + cell / 2
                seg(Offset(x0 + cell * 0.1f, cy), Offset(x0 + cell * 2.9f, cy))
                val plate = Offset(x0 + cell + cell * 0.07f, y0 + cell * 0.07f)
                drawRoundRect(c.gold.copy(alpha = 0.10f), plate, Size(cell * 0.86f, cell * 0.86f), CornerRadius(cell * 0.2f))
                drawRoundRect(c.gold.copy(alpha = 0.55f), plate, Size(cell * 0.86f, cell * 0.86f), CornerRadius(cell * 0.2f), style = Stroke(cell * 0.04f))
                seg(Offset(x0 + cell * 1.1f, cy), Offset(x0 + cell * 1.9f, cy))
                drawPadlock(Offset(x0 + cell * 1.5f, y0 - cell * 0.02f), cell * 0.55f, c.gold, lerp(c.gold, Color.White, 0.35f))
            }
            Twist.TWINS -> {
                val cell = size.height * 0.62f
                val gap = size.width * 0.34f
                val xa = size.width / 2 - gap / 2 - cell / 2
                val xb = size.width / 2 + gap / 2 - cell / 2
                val y0 = (size.height - cell) / 2
                val col = c.gold
                val dash = Stroke(stroke * 0.7f, cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(stroke * 1.2f, stroke * 1.8f)))
                drawLine(col.copy(alpha = 0.8f), Offset(xa + cell, y0 + cell / 2), Offset(xb, y0 + cell / 2), strokeWidth = dash.width, cap = StrokeCap.Round, pathEffect = dash.pathEffect)
                for (x in listOf(xa, xb)) {
                    drawRoundRect(col.copy(alpha = 0.10f), Offset(x, y0), Size(cell, cell), CornerRadius(cell * 0.2f))
                    drawRoundRect(col.copy(alpha = 0.75f), Offset(x, y0), Size(cell, cell), CornerRadius(cell * 0.2f), style = Stroke(cell * 0.05f))
                    seg(Offset(x + cell * 0.5f, y0 + cell * 0.2f), Offset(x + cell * 0.5f, y0 + cell * 0.8f))
                    drawLinkGlyph(Offset(x + cell * 0.80f, y0 + cell * 0.20f), cell * 0.075f, col)
                }
            }
            Twist.SHAPE -> {
                val cols = 4
                val rows = 3
                val cell = size.height / (rows + 0.4f)
                val x0 = (size.width - cell * cols) / 2
                val y0 = (size.height - cell * rows) / 2
                for (r in 0 until rows) for (k in 0 until cols) {
                    val wall = (r == 0 && k == cols - 1) || (r == rows - 1 && k == 0)
                    val tl = Offset(x0 + k * cell + cell * 0.07f, y0 + r * cell + cell * 0.07f)
                    val sd = Size(cell * 0.86f, cell * 0.86f)
                    if (wall) {
                        drawRoundRect(c.textDim.copy(alpha = 0.16f), tl, sd, CornerRadius(cell * 0.2f))
                        drawRoundRect(c.textDim.copy(alpha = 0.35f), tl, sd, CornerRadius(cell * 0.2f), style = Stroke(cell * 0.03f))
                    } else {
                        drawRoundRect(c.accent.copy(alpha = 0.18f), tl, sd, CornerRadius(cell * 0.2f))
                        drawCircle(c.accent, cell * 0.09f, Offset(x0 + k * cell + cell / 2, y0 + r * cell + cell / 2))
                    }
                }
            }
            Twist.WINDING -> {
                val w = size.width
                val h = size.height
                val path = Path().apply {
                    moveTo(w * 0.08f, h * 0.2f)
                    lineTo(w * 0.40f, h * 0.2f)
                    lineTo(w * 0.40f, h * 0.8f)
                    lineTo(w * 0.62f, h * 0.8f)
                    lineTo(w * 0.62f, h * 0.2f)
                    lineTo(w * 0.92f, h * 0.2f)
                }
                drawPath(path, line.copy(alpha = 0.28f), style = Stroke(stroke * 2.6f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawPath(path, line, style = Stroke(stroke, cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawCircle(c.gold, stroke * 1.3f, Offset(w * 0.08f, h * 0.2f))
                drawCircle(c.gold, stroke * 1.3f, Offset(w * 0.92f, h * 0.2f))
            }
        }
    }
}
