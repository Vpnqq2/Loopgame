package com.loopconnect.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.loopconnect.engine.LevelGenerator
import com.loopconnect.ui.*
import java.time.DayOfWeek
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun DailyScreen(vm: GameViewModel, onBack: () -> Unit, onPlay: () -> Unit) {
    val c = LocalLoop.current
    val progress by vm.progress.collectAsStateWithLifecycle()
    val today = remember { vm.today() }
    val spec = remember(today) { LevelGenerator.dailySpec(today) }
    var monthText by rememberSaveable { mutableStateOf(YearMonth.now().toString()) }
    val month = remember(monthText) { YearMonth.parse(monthText) }
    val doneToday = today in progress.dailyDays
    val streak = progress.streakOn(today)

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("DAILY PUZZLE", "New puzzle every day", onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            LoopCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { monthText = month.minusMonths(1).toString() }) {
                        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, "Previous month", tint = c.text)
                    }
                    Text(
                        "${month.month.getDisplayName(TextStyle.FULL, Locale.getDefault())} ${month.year}",
                        color = c.text, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { monthText = month.plusMonths(1).toString() }, enabled = month < YearMonth.now()) {
                        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, "Next month", tint = if (month < YearMonth.now()) c.text else c.border)
                    }
                }
                Row(Modifier.fillMaxWidth()) {
                    val order = listOf(DayOfWeek.SUNDAY, DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY)
                    order.forEach {
                        Text(it.getDisplayName(TextStyle.SHORT, Locale.getDefault()), color = c.textDim, fontSize = 11.sp,
                            textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                    }
                }
                Spacer(Modifier.height(6.dp))
                val lead = month.atDay(1).dayOfWeek.value % 7
                val cells = lead + month.lengthOfMonth()
                val rows = (cells + 6) / 7
                for (r in 0 until rows) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        for (col in 0 until 7) {
                            val day = r * 7 + col - lead + 1
                            Box(Modifier.weight(1f).aspectRatio(1f).padding(2.dp), contentAlignment = Alignment.Center) {
                                if (day in 1..month.lengthOfMonth()) {
                                    val epoch = month.atDay(day).toEpochDay()
                                    val done = epoch in progress.dailyDays
                                    val isToday = epoch == today
                                    val future = epoch > today
                                    Box(
                                        Modifier.fillMaxSize().clip(CircleShape)
                                            .background(if (done) c.accent else Color.Transparent)
                                            .border(if (isToday) 2.dp else 0.dp, if (isToday) c.gold else Color.Transparent, CircleShape)
                                            .semantics { contentDescription = "Day $day${if (done) ", completed" else ""}${if (isToday) ", today" else ""}" },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (done) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(16.dp))
                                        else Text("$day", color = if (future) c.border else c.text, fontSize = 13.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            LoopCard(Modifier.fillMaxWidth()) {
                Text("TODAY'S PUZZLE", color = c.gold, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(6.dp))
                Text("${spec.width} × ${spec.height}  ·  ${spec.objective.title}", color = c.text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(if (doneToday) "Completed today" else "Same puzzle for everyone today", color = if (doneToday) c.good else c.textDim, fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                PrimaryButton(if (doneToday) "REPLAY" else "PLAY", { vm.startDaily(); onPlay() }, Modifier.fillMaxWidth(), icon = Icons.Rounded.PlayArrow)
            }

            LoopCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.LocalFireDepartment, null, tint = c.gold, modifier = Modifier.size(36.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Current Streak", color = c.textDim, fontSize = 13.sp)
                        Text("$streak day${if (streak == 1) "" else "s"}", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Icon(Icons.Rounded.CardGiftcard, "Weekly reward", tint = if (streak > 0 && streak % 7 == 0) c.gold else c.border, modifier = Modifier.size(28.dp))
                }
                Spacer(Modifier.height(10.dp))
                val inWeek = if (streak == 0) 0 else (streak - 1) % 7 + 1
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.semantics { contentDescription = "$inWeek of 7 days toward weekly reward" }) {
                    repeat(7) { Box(Modifier.size(10.dp).clip(CircleShape).background(if (it < inWeek) c.gold else c.border)) }
                }
                Spacer(Modifier.height(4.dp))
                Text("Solve 7 days in a row for the weekly reward", color = c.textDim, fontSize = 12.sp)
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}
