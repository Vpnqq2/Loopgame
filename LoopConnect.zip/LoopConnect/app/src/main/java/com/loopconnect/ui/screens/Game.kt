package com.loopconnect.ui.screens

import android.os.Build
import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.drawscope.scale
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import com.loopconnect.ads.AdManager
import com.loopconnect.ads.findActivity
import com.loopconnect.data.AnimationMode
import com.loopconnect.engine.Dir
import com.loopconnect.engine.Rules
import com.loopconnect.engine.Tile
import com.loopconnect.engine.TileKind
import com.loopconnect.ui.*
import kotlinx.coroutines.launch
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun GameScreen(vm: GameViewModel, ads: AdManager, onBack: () -> Unit, onSettings: () -> Unit, onHome: () -> Unit) {
    val c = LocalLoop.current
    val ui by vm.ui.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    var paused by rememberSaveable { mutableStateOf(false) }
    var showAd by rememberSaveable { mutableStateOf(false) }
    val context = LocalContext.current
    val view = LocalView.current

    LaunchedEffect(Unit) { vm.ensureLoaded() }
    LaunchedEffect(ui.solved) {
        if (ui.solved && settings.haptics) {
            view.performHapticFeedback(
                if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.LONG_PRESS
            )
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            ScreenTopBar(
                title = when {
                    !ui.ready -> "LOOP CONNECT"
                    ui.isDaily -> "DAILY PUZZLE"
                    else -> "LEVEL ${ui.levelNumber}"
                },
                subtitle = if (ui.ready) ui.objective.title else null,
                onBack = onBack,
                trailing = {
                    GlassIconButton(Icons.Rounded.Pause, "Pause menu", { paused = true })
                }
            )
            when {
                ui.error != null -> Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                ) {
                    Text(ui.error ?: "", color = c.text, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(16.dp))
                    PrimaryButton("Try again", { vm.continueGame() })
                }
                !ui.ready -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = c.accent)
                }
                else -> {
                    InfoCard(ui, Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                    BoxWithConstraints(
                        Modifier.weight(1f).fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center
                    ) {
                        val tile = minOf(maxWidth / ui.width, maxHeight / ui.height, 96.dp)
                        Box(Modifier.size(tile * ui.width, tile * ui.height)) {
                            PuzzleBoardView(
                                ui, settings.animation.rotateMs, Modifier.fillMaxSize()
                            ) { i ->
                                if (vm.rotate(i) && settings.haptics) {
                                    view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                                }
                            }
                            val hint = ui.hint
                            if (hint != null) HintRing(ui.width, ui.height, hint.tile, Modifier.fillMaxSize())
                        }
                    }
                    val hint = ui.hint
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(
                            if (hint != null) "Tap the highlighted piece ${hint.taps} time${if (hint.taps == 1) "" else "s"}"
                            else ui.objective.hint,
                            color = if (hint != null) c.gold else c.textDim, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp).clip(RoundedCornerShape(50))
                                .background(c.surface.copy(alpha = 0.8f)).padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        CircleAction(Icons.AutoMirrored.Rounded.Undo, "Undo", { vm.undo() }, enabled = ui.canUndo && !ui.solved)
                        CircleAction(
                            Icons.Rounded.Lightbulb, "Hint",
                            { if (progress.hints > 0) vm.hint() else showAd = true },
                            enabled = !ui.solved, highlight = ui.hint != null,
                            badge = if (progress.hints > 0) "${progress.hints}" else "+"
                        )
                        CircleAction(Icons.Rounded.Refresh, "Restart", { vm.restart() }, enabled = !ui.solved)
                    }
                }
            }
        }

        if (ui.completed) {
            CompleteOverlay(ui, settings.animation != AnimationMode.OFF,
                onNext = { vm.nextLevel() }, onReplay = { vm.replay() }, onBack = onBack)
        }
        if (showAd) {
            OutOfHintsDialog(
                ads = ads,
                onWatch = {
                    val activity = context.findActivity()
                    if (activity != null) ads.show(activity, onRewarded = { vm.grantAdHint(); showAd = false }, onUnavailable = {})
                },
                onDismiss = { showAd = false }
            )
        }
        if (paused) {
            Dialog(onDismissRequest = { paused = false }) {
                LoopCard(Modifier.fillMaxWidth()) {
                    Text("PAUSED", color = c.text, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp,
                        modifier = Modifier.align(Alignment.CenterHorizontally))
                    Spacer(Modifier.height(16.dp))
                    PrimaryButton("Resume", { paused = false }, Modifier.fillMaxWidth(), icon = Icons.Rounded.PlayArrow)
                    Spacer(Modifier.height(10.dp))
                    OutlineButton("Restart Level", { vm.restart(); paused = false }, Modifier.fillMaxWidth(), icon = Icons.Rounded.Refresh)
                    Spacer(Modifier.height(10.dp))
                    OutlineButton("Settings", { paused = false; onSettings() }, Modifier.fillMaxWidth(), icon = Icons.Rounded.Settings)
                    Spacer(Modifier.height(10.dp))
                    OutlineButton("Main Menu", { paused = false; onHome() }, Modifier.fillMaxWidth(), icon = Icons.Rounded.Home)
                }
            }
        }
    }
}

@Composable
private fun InfoCard(ui: GameUiState, modifier: Modifier) {
    val c = LocalLoop.current
    val target = if (ui.occupied == 0) 0f else ui.satisfied.toFloat() / ui.occupied
    val fraction by animateFloatAsState(target, tween(450), label = "progress")
    val done = ui.occupied > 0 && ui.satisfied == ui.occupied
    LoopCard(modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.width(68.dp).semantics(mergeDescendants = true) {}) {
                Text("MOVES", color = c.textDim, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Text("${ui.moves}", color = c.text, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            }
            Box(Modifier.width(1.dp).height(44.dp).background(c.border))
            Column(Modifier.weight(1f).padding(horizontal = 14.dp).semantics(mergeDescendants = true) {
                contentDescription = "Progress ${ui.satisfied} of ${ui.occupied} pieces connected"
            }) {
                Row {
                    Text("PROGRESS", color = c.textDim, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, modifier = Modifier.weight(1f))
                    Text("${ui.satisfied}/${ui.occupied}", color = if (done) c.good else c.text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp)).background(c.bgBottom)) {
                    Box(
                        Modifier.fillMaxWidth(fraction).fillMaxHeight().clip(RoundedCornerShape(6.dp))
                            .background(Brush.horizontalGradient(listOf(c.accent, if (done) c.good else c.accent2)))
                    )
                }
            }
            Box(Modifier.width(1.dp).height(44.dp).background(c.border))
            Column(Modifier.padding(start = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.Star, null, tint = c.gold, modifier = Modifier.size(24.dp))
                Text("PAR ${ui.par}", color = c.textDim, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }
    }
}

private fun easeOutBack(x: Float): Float {
    val c1 = 1.70158f
    val c3 = c1 + 1f
    val t = x - 1f
    return 1f + c3 * t * t * t + c1 * t * t
}

/** Component id (lowest tile index) of every tile, connected through matched sides. -1 for empty tiles. */
internal fun components(masks: IntArray, w: Int, h: Int): IntArray {
    val comp = IntArray(masks.size) { -1 }
    for (s in masks.indices) {
        if (masks[s] == 0 || comp[s] >= 0) continue
        comp[s] = s
        val st = ArrayDeque<Int>()
        st.addLast(s)
        while (st.isNotEmpty()) {
            val cur = st.removeLast()
            for (d in Dir.ALL) {
                if (!Rules.isMatched(masks, w, h, cur, d)) continue
                val n = Rules.neighbor(cur, d, w, h)
                if (comp[n] < 0) { comp[n] = s; st.addLast(n) }
            }
        }
    }
    return comp
}

/** The puzzle board: custom Canvas drawing with spring rotation, intro pop-in and a completion wave. */
@Composable
fun PuzzleBoardView(ui: GameUiState, animMs: Int, modifier: Modifier, onTap: (Int) -> Unit) {
    val c = LocalLoop.current
    val n = ui.width * ui.height
    val offsets = remember(ui.key, n) { List(n) { Animatable(0f) } }
    val prev = remember(ui.key, n) { arrayOf(ui.masks) }
    val tap by rememberUpdatedState(onTap)
    val comps = remember(ui.masks) { components(ui.masks, ui.width, ui.height) }
    val intro = remember(ui.key, n) { Animatable(if (animMs > 0) 0f else 1f) }
    val win = remember(ui.key, n) { Animatable(0f) }
    val palette = listOf(c.accent, c.gold, c.accent2, Color(0xFFFF6FA8), Color(0xFF35E0FF))

    LaunchedEffect(ui.key, n) {
        if (animMs > 0) intro.animateTo(1f, tween(800, easing = LinearEasing)) else intro.snapTo(1f)
    }
    LaunchedEffect(ui.solved, ui.key) {
        if (ui.solved) {
            if (animMs > 0) { win.snapTo(0f); win.animateTo(1f, tween(1100, easing = LinearEasing)) } else win.snapTo(1f)
        } else win.snapTo(0f)
    }
    LaunchedEffect(ui.masks) {
        val old = prev[0]
        if (old !== ui.masks && old.size == ui.masks.size) {
            for (i in 0 until n) {
                if (old[i] == ui.masks[i]) continue
                val delta = when {
                    Tile.rotateCw(old[i]) == ui.masks[i] -> -90f
                    Tile.rotateCcw(old[i]) == ui.masks[i] -> 90f
                    else -> 0f
                }
                launch {
                    if (animMs > 0 && delta != 0f) {
                        // Continue from the current visual angle so rapid taps never jump or end tilted.
                        offsets[i].snapTo(offsets[i].value + delta)
                        offsets[i].animateTo(0f, tween(animMs, easing = FastOutSlowInEasing))
                    } else offsets[i].snapTo(0f)
                }
            }
        }
        prev[0] = ui.masks
    }

    Canvas(
        modifier
            .pointerInput(ui.width, ui.height, ui.solved) {
                detectTapGestures { p ->
                    val col = (p.x / (size.width / ui.width.toFloat())).toInt()
                    val row = (p.y / (size.height / ui.height.toFloat())).toInt()
                    if (col in 0 until ui.width && row in 0 until ui.height) tap(row * ui.width + col)
                }
            }
            .semantics {
                contentDescription = "Puzzle board, ${ui.width} by ${ui.height}. ${ui.satisfied} of ${ui.occupied} pieces connected. Tap a piece to rotate it."
            }
    ) {
        val cell = size.width / ui.width
        val denom = (ui.width + ui.height - 2).coerceAtLeast(1).toFloat()
        val iv = intro.value
        val wv = win.value
        // Three passes (glow, core, highlight) over the whole board: a neighbour's glow can
        // never paint over this tile's line, so paths join cleanly across invisible cell borders.
        for (pass in 0..2) {
            for (i in 0 until n) {
                if (ui.masks[i] == 0) continue
                val dist = ((i % ui.width) + (i / ui.width)) / denom
                val pop = (iv * 1.7f - dist * 0.7f).coerceIn(0f, 1f)
                val wave = if (ui.solved) (wv * 1.7f - dist * 0.7f).coerceIn(0f, 1f) else 0f
                drawPiece(pass, ui, comps, palette, i, cell, offsets[i].value, pop, wave, c)
            }
        }
    }
}

/**
 * Draws only the line art of one piece. Cells have no visible background or border; the grid
 * exists purely as invisible geometry for placement and touch. Geometry is never scaled, so
 * every line meets its neighbour exactly at the cell edge.
 */
internal fun DrawScope.drawPiece(
    pass: Int, ui: GameUiState, comps: IntArray, palette: List<Color>, i: Int, cell: Float,
    angle: Float, pop: Float, wave: Float, c: LoopColors
) {
    val m = ui.masks[i]
    if (m == 0 || pop <= 0f) return
    val w = ui.width
    val h = ui.height
    val cx = (i % w) * cell + cell / 2
    val cy = (i / w) * cell + cell / 2
    val pulse = kotlin.math.sin(PI.toFloat() * wave)
    val glowMul = 1f + pulse
    val stroke = cell * 0.12f
    val base = palette[comps[i].coerceAtLeast(0) % palette.size]
    val tint = lerp(lerp(base, c.good, wave), Color.White, pulse * 0.45f)
    val bad = c.bad.copy(alpha = 0.9f)
    val allOk = Dir.ALL.all { !Tile.has(m, it) || Rules.isMatched(ui.masks, w, h, i, it) }
    fun Color.fade(f: Float) = copy(alpha = (alpha * f * pop).coerceIn(0f, 1f))
    fun mid(d: Int, f: Float = 1f) = Offset(cx + Dir.dx(d) * cell / 2 * f, cy + Dir.dy(d) * cell / 2 * f)

    rotate(angle, Offset(cx, cy)) {
        val kind = Tile.kind(m)
        if (kind == TileKind.CORNER) {
            val sides = Dir.ALL.filter { Tile.has(m, it) }
            val ok = sides.all { Rules.isMatched(ui.masks, w, h, i, it) }
            val path = Path().apply {
                moveTo(mid(sides[0]).x, mid(sides[0]).y)
                quadraticBezierTo(cx, cy, mid(sides[1]).x, mid(sides[1]).y)
            }
            val col = if (ok) tint else bad
            when (pass) {
                0 -> if (ok) {
                    drawPath(path, col.fade(0.10f * glowMul), style = Stroke(stroke * 3.2f, cap = StrokeCap.Round))
                    drawPath(path, col.fade(0.20f * glowMul), style = Stroke(stroke * 2f, cap = StrokeCap.Round))
                }
                1 -> drawPath(path, col.fade(1f), style = Stroke(stroke, cap = StrokeCap.Round))
                else -> if (ok) drawPath(path, Color.White.fade(0.28f), style = Stroke(stroke * 0.32f, cap = StrokeCap.Round))
            }
        } else {
            for (d in Dir.ALL) {
                if (!Tile.has(m, d)) continue
                val ok = Rules.isMatched(ui.masks, w, h, i, d)
                val end = mid(d, if (ok) 1f else 0.8f)
                val col = if (ok) tint else bad
                when (pass) {
                    0 -> if (ok) {
                        drawLine(col.fade(0.10f * glowMul), Offset(cx, cy), end, stroke * 3.2f, StrokeCap.Round)
                        drawLine(col.fade(0.20f * glowMul), Offset(cx, cy), end, stroke * 2f, StrokeCap.Round)
                    }
                    1 -> drawLine(col.fade(1f), Offset(cx, cy), end, stroke, StrokeCap.Round)
                    else -> if (ok) drawLine(Color.White.fade(0.28f), Offset(cx, cy), end, stroke * 0.32f, StrokeCap.Round)
                }
            }
            val col = if (allOk) tint else bad
            when (kind) {
                TileKind.END -> when (pass) {
                    0 -> drawCircle(col.fade(0.25f), stroke * 1.9f, Offset(cx, cy))
                    1 -> drawCircle(col.fade(1f), stroke * 1.2f, Offset(cx, cy))
                    else -> drawCircle(Color.White.fade(0.35f), stroke * 0.45f, Offset(cx - stroke * 0.25f, cy - stroke * 0.25f))
                }
                TileKind.TEE, TileKind.CROSS -> when (pass) {
                    1 -> drawCircle(col.fade(1f), stroke * 0.9f, Offset(cx, cy))
                    2 -> drawCircle(Color.White.fade(0.35f), stroke * 0.35f, Offset(cx, cy))
                    else -> Unit
                }
                else -> Unit
            }
        }
    }
}

@Composable
private fun HintRing(w: Int, h: Int, tile: Int, modifier: Modifier) {
    val c = LocalLoop.current
    val t = rememberInfiniteTransition(label = "hint")
    val alpha by t.animateFloat(0.35f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "alpha")
    Canvas(modifier) {
        val cell = size.width / w
        val x = (tile % w) * cell
        val y = (tile / w) * cell
        drawRoundRect(
            c.gold.copy(alpha = alpha), Offset(x + cell * 0.03f, y + cell * 0.03f),
            Size(cell * 0.94f, cell * 0.94f), CornerRadius(cell * 0.22f), style = Stroke(cell * 0.05f)
        )
    }
}

@Composable
private fun CompleteOverlay(ui: GameUiState, animated: Boolean, onNext: () -> Unit, onReplay: () -> Unit, onBack: () -> Unit) {
    val c = LocalLoop.current
    val appear = remember { Animatable(if (animated) 0f else 1f) }
    val starScales = remember { List(3) { Animatable(if (animated) 0f else 1f) } }
    LaunchedEffect(Unit) {
        if (animated) {
            launch { appear.animateTo(1f, tween(450, easing = FastOutSlowInEasing)) }
            for (i in 0 until ui.stars) {
                delay(280L)
                launch { starScales[i].animateTo(1f, spring(dampingRatio = 0.38f, stiffness = 260f)) }
            }
        }
    }
    Box(
        Modifier.fillMaxSize().drawBehind { drawRect(Color.Black.copy(alpha = 0.72f * appear.value)) }
            .clickable(enabled = false) {},
        contentAlignment = Alignment.Center
    ) {
        if (animated) Confetti(Modifier.fillMaxSize())
        Column(
            Modifier.padding(28.dp).fillMaxWidth().graphicsLayer {
                alpha = appear.value
                translationY = (1f - appear.value) * 48f
            },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.semantics { contentDescription = "${ui.stars} of 3 stars" }
            ) {
                for (i in 0 until 3) {
                    val earned = i < ui.stars
                    Icon(
                        Icons.Rounded.Star, null, tint = if (earned) c.gold else c.border,
                        modifier = Modifier.size(56.dp).graphicsLayer {
                            if (earned) {
                                val sc = starScales[i].value
                                scaleX = sc; scaleY = sc
                                rotationZ = (1f - sc) * -50f
                            }
                        }
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            Text(if (ui.isDaily) "Daily Complete!" else "Level Complete!", color = c.text, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text(if (ui.newBest) "New best!" else "Great job!", color = c.textDim, fontSize = 16.sp)
            Spacer(Modifier.height(20.dp))
            LoopCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Stat("Moves", "${ui.moves}")
                    Stat(if (ui.isDaily) "Streak" else "Best", if (ui.isDaily) "${ui.streak} d" else "${ui.bestMoves ?: ui.moves}")
                    Stat("Par", "${ui.par}")
                }
            }
            Spacer(Modifier.height(22.dp))
            if (ui.isDaily) PrimaryButton("Back to Daily", onBack, Modifier.fillMaxWidth())
            else PrimaryButton("Next Level", onNext, Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlineButton("Replay", onReplay, Modifier.fillMaxWidth(), icon = Icons.Rounded.Refresh)
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    val c = LocalLoop.current
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = c.textDim, fontSize = 12.sp)
        Text(value, color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    }
}

private class Particle(val x: Float, val phase: Float, val speed: Float, val color: Int, val rot: Float)

@Composable
internal fun Confetti(modifier: Modifier) {
    val c = LocalLoop.current
    val t by rememberInfiniteTransition(label = "confetti").animateFloat(0f, 1f, infiniteRepeatable(tween(4200, easing = LinearEasing)), label = "t")
    val parts = remember { val r = Random(7); List(46) { Particle(r.nextFloat(), r.nextFloat(), 0.6f + r.nextFloat() * 0.6f, r.nextInt(5), r.nextFloat() * 360f) } }
    val colors = listOf(c.gold, c.accent, c.accent2, c.good, c.bad)
    Canvas(modifier) {
        for (p in parts) {
            val prog = (t * p.speed + p.phase) % 1f
            val px = p.x * size.width + sin(prog * 12.5f + p.phase * 6f) * 14f
            val py = prog * size.height
            rotate(p.rot + prog * 360f, Offset(px, py)) {
                drawRect(colors[p.color], Offset(px, py), Size(8f, 14f))
            }
        }
    }
}

@Composable
private fun OutOfHintsDialog(ads: AdManager, onWatch: () -> Unit, onDismiss: () -> Unit) {
    val c = LocalLoop.current
    val ready by ads.ready.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { ads.load() }
    Dialog(onDismissRequest = onDismiss) {
        LoopCard(Modifier.fillMaxWidth()) {
            Text("Out of hints", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            Text(
                "Earn hints by completing levels (one per 3 levels, one for a 3-star result, two for a 7-day daily streak), " +
                    "or watch a short ad for +1 hint. Using a hint caps that level at 2 stars.",
                color = c.textDim, fontSize = 14.sp, lineHeight = 20.sp
            )
            if (!ready) {
                Spacer(Modifier.height(8.dp))
                Text("No ad is ready yet. You need an internet connection; it will load automatically.", color = c.bad, fontSize = 12.sp)
            }
            Spacer(Modifier.height(18.dp))
            PrimaryButton(if (ready) "Watch ad  ·  +1 hint" else "Loading ad…", onWatch, Modifier.fillMaxWidth(), enabled = ready)
            Spacer(Modifier.height(10.dp))
            OutlineButton("Not now", onDismiss, Modifier.fillMaxWidth())
        }
    }
}
