package com.loopconnect.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.loopconnect.ui.*

@Composable
fun HomeScreen(
    vm: GameViewModel,
    onPlay: () -> Unit, onContinue: () -> Unit, onDaily: () -> Unit,
    onLevels: () -> Unit, onStats: () -> Unit, onSettings: () -> Unit
) {
    val c = LocalLoop.current
    val hasSave by vm.hasSave.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().padding(horizontal = 28.dp)) {
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            Spacer(Modifier.height(16.dp))
            LogoMark(120.dp)
            Spacer(Modifier.height(18.dp))
            Text("Loop Connect", color = c.text, fontSize = 36.sp, fontWeight = FontWeight.Bold)
            Text("Rotate  ·  Connect  ·  Solve", color = c.textDim, fontSize = 15.sp)
            Spacer(Modifier.height(32.dp))
            PrimaryButton(
                if (progress.levelsCompleted == 0) "Play" else "Play  ·  Level ${progress.highestUnlocked}",
                onPlay, Modifier.fillMaxWidth(), icon = Icons.Rounded.PlayArrow
            )
            Spacer(Modifier.height(12.dp))
            OutlineButton("Continue", onContinue, Modifier.fillMaxWidth(), icon = Icons.Rounded.Replay, enabled = hasSave)
            Spacer(Modifier.height(12.dp))
            OutlineButton("Daily Puzzle", onDaily, Modifier.fillMaxWidth(), icon = Icons.Rounded.CalendarMonth)
            Spacer(Modifier.height(12.dp))
            OutlineButton("Level Selection", onLevels, Modifier.fillMaxWidth(), icon = Icons.Rounded.GridView)
            Spacer(Modifier.height(16.dp))
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            BottomItem(Icons.Rounded.BarChart, "Statistics", onStats)
            BottomItem(Icons.Rounded.EmojiEvents, "Achievements", onStats)
            BottomItem(Icons.Rounded.Settings, "Settings", onSettings)
        }
    }
}

@Composable
private fun BottomItem(icon: ImageVector, label: String, onClick: () -> Unit) {
    val c = LocalLoop.current
    Column(
        Modifier.widthIn(min = 88.dp).clickable(role = Role.Button, onClickLabel = label, onClick = onClick).padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = c.text, modifier = Modifier.size(24.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = c.textDim, fontSize = 12.sp)
    }
}
