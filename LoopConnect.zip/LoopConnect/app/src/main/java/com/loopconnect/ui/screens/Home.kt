package com.loopconnect.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.loopconnect.ui.*

@Composable
fun HomeScreen(
    vm: GameViewModel,
    onPlay: () -> Unit, onContinue: () -> Unit, onDaily: () -> Unit,
    onModes: () -> Unit, onStats: () -> Unit, onSettings: () -> Unit, onHowTo: () -> Unit, onAwards: () -> Unit
) {
    val c = LocalLoop.current
    val hasSave by vm.hasSave.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val today = remember { vm.today() }
    val stars = progress.results.values.sumOf { it.stars }
    val streak = progress.streakOn(today)
    val dailyDone = today in progress.dailyDays

    // One gentle, contextual notification prompt after a few completed levels.
    val ctx = LocalContext.current
    var askPush by rememberSaveable { mutableStateOf(false) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> vm.setNotifications(granted) }
    LaunchedEffect(progress.levelsCompleted) { if (vm.shouldAskNotifications()) askPush = true }
    if (askPush) {
        Dialog(onDismissRequest = { askPush = false; vm.markNotifPrompted() }) {
            LoopCard(Modifier.fillMaxWidth()) {
                Text("Daily puzzle reminders?", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(8.dp))
                Text("Get a gentle nudge when the daily puzzle is ready. You can turn this off any time in Settings.", color = c.textDim, fontSize = 14.sp, lineHeight = 20.sp)
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlineButton("Not now", { askPush = false; vm.markNotifPrompted() }, Modifier.weight(1f))
                    PrimaryButton("Enable", {
                        askPush = false
                        vm.markNotifPrompted()
                        val needsAsk = Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        if (needsAsk) permission.launch(Manifest.permission.POST_NOTIFICATIONS) else vm.setNotifications(true)
                    }, Modifier.weight(1f))
                }
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudChip(Icons.Rounded.Flag, "Lv ${progress.highestUnlocked}", c.accent)
            HudChip(Icons.Rounded.Star, "$stars", c.gold)
            HudChip(Icons.Rounded.Lightbulb, "${progress.hints}", c.accent2)
            Spacer(Modifier.weight(1f))
            HudChip(Icons.Rounded.LocalFireDepartment, "$streak", Color(0xFFFF8A4D))
        }
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            LogoMark(116.dp)
            Text(
                "LOOP CONNECT",
                style = TextStyle(
                    brush = Brush.horizontalGradient(listOf(c.accent, c.text, c.accent2)),
                    fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp
                )
            )
            Spacer(Modifier.height(4.dp))
            Text("Rotate  ·  Connect  ·  Solve", color = c.textDim, fontSize = 14.sp, letterSpacing = 1.sp)
        }
        PrimaryButton(
            if (progress.levelsCompleted == 0) "PLAY" else "PLAY  ·  LEVEL ${progress.highestUnlocked}",
            onPlay, Modifier.fillMaxWidth(), icon = Icons.Rounded.PlayArrow, big = true
        )
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MenuTile("Daily Puzzle", Icons.Rounded.CalendarMonth, c.gold, !dailyDone, onDaily, Modifier.weight(1f))
            MenuTile("Game modes", Icons.Rounded.GridView, c.accent2, false, onModes, Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        OutlineButton("Continue", onContinue, Modifier.fillMaxWidth(), icon = Icons.Rounded.Replay, enabled = hasSave)
        Spacer(Modifier.height(10.dp))
        val dock = RoundedCornerShape(28.dp)
        Row(
            Modifier.fillMaxWidth().padding(bottom = 12.dp).clip(dock).background(c.surface.copy(alpha = 0.88f))
                .border(1.dp, c.border, dock).padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            DockItem(Icons.Rounded.BarChart, "Stats", onStats, Modifier.weight(1f))
            DockItem(Icons.Rounded.EmojiEvents, "Awards", onAwards, Modifier.weight(1f))
            DockItem(Icons.Rounded.School, "How to play", onHowTo, Modifier.weight(1f))
            DockItem(Icons.Rounded.Settings, "Settings", onSettings, Modifier.weight(1f))
        }
    }
}

@Composable
private fun MenuTile(title: String, icon: ImageVector, tint: Color, badge: Boolean, onClick: () -> Unit, modifier: Modifier) {
    val c = LocalLoop.current
    LoopCard(modifier.gamePress(label = title, onClick = onClick)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.35f), tint.copy(alpha = 0.12f))))
                    .border(1.dp, tint.copy(alpha = 0.6f), CircleShape),
                contentAlignment = Alignment.Center
            ) { Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp)) }
            Spacer(Modifier.weight(1f))
            if (badge) {
                Text(
                    "NEW", color = Color(0xFF1B1300), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(c.gold).padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(title, color = c.text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
private fun DockItem(icon: ImageVector, label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = LocalLoop.current
    Column(
        modifier.gamePress(label = label, onClick = onClick).padding(vertical = 8.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = c.text, modifier = Modifier.size(24.dp))
        Spacer(Modifier.height(2.dp))
        Text(label, color = c.textDim, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}
