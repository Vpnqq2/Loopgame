package com.loopconnect.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.loopconnect.engine.Dir
import com.loopconnect.engine.Tile
import com.loopconnect.ui.*
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.sin

/** A looping mini-puzzle: pieces start scrambled, get tapped into place one by one, then the board lights up. */
private class DemoSpec(val w: Int, val h: Int, val solved: IntArray, val scramble: IntArray, val widthFraction: Float)

private const val N = Dir.N
private const val E = Dir.E
private const val S = Dir.S
private const val W = Dir.W

private val demoTap = DemoSpec(1, 1, intArrayOf(N or E), intArrayOf(3), 0.5f)
private val demoConnect = DemoSpec(3, 1, intArrayOf(E, E or W, W), intArrayOf(1, 1, 3), 0.85f)
private val demoNetwork = DemoSpec(
    3, 3,
    intArrayOf(E or S, E or W or S, W or S, N or S, N or S, N or S, N or E, N or E or W, N or W),
    intArrayOf(1, 2, 3, 1, 1, 1, 3, 2, 1), 0.7f
)
private val demoLoop = DemoSpec(2, 2, intArrayOf(E or S, W or S, N or E, N or W), intArrayOf(1, 3, 2, 1), 0.5f)

private fun smooth(p: Float) = p * p * (3f - 2f * p)

@Composable
private fun DemoBoard(spec: DemoSpec, modifier: Modifier) {
    val c = LocalLoop.current
    val animate = LocalAnimations.current
    val tState: State<Float> = if (animate) {
        rememberInfiniteTransition(label = "demo").animateFloat(0f, 1f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "t")
    } else remember { mutableStateOf(0.93f) }
    val palette = listOf(c.accent, c.gold, c.accent2, Color(0xFFFF6FA8), Color(0xFF35E0FF))
    val n = spec.w * spec.h

    Canvas(modifier.aspectRatio(spec.w.toFloat() / spec.h)) {
        val t = tState.value
        val cell = size.width / spec.w
        val masks = IntArray(n)
        val angles = FloatArray(n)
        for (i in 0 until n) {
            val k = spec.scramble[i]
            var rem = k * 90f
            val s0 = 0.12f + 0.28f * (i / n.toFloat())
            for (j in 0 until k) rem -= 90f * smooth(((t - (s0 + j * 0.1f)) / 0.07f).coerceIn(0f, 1f))
            rem = max(rem, 0f)
            val q = ceil(rem / 90f - 0.001f).toInt().coerceIn(0, 3)
            masks[i] = Tile.rotateCw(spec.solved[i], (4 - q) % 4) // logical orientation
            angles[i] = q * 90f - rem                             // remaining visual turn
        }
        val ui = GameUiState(width = spec.w, height = spec.h, masks = masks)
        val comps = components(masks, spec.w, spec.h)
        val pop = if (animate) (t / 0.05f).coerceIn(0f, 1f) * (1f - ((t - 0.95f) / 0.05f).coerceIn(0f, 1f)) else 1f
        val denom = (spec.w + spec.h - 2).coerceAtLeast(1).toFloat()
        for (pass in 0..2) {
            for (i in 0 until n) {
                if (masks[i] == 0) continue
                val dist = ((i % spec.w) + (i / spec.w)) / denom
                val wave = if (!animate) 1f else if (t > 0.78f) ((t - 0.78f) / 0.2f * 1.7f - dist * 0.7f).coerceIn(0f, 1f) else 0f
                drawPiece(pass, ui, comps, palette, i, cell, angles[i], pop, wave, c)
            }
        }
        if (animate) {
            // tap ripples at the moment each piece is turned
            for (i in 0 until n) {
                val s0 = 0.12f + 0.28f * (i / n.toFloat())
                val center = Offset((i % spec.w) * cell + cell / 2, (i / spec.w) * cell + cell / 2)
                for (j in 0 until spec.scramble[i]) {
                    val p = (t - (s0 + j * 0.1f)) / 0.12f
                    if (p in 0f..1f) {
                        drawCircle(Color.White.copy(alpha = 0.55f * (1f - p)), cell * (0.1f + 0.3f * p), center, style = Stroke(cell * 0.03f))
                        drawCircle(c.gold.copy(alpha = 0.35f * (1f - p)), cell * 0.12f, center)
                    }
                }
            }
        }
    }
}

@Composable
private fun StarsHintDemo() {
    val c = LocalLoop.current
    val animate = LocalAnimations.current
    val tState: State<Float> = if (animate) {
        rememberInfiniteTransition(label = "stars").animateFloat(0f, 1f, infiniteRepeatable(tween(3600, easing = LinearEasing)), label = "t")
    } else remember { mutableStateOf(0.9f) }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            for (i in 0 until 3) {
                Icon(
                    Icons.Rounded.Star, null, tint = c.gold,
                    modifier = Modifier.size(56.dp).graphicsLayer {
                        val p = (tState.value * 1.5f - i * 0.2f).coerceIn(0f, 1f)
                        val back = 1f + 2.70158f * (p - 1f) * (p - 1f) * (p - 1f) + 1.70158f * (p - 1f) * (p - 1f)
                        scaleX = back; scaleY = back
                        rotationZ = (1f - p) * -40f
                        alpha = if (tState.value > 0.93f) (1f - tState.value) / 0.07f else 1f
                    }
                )
            }
        }
        Spacer(Modifier.height(22.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(64.dp).clip(CircleShape).background(c.gold.copy(alpha = 0.18f)).graphicsLayer {
                    val s = 1f + 0.1f * sin(tState.value * 2f * PI.toFloat() * 2f)
                    scaleX = s; scaleY = s
                },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.Lightbulb, null, tint = c.gold, modifier = Modifier.size(36.dp)) }
            Spacer(Modifier.width(12.dp))
            Text("+1", color = c.gold, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

private class HowPage(val title: String, val body: String, val tip: String, val demo: @Composable () -> Unit)

private fun pages(): List<HowPage> = listOf(
    HowPage(
        "Tap to rotate",
        "Every piece turns 90° clockwise each time you tap it. Tap as many times as you need to point its lines the right way.",
        "Tap a piece, watch it turn"
    ) { DemoBoard(demoTap, Modifier.fillMaxWidth(demoTap.widthFraction)) },
    HowPage(
        "Match the ends",
        "A line must meet a line on the neighbouring piece. Red ends are loose. Glowing lines are connected on both sides.",
        "Red means loose, glow means joined"
    ) { DemoBoard(demoConnect, Modifier.fillMaxWidth(demoConnect.widthFraction)) },
    HowPage(
        "Build one network",
        "Connect every piece into a single network. When no loose end is left anywhere, the level is solved.",
        "Different colours are separate groups"
    ) { DemoBoard(demoNetwork, Modifier.fillMaxWidth(demoNetwork.widthFraction)) },
    HowPage(
        "Close the loops",
        "On \"Close every loop\" levels nothing may dangle. Every piece has to sit on a closed loop.",
        "Look for the levels with this goal"
    ) { DemoBoard(demoLoop, Modifier.fillMaxWidth(demoLoop.widthFraction)) },
    HowPage(
        "Stars and hints",
        "Finish in fewer moves to earn up to 3 stars. A hint points to the next piece to turn, but caps that level at 2 stars. Earn hints by playing, or watch a short ad.",
        "Stuck? Tap the lightbulb"
    ) { StarsHintDemo() }
)

@Composable
fun HowToScreen(firstRun: Boolean, onDone: () -> Unit) {
    val c = LocalLoop.current
    val list = remember { pages() }
    val pager = rememberPagerState(pageCount = { list.size })
    val scope = rememberCoroutineScope()
    val last = pager.currentPage == list.size - 1
    BackHandler(enabled = firstRun) { onDone() }

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar(
            "HOW TO PLAY", null,
            onBack = if (firstRun) null else onDone,
            trailing = {
                if (!last) Box(Modifier.gamePress(label = "Skip tutorial", onClick = onDone).padding(horizontal = 14.dp, vertical = 12.dp)) {
                    Text("Skip", color = c.textDim, fontWeight = FontWeight.SemiBold)
                }
            }
        )
        HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { index ->
            val page = list[index]
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                LoopCard(Modifier.fillMaxWidth()) {
                    Box(Modifier.fillMaxWidth().height(240.dp), contentAlignment = Alignment.Center) { page.demo() }
                }
                Spacer(Modifier.height(24.dp))
                Text("${index + 1}", color = c.accent, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                Text(page.title, color = c.text, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(10.dp))
                Text(page.body, color = c.textDim, fontSize = 15.sp, lineHeight = 22.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(14.dp))
                Text(
                    page.tip, color = c.gold, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(c.gold.copy(alpha = 0.14f)).padding(horizontal = 14.dp, vertical = 6.dp)
                )
                Spacer(Modifier.height(12.dp))
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(vertical = 10.dp).semantics { contentDescription = "Page ${pager.currentPage + 1} of ${list.size}" },
            horizontalArrangement = Arrangement.Center
        ) {
            list.indices.forEach { i ->
                val width by animateDpAsState(if (i == pager.currentPage) 26.dp else 8.dp, label = "dot")
                Box(
                    Modifier.padding(horizontal = 4.dp).height(8.dp).width(width).clip(CircleShape)
                        .background(if (i == pager.currentPage) c.accent else c.border)
                )
            }
        }
        PrimaryButton(
            if (last) "LET'S PLAY" else "NEXT",
            { if (last) onDone() else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } },
            Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 16.dp), big = true
        )
    }
}
