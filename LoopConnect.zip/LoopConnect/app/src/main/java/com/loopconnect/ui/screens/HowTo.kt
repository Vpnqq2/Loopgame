package com.loopconnect.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.loopconnect.engine.Dir
import com.loopconnect.engine.Objective
import com.loopconnect.engine.Rules
import com.loopconnect.engine.Spark
import com.loopconnect.engine.Tile
import com.loopconnect.ui.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/**
 * A tiny playable puzzle for the tutorial. Pieces start scrambled and the player taps them into place with the
 * real rules and the real piece drawing; solving it lights the board up. [spark] adds a power source so that
 * only lit pieces can turn, exactly like Spark mode.
 */
private class PlaySpec(
    val w: Int, val h: Int, val solved: IntArray, val scramble: IntArray, val widthFraction: Float,
    val objective: Objective = Objective.NETWORK, val spark: Boolean = false
) {
    val start: IntArray get() = IntArray(w * h) { Tile.rotateCw(solved[it], scramble[it]) }
    val source: Int get() = if (spark) Spark.sourceOf(solved, w, h) else -1
}

private const val N = Dir.N
private const val E = Dir.E
private const val S = Dir.S
private const val W = Dir.W

private val playTap = PlaySpec(2, 1, intArrayOf(E, W), intArrayOf(3, 3), 0.6f)
private val playConnect = PlaySpec(3, 1, intArrayOf(E, E or W, W), intArrayOf(1, 1, 3), 0.85f)
private val playNetwork = PlaySpec(
    3, 3,
    intArrayOf(E or S, E or W or S, W or S, N or S, N or S, N or S, N or E, N or E or W, N or W),
    intArrayOf(1, 2, 3, 1, 1, 1, 3, 2, 1), 0.7f
)
private val playLoop = PlaySpec(2, 2, intArrayOf(E or S, W or S, N or E, N or W), intArrayOf(1, 3, 2, 1), 0.5f, Objective.LOOPS)
private val playSpark = PlaySpec(
    3, 2,
    intArrayOf(E or S, E or W, W or S, N, 0, N),
    intArrayOf(3, 1, 1, 0, 0, 0), 0.8f, spark = true
)

/** Marks every piece connected to the source through matched sides as powered. */
private fun wakeFrom(masks: IntArray, w: Int, h: Int, src: Int, awake: BooleanArray) {
    val seen = BooleanArray(masks.size)
    val stack = ArrayDeque<Int>()
    seen[src] = true
    stack.addLast(src)
    while (stack.isNotEmpty()) {
        val cur = stack.removeLast()
        awake[cur] = true
        for (d in Dir.ALL) {
            if (!Rules.isMatched(masks, w, h, cur, d)) continue
            val nb = Rules.neighbor(cur, d, w, h)
            if (!seen[nb]) { seen[nb] = true; stack.addLast(nb) }
        }
    }
}

@Composable
private fun PlayBoard(spec: PlaySpec, resetKey: Int, onSolved: () -> Unit, modifier: Modifier) {
    val c = LocalLoop.current
    val animate = LocalAnimations.current
    val n = spec.w * spec.h
    val src = spec.source
    val scope = rememberCoroutineScope()

    var masks by remember(spec, resetKey) { mutableStateOf(spec.start) }
    var touched by remember(spec, resetKey) { mutableStateOf(false) }
    var solved by remember(spec, resetKey) { mutableStateOf(false) }
    val awake = remember(spec, resetKey) { BooleanArray(n).also { if (src >= 0) wakeFrom(spec.start, spec.w, spec.h, src, it) } }
    val offsets = remember(spec, resetKey) { List(n) { Animatable(0f) } }
    val lit = remember(spec, resetKey) { List(n) { Animatable(if (src >= 0 && !awake[it]) 0f else 1f) } }
    val win = remember(spec, resetKey) { Animatable(0f) }
    val pop = remember(spec, resetKey) { Animatable(if (animate) 0f else 1f) }
    LaunchedEffect(spec, resetKey) { if (animate) pop.animateTo(1f, tween(380, easing = FastOutSlowInEasing)) }

    val palette = listOf(c.accent, c.gold, c.accent2, c.pop1, c.pop2)
    val pulse: State<Float> = if (animate) {
        rememberInfiniteTransition(label = "play").animateFloat(0f, 1f, infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "t")
    } else remember { mutableStateOf(0f) }
    val ring: State<Float> = if (animate) {
        rememberInfiniteTransition(label = "ring").animateFloat(0f, 1f, infiniteRepeatable(tween(1400, easing = LinearEasing)), label = "r")
    } else remember { mutableStateOf(0f) }

    fun tap(i: Int) {
        if (solved || masks[i] == 0) return
        if (src >= 0 && !awake[i]) {
            // not powered yet: shake instead of turning
            scope.launch { offsets[i].snapTo(12f); offsets[i].animateTo(0f, spring(dampingRatio = 0.2f, stiffness = 450f)) }
            return
        }
        val turned = Tile.rotateCw(masks[i])
        if (turned == masks[i]) return
        touched = true
        val next = masks.copyOf().also { it[i] = turned }
        masks = next
        scope.launch {
            if (animate) {
                offsets[i].snapTo(offsets[i].value - 90f)
                offsets[i].animateTo(0f, tween(180, easing = FastOutSlowInEasing))
            } else offsets[i].snapTo(0f)
        }
        if (src >= 0) {
            val before = awake.copyOf()
            wakeFrom(next, spec.w, spec.h, src, awake)
            for (j in 0 until n) {
                if (!awake[j] || before[j]) continue
                val d = abs(j % spec.w - src % spec.w) + abs(j / spec.w - src / spec.w)
                scope.launch {
                    if (animate) { delay(d * 70L); lit[j].animateTo(1f, tween(380, easing = FastOutSlowInEasing)) } else lit[j].snapTo(1f)
                }
            }
        }
        if (Rules.isSolved(next, spec.w, spec.h, spec.objective)) {
            solved = true
            onSolved()
            scope.launch { delay(200); if (animate) win.animateTo(1f, tween(1100, easing = LinearEasing)) else win.snapTo(1f) }
        }
    }

    Canvas(
        modifier.aspectRatio(spec.w.toFloat() / spec.h).pointerInput(spec, resetKey) {
            detectTapGestures { pos ->
                val cellPx = size.width / spec.w.toFloat()
                val col = (pos.x / cellPx).toInt()
                val row = (pos.y / cellPx).toInt()
                if (col in 0 until spec.w && row in 0 until spec.h) tap(row * spec.w + col)
            }
        }
    ) {
        val cell = size.width / spec.w
        val ms = masks
        val ui = GameUiState(width = spec.w, height = spec.h, masks = ms, sparkSource = src)
        val comps = components(ms, spec.w, spec.h)
        val denom = (spec.w + spec.h - 2).coerceAtLeast(1).toFloat()
        for (pass in 0..2) {
            for (i in 0 until n) {
                if (ms[i] == 0) continue
                val dist = ((i % spec.w) + (i / spec.w)) / denom
                val wave = (win.value * 1.7f - dist * 0.7f).coerceIn(0f, 1f)
                drawPiece(pass, ui, comps, palette, i, cell, offsets[i].value, pop.value, wave, c, lit[i].value, pulse.value)
            }
        }
        if (!touched && !solved) {
            // a pulsing ring shows where to tap first
            val k = (0 until n).firstOrNull { ms[it] != spec.solved[it] && (src < 0 || awake[it]) }
            if (k != null) {
                val ctr = Offset((k % spec.w) * cell + cell / 2, (k / spec.w) * cell + cell / 2)
                val t = ring.value
                drawCircle(c.gold.copy(alpha = 0.75f * (1f - t)), cell * (0.26f + 0.3f * t), ctr, style = Stroke(cell * 0.04f))
                drawCircle(c.gold.copy(alpha = 0.18f), cell * 0.12f, ctr)
            }
        }
    }
}

@Composable
private fun StarsHintDemo() {
    val c = LocalLoop.current
    val animate = LocalAnimations.current
    val tState: State<Float> = if (animate) {
        rememberInfiniteTransition(label = "stars").animateFloat(0f, 1f, infiniteRepeatable(tween(3600, easing = LinearEasing)), label = "t")
    } else remember { mutableStateOf(0.9f) }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            for (i in 0 until 3) {
                Icon(
                    Icons.Rounded.Star, null, tint = c.gold,
                    modifier = Modifier.size(56.dp).graphicsLayer {
                        val p = (tState.value * 1.5f - i * 0.2f).coerceIn(0f, 1f)
                        val back = 1f + 2.70158f * (p - 1f) * (p - 1f) * (p - 1f) + 1.70158f * (p - 1f) * (p - 1f)
                        scaleX = back; scaleY = back
                        rotationZ = (1f - p) * -40f
                        alpha = if (tState.value > 0.93f) (1f - tState.value) / 0.07f else 1f
                    }
                )
            }
        }
        Spacer(Modifier.height(22.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(64.dp).clip(CircleShape).background(c.gold.copy(alpha = 0.18f)).graphicsLayer {
                    val s = 1f + 0.1f * sin(tState.value * 2f * PI.toFloat() * 2f)
                    scaleX = s; scaleY = s
                },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.Lightbulb, null, tint = c.gold, modifier = Modifier.size(36.dp)) }
            Spacer(Modifier.width(12.dp))
            Text("+1", color = c.gold, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

private class HowPage(val title: String, val body: String, val tip: String, val play: PlaySpec? = null, val demo: (@Composable () -> Unit)? = null)

private fun pages(): List<HowPage> = listOf(
    HowPage(
        "Tap to rotate",
        "Every piece turns 90° clockwise each time you tap it. Turn both pieces so their lines meet.",
        "Try it: tap the glowing piece", play = playTap
    ),
    HowPage(
        "Match the ends",
        "A line must meet a line on the neighbouring piece. Red ends are loose, glowing lines are joined. Connect all three.",
        "Red means loose, glow means joined", play = playConnect
    ),
    HowPage(
        "Build one network",
        "Connect every piece into a single network. When no loose end is left anywhere, the level is solved.",
        "Different colours are separate groups", play = playNetwork
    ),
    HowPage(
        "Close the loops",
        "On \"Close every loop\" levels nothing may dangle. Every piece has to sit on a closed loop.",
        "Make one closed ring", play = playLoop
    ),
    HowPage(
        "Spark mode",
        "Only lit pieces can turn. Turn the piece in the golden ring to send power along, wake the dark ones, then finish the shape.",
        "Dark pieces shake until power reaches them", play = playSpark
    ),
    HowPage(
        "Stars and hints",
        "Finish in fewer moves to earn up to 3 stars. A hint points to the next piece to turn, but caps that level at 2 stars. Earn hints by playing, or watch a short ad.",
        "Stuck? Tap the lightbulb", demo = { StarsHintDemo() }
    )
)

@Composable
fun HowToScreen(firstRun: Boolean, onDone: () -> Unit) {
    val c = LocalLoop.current
    val list = remember { pages() }
    val pager = rememberPagerState(pageCount = { list.size })
    val scope = rememberCoroutineScope()
    val last = pager.currentPage == list.size - 1
    val solvedPages = remember { mutableStateMapOf<Int, Boolean>() }
    val resets = remember { mutableStateMapOf<Int, Int>() }
    BackHandler(enabled = firstRun) { onDone() }

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar(
            "HOW TO PLAY", null,
            onBack = if (firstRun) null else onDone,
            trailing = {
                if (!last) Box(Modifier.gamePress(label = "Skip tutorial", onClick = onDone).padding(horizontal = 14.dp, vertical = 12.dp)) {
                    Text("Skip", color = c.textDim, fontWeight = FontWeight.SemiBold)
                }
            }
        )
        HorizontalPager(state = pager, modifier = Modifier.weight(1f), userScrollEnabled = true) { index ->
            val page = list[index]
            val done = solvedPages[index] == true
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                LoopCard(Modifier.fillMaxWidth()) {
                    Box(Modifier.fillMaxWidth().height(240.dp), contentAlignment = Alignment.Center) {
                        val play = page.play
                        if (play != null) {
                            PlayBoard(play, resets[index] ?: 0, { solvedPages[index] = true }, Modifier.fillMaxWidth(play.widthFraction))
                        } else page.demo?.invoke()
                    }
                }
                Spacer(Modifier.height(24.dp))
                Text("${index + 1}", color = c.accent, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                Text(page.title, color = c.text, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(10.dp))
                Text(page.body, color = c.textDim, fontSize = 15.sp, lineHeight = 22.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(14.dp))
                if (done) {
                    Row(
                        Modifier.clip(RoundedCornerShape(50)).background(c.good.copy(alpha = 0.16f)).padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Check, null, tint = c.good, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Nice! You solved it", color = c.good, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(6.dp))
                    Box(
                        Modifier.gamePress(label = "Try this step again") { solvedPages[index] = false; resets[index] = (resets[index] ?: 0) + 1 }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) { Text("Play again", color = c.textDim, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
                } else {
                    Text(
                        page.tip, color = c.gold, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clip(RoundedCornerShape(50)).background(c.gold.copy(alpha = 0.14f)).padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }
                Spacer(Modifier.height(12.dp))
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(vertical = 10.dp).semantics { contentDescription = "Page ${pager.currentPage + 1} of ${list.size}" },
            horizontalArrangement = Arrangement.Center
        ) {
            list.indices.forEach { i ->
                val width by animateDpAsState(if (i == pager.currentPage) 26.dp else 8.dp, label = "dot")
                Box(
                    Modifier.padding(horizontal = 4.dp).height(8.dp).width(width).clip(CircleShape)
                        .background(if (i == pager.currentPage) c.accent else if (solvedPages[i] == true) c.good else c.border)
                )
            }
        }
        PrimaryButton(
            if (last) "LET'S PLAY" else "NEXT",
            { if (last) onDone() else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } },
            Modifier.fillMaxWidth().padding(horizontal = 24.dp).padding(bottom = 16.dp), big = true
        )
    }
}
