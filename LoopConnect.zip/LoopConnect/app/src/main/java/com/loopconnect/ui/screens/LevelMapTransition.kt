package com.loopconnect.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.loopconnect.engine.GameMode
import com.loopconnect.engine.Progress
import com.loopconnect.ui.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

private val ONE: () -> Float = { 1f }
private val ZERO: () -> Float = { 0f }

/** Where the "done" look takes over from the gold "current" look (fraction of the completion morph). */
private const val DONE_FADE = 0.3f

/** Overshooting pop, 0 -> 1. Used for the stars landing one by one. */
private fun popCurve(x: Float): Float {
    val c1 = 1.70158f
    val c3 = c1 + 1f
    val t = x - 1f
    return 1f + c3 * t * t * t + c1 * t * t
}

/**
 * Shown after a campaign / challenge level is cleared, instead of jumping straight to the next puzzle.
 *
 * The same winding level map as the level-select screen, with this sequence:
 *  1. level [from] (gold "PLAY") turns into a completed node and its stars pop in,
 *  2. the connector lights up and a glowing spark travels to the next node while the map pans along,
 *  3. level `from + 1` shakes its padlock, the lock opens, and the node flips from dark to gold with a burst.
 *
 * [newUnlock] is true on the first clear of a level (the next level was locked before). On a replay the next
 * level is already open, so only the travel part plays. With [animated] false the final state shows at once.
 * Once the animation ends, tapping the gold PLAY node starts the next level (system Back returns to the result card).
 */
@Composable
fun LevelMapTransition(
    from: Int,
    stars: Int,
    newUnlock: Boolean,
    mode: GameMode,
    progress: Progress,
    animated: Boolean,
    onCelebrate: () -> Unit,
    onPlay: () -> Unit
) {
    val c = LocalLoop.current
    val challenge = mode == GameMode.CHALLENGE
    val to = from + 1
    val frontier = if (challenge) progress.challengeCleared + 1 else progress.highestUnlocked
    val limit = to + 12
    val playUnlock = animated && newUnlock

    val appear = remember { Animatable(if (animated) 0f else 1f) }
    val morph = remember { Animatable(if (playUnlock) 0f else 1f) }
    val travel = remember { Animatable(if (animated) 0f else 1f) }
    val unlock = remember { Animatable(if (playUnlock) 0f else 1f) }
    var finished by remember { mutableStateOf(!animated) }
    // Start with the cleared level in the middle of the screen (the final level when nothing animates).
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = max(0, (if (animated) from else to) - 1))
    val celebrate by rememberUpdatedState(onCelebrate)
    val sfx = LocalSfx.current
    val density = LocalDensity.current
    val rowPx = with(density) { ROW.toPx() }
    // The screen background pads for the system bars; this overlay paints under them too so all is one colour.
    val barTop = WindowInsets.statusBars.getTop(density).toFloat()
    val barBottom = WindowInsets.navigationBars.getBottom(density).toFloat()

    LaunchedEffect(Unit) {
        if (!animated) return@LaunchedEffect
        launch { appear.animateTo(1f, tween(300, easing = LinearEasing)) }
        delay(650)
        if (newUnlock) {
            // Same timing as the stars popping in the node (they start at 30 % of the morph, 210 ms apart).
            launch { delay(270); for (i in 0 until stars.coerceAtMost(3)) { sfx?.playStar(i); delay(210) } }
            morph.animateTo(1f, tween(900, easing = LinearEasing))
        }
        delay(200)
        // The camera follows the spark: the next node is exactly one row further down, so scroll one row.
        // It is a touch slower than the spark, so the spark leads and the camera settles on the new node.
        val camera = launch { listState.animateScrollBy(rowPx, tween(1400, easing = FastOutSlowInEasing)) }
        travel.animateTo(1f, tween(1100, easing = FastOutSlowInEasing))
        camera.join()
        if (newUnlock) {
            launch { delay(480); celebrate() }
            unlock.animateTo(1f, tween(1300, easing = LinearEasing))
        }
        finished = true
    }

    Box(
        Modifier.fillMaxSize()
            .graphicsLayer { alpha = appear.value }
            .drawBehind {
                drawRect(
                    Brush.verticalGradient(listOf(c.bgTop, c.bgBottom), startY = -barTop, endY = size.height + barBottom),
                    topLeft = Offset(0f, -barTop),
                    size = Size(size.width, size.height + barTop + barBottom)
                )
            }
            // Swallow touches so nothing underneath (the result card buttons) can be hit through the map.
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        GlowDots(Modifier.fillMaxSize())
        SkyFx(withStars = false)   // this overlay hides the app background, so it brings its own shooting stars
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxWidth().heightIn(min = 64.dp).padding(horizontal = 14.dp, vertical = 6.dp), contentAlignment = Alignment.Center) {
                Text(
                    if (challenge) "CHALLENGE $from CLEARED" else "LEVEL $from COMPLETE",
                    color = c.text, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.5.sp,
                    textAlign = TextAlign.Center, maxLines = 1
                )
            }
            Box(Modifier.fillMaxWidth().height(30.dp), contentAlignment = Alignment.Center) {
                if (newUnlock) {
                    Text(
                        if (challenge) "CHALLENGE $to UNLOCKED" else "LEVEL $to UNLOCKED",
                        color = c.gold, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp,
                        modifier = Modifier.graphicsLayer {
                            val p = ((unlock.value - 0.6f) / 0.3f).coerceIn(0f, 1f)
                            alpha = p
                            scaleX = 0.8f + 0.2f * p
                            scaleY = 0.8f + 0.2f * p
                        }
                    )
                }
            }
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                // Half a screen of padding on both ends lets any row be scrolled exactly to the centre.
                val pad = if (maxHeight > ROW) (maxHeight - ROW) / 2 else 0.dp
                LazyColumn(
                    state = listState,
                    userScrollEnabled = finished,
                    contentPadding = PaddingValues(vertical = pad),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(limit, key = { it + 1 }) { i ->
                        val n = i + 1
                        val isDone = if (challenge) n <= progress.challengeCleared else progress.isCompleted(n)
                        val earned = progress.results[n]?.stars ?: 0
                        MapRow(
                            n = n, from = from, frontier = frontier, newUnlock = newUnlock,
                            done = isDone, stars = if (n == from) max(earned, stars) else earned,
                            showStars = !challenge,
                            morph = { morph.value }, travel = { travel.value }, unlock = { unlock.value },
                            interactive = finished, onPlay = onPlay
                        )
                    }
                }
            }
        }
    }
}

private class Dot(val x: Float, val y: Float, val r: Float, val color: Int, val phase: Float, val sway: Int, val cycles: Int)

/**
 * Tiny glowing specks scattered at random behind the map. Each one sways a pixel or two around its spot and
 * twinkles on its own rhythm and phase, so they shimmer one after another instead of all at once.
 * Everything loops seamlessly every 90 s. With Animation off the specks stay still.
 */
@Composable
private fun GlowDots(modifier: Modifier) {
    val c = LocalLoop.current
    val animate = LocalAnimations.current
    val dots = remember {
        val rnd = Random(23)
        List(24) {
            Dot(
                x = rnd.nextFloat(), y = rnd.nextFloat(),
                r = 0.55f + rnd.nextFloat() * 0.75f,
                color = rnd.nextInt(3),
                phase = rnd.nextFloat() * 6.2832f,
                sway = 1 + rnd.nextInt(2),
                cycles = 7 + rnd.nextInt(10)   // one twinkle every ~5 to 13 s, different for every dot
            )
        }
    }
    val tState: State<Float> = if (animate) {
        rememberInfiniteTransition(label = "dots").animateFloat(0f, 1f, infiniteRepeatable(tween(90_000, easing = LinearEasing)), label = "t")
    } else remember { mutableStateOf(0f) }
    val colors = listOf(c.accent, c.accent2, Color.White)
    Canvas(modifier) {
        val t = tState.value * 2f * PI.toFloat()
        val unit = 1.dp.toPx()
        for (d in dots) {
            val px = d.x * size.width + sin(t * d.sway + d.phase) * 3f * unit
            val py = d.y * size.height + cos(t * d.sway + d.phase) * 3f * unit
            // 0..1 wave, squared so each dot rests dim for a while and then swells and fades smoothly.
            val w = 0.5f + 0.5f * sin(t * d.cycles + d.phase * 3f)
            val glow = w * w
            val col = colors[d.color]
            val r = d.r * unit
            val o = Offset(px, py)
            drawCircle(col.copy(alpha = 0.16f * glow), r * (2.5f + 2.5f * glow), o)
            drawCircle(col.copy(alpha = 0.30f * glow), r * 1.8f, o)
            drawCircle(col.copy(alpha = 0.18f + 0.82f * glow), r, o)
        }
    }
}

@Composable
private fun MapRow(
    n: Int, from: Int, frontier: Int, newUnlock: Boolean,
    done: Boolean, stars: Int, showStars: Boolean,
    morph: () -> Float, travel: () -> Float, unlock: () -> Float,
    interactive: Boolean, onPlay: () -> Unit
) {
    val c = LocalLoop.current
    val bias = biasFor(n)
    val isFrom = n == from
    val isTo = n == from + 1
    val animFrom = isFrom && newUnlock   // was the gold "current" node a moment ago
    val animTo = isTo && newUnlock       // was locked a moment ago

    // The connector between `from` and `from + 1` starts dark and is lit by the travelling spark.
    val upLit = n > 1 && n <= frontier && !animTo
    val downLit = n < frontier && !animFrom

    val openP: () -> Float = if (animTo) unlock else if (n <= frontier) ONE else ZERO
    val doneP: () -> Float = if (animFrom) morph else if (done) ONE else ZERO
    val pulsing = animFrom || (animTo && interactive) || (!animTo && n == frontier && !done)
    val desc = when {
        n > frontier -> "Level $n, locked"
        n == frontier && !done -> "Level $n, current level"
        else -> "Level $n, completed with $stars stars"
    }

    Box(Modifier.fillMaxWidth().height(ROW).padding(horizontal = 36.dp)) {
        Canvas(Modifier.fillMaxSize()) {
            val r = NODE.toPx() / 2f
            fun xOf(b: Float) = r + (size.width - 2f * r) * (b + 1f) / 2f
            val h = size.height
            val x = xOf(bias)
            val xPrev = if (n == 1) x else (xOf(biasFor(n - 1)) + x) / 2f
            val xNext = (xOf(biasFor(n + 1)) + x) / 2f
            val upper = Path().apply {
                moveTo(xPrev, 0f)
                cubicTo(xPrev, h * 0.25f, x, h * 0.25f, x, h / 2f)
            }
            val lower = Path().apply {
                moveTo(x, h / 2f)
                cubicTo(x, h * 0.75f, xNext, h * 0.75f, xNext, h)
            }
            fun half(p: Path, lit: Boolean) {
                if (lit) drawPath(p, c.accent.copy(alpha = 0.18f), style = Stroke(16f, cap = StrokeCap.Round))
                drawPath(p, if (lit) c.accent else c.border.copy(alpha = 0.7f), style = Stroke(6f, cap = StrokeCap.Round))
            }
            if (n > 1) half(upper, upLit)
            half(lower, downLit)

            if (isFrom || isTo) {
                val t = travel()
                // The spark covers the lower half of `from`'s row, then the upper half of `to`'s row.
                val frac = if (isFrom) t / 0.5f else (t - 0.5f) / 0.5f
                val seg = if (isFrom) lower else upper
                val pm = PathMeasure()
                pm.setPath(seg, false)
                if (newUnlock && frac > 0f) {
                    val part = Path()
                    pm.getSegment(0f, pm.length * frac.coerceIn(0f, 1f), part, true)
                    drawPath(part, c.accent.copy(alpha = 0.18f), style = Stroke(16f, cap = StrokeCap.Round))
                    drawPath(part, c.accent, style = Stroke(6f, cap = StrokeCap.Round))
                }
                if (t > 0f && t < 1f && frac in 0f..1f) {
                    val pos = pm.getPosition(pm.length * frac)
                    drawCircle(c.accent.copy(alpha = 0.25f), 18.dp.toPx(), pos)
                    drawCircle(c.accent.copy(alpha = 0.55f), 11.dp.toPx(), pos)
                    drawCircle(Color.White, 6.dp.toPx(), pos)
                }
            }
        }
        MapNode(
            n = n, modifier = Modifier.align(BiasAlignment(bias, 0f)).size(NODE),
            stars = stars, showStars = showStars, openP = openP, doneP = doneP,
            pulsing = pulsing, celebrate = animTo, desc = desc,
            onClick = if (isTo && interactive) onPlay else null
        )
    }
}

/**
 * One map node drawn as stacked layers that cross-fade, all driven by two 0..1 values:
 *  [openP]  0 = dark locked node with a padlock, 1 = unlocked (the padlock shakes, opens and fades around 0..0.7),
 *  [doneP]  0 = gold "PLAY" node, 1 = blue completed node with stars (or a tick in Challenge).
 * Both are read only inside graphicsLayer / draw lambdas, so animating them never recomposes anything.
 */
@Composable
private fun MapNode(
    n: Int, modifier: Modifier, stars: Int, showStars: Boolean,
    openP: () -> Float, doneP: () -> Float,
    pulsing: Boolean, celebrate: Boolean, desc: String, onClick: (() -> Unit)?
) {
    val c = LocalLoop.current
    val animate = LocalAnimations.current
    val pulse: State<Float> = if (pulsing && animate) {
        rememberInfiniteTransition(label = "mapNode").animateFloat(
            0f, 1f, infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "pulse"
        )
    } else remember { mutableStateOf(0.5f) }

    fun lockFade(): Float = ((openP() - 0.4f) / 0.3f).coerceIn(0f, 1f)
    fun doneFade(): Float = (doneP() / DONE_FADE).coerceIn(0f, 1f)

    val root = if (onClick != null) modifier.gamePress(label = desc, onClick = onClick)
    else modifier.semantics { contentDescription = desc }

    Box(root, contentAlignment = Alignment.Center) {
        Box(
            Modifier.fillMaxSize().graphicsLayer {
                // Springy pop when the node unlocks and again when it turns into a completed node.
                val a = ((openP() - 0.45f) / 0.4f).coerceIn(0f, 1f)
                val b = ((doneP() - 0.45f) / 0.4f).coerceIn(0f, 1f)
                val s = 1f + 0.2f * sin(PI.toFloat() * a) + 0.14f * sin(PI.toFloat() * b)
                scaleX = s
                scaleY = s
            }
        ) {
            // Pulsing halo of the current level.
            if (pulsing) {
                Box(
                    Modifier.fillMaxSize().graphicsLayer {
                        val p = pulse.value
                        val s = 1f + 0.22f * p
                        scaleX = s
                        scaleY = s
                        alpha = 0.55f * (1f - p) * lockFade() * (1f - doneFade())
                    }.clip(CircleShape).background(c.gold)
                )
            }
            // Layer 1: locked.
            Box(
                Modifier.fillMaxSize()
                    .graphicsLayer { alpha = if (lockFade() >= 1f) 0f else 1f }
                    .clip(CircleShape).background(c.surface).border(2.dp, c.border, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$n", color = c.textDim, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Box(
                        Modifier.size(14.dp).graphicsLayer {
                            val u = openP()
                            // 0..0.22 the padlock shakes, then it hops while it opens.
                            val shake = (u / 0.22f).coerceIn(0f, 1f)
                            rotationZ = if (u > 0f && u < 0.22f) sin(shake * 6f * PI.toFloat()) * 16f * (1f - shake) else 0f
                            val hop = sin(PI.toFloat() * ((u - 0.22f) / 0.2f).coerceIn(0f, 1f))
                            translationY = -5.dp.toPx() * hop
                            scaleX = 1f + 0.6f * hop
                            scaleY = 1f + 0.6f * hop
                        }
                    ) {
                        Icon(
                            Icons.Rounded.Lock, null, tint = c.textDim,
                            modifier = Modifier.fillMaxSize().graphicsLayer { alpha = if (openP() < 0.22f) 1f else 0f }
                        )
                        Icon(
                            Icons.Rounded.LockOpen, null, tint = c.gold,
                            modifier = Modifier.fillMaxSize().graphicsLayer { alpha = if (openP() < 0.22f) 0f else 1f }
                        )
                    }
                }
            }
            // Layer 2: gold "current level" node.
            Box(
                Modifier.fillMaxSize()
                    .graphicsLayer { alpha = if (doneFade() >= 1f) 0f else lockFade() }
                    .clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(c.gold, Color(0xFFFF9A3D))))
                    .border(2.dp, Color.White.copy(alpha = 0.7f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$n", color = Color(0xFF2A1900), fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    Text("PLAY", color = Color(0xFF2A1900), fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                }
            }
            // Layer 3: completed node.
            Box(
                Modifier.fillMaxSize()
                    .graphicsLayer { alpha = doneFade() }
                    .clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(c.accent, c.accent2)))
                    .border(2.dp, Color.White.copy(alpha = 0.45f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$n", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    if (showStars) {
                        Row(horizontalArrangement = Arrangement.spacedBy(1.dp)) {
                            for (i in 0 until 3) {
                                val got = i < stars
                                Icon(
                                    Icons.Rounded.Star, null, tint = if (got) c.gold else c.border,
                                    modifier = Modifier.size(11.dp).graphicsLayer {
                                        // Earned stars land one after another once the node has turned blue.
                                        val p = ((doneP() - DONE_FADE) / (1f - DONE_FADE) * 3f - i).coerceIn(0f, 1f)
                                        val s = if (got) popCurve(p) else 1f
                                        scaleX = s
                                        scaleY = s
                                    }
                                )
                            }
                        }
                    } else {
                        Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(14.dp))
                    }
                }
            }
        }
        // Burst of light when the node unlocks: an expanding ring plus sparks.
        if (celebrate) {
            Canvas(Modifier.requiredSize(NODE * 2.8f)) {
                val b = ((openP() - 0.5f) / 0.5f).coerceIn(0f, 1f)
                if (b > 0f && b < 1f) {
                    val ctr = center
                    val r0 = NODE.toPx() / 2f
                    val ease = 1f - (1f - b) * (1f - b)
                    drawCircle(
                        c.gold.copy(alpha = 0.7f * (1f - b)), r0 * (1f + 0.9f * ease), ctr,
                        style = Stroke(width = 5.dp.toPx() * (1f - b))
                    )
                    for (k in 0 until 10) {
                        val ang = (k * 36f + 12f) * (PI.toFloat() / 180f)
                        val dist = r0 * (1.05f + 1.0f * ease)
                        val p = Offset(ctr.x + cos(ang) * dist, ctr.y + sin(ang) * dist)
                        drawCircle(
                            (if (k % 2 == 0) c.gold else Color.White).copy(alpha = 1f - b),
                            3.5f.dp.toPx() * (1f - b), p
                        )
                    }
                }
            }
        }
    }
}
