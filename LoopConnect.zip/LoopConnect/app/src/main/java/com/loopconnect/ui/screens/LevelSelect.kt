package com.loopconnect.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.loopconnect.ui.*
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.sin

private val NODE = 68.dp
private val ROW = 100.dp

private fun biasFor(n: Int): Float = sin(n * 0.85f) * 0.72f

@Composable
fun LevelSelectScreen(vm: GameViewModel, onBack: () -> Unit, onPlay: () -> Unit) {
    val c = LocalLoop.current
    val progress by vm.progress.collectAsStateWithLifecycle()
    var pages by rememberSaveable { mutableIntStateOf(0) }
    val current = progress.highestUnlocked
    // Levels are generated on demand, so the map is unlimited: always show a bit past the frontier.
    val limit = max(100, current + 20) + pages * 20
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { listState.scrollToItem(max(0, current - 4)) }

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("LEVELS", "${progress.levelsCompleted} completed  ·  next: $current", onBack)
        Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Start" to 0, "Medium" to 30, "Hard" to 70, "Current" to max(0, current - 4)).forEach { (label, index) ->
                Box(
                    Modifier.weight(1f).heightIn(min = 40.dp).gamePress(label = "Jump to $label") {
                        scope.launch { listState.animateScrollToItem(index) }
                    }.clip(RoundedCornerShape(50)).background(c.surface.copy(alpha = 0.9f))
                        .border(1.dp, c.border, RoundedCornerShape(50)),
                    contentAlignment = Alignment.Center
                ) { Text(label, color = c.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
            }
        }
        LazyColumn(state = listState, modifier = Modifier.weight(1f), contentPadding = PaddingValues(vertical = 16.dp)) {
            items((1..limit).toList(), key = { it }) { n ->
                PathNode(n, progress.isUnlocked(n), n == current, progress.results[n]?.stars ?: 0, current) {
                    vm.startLevel(n)
                    onPlay()
                }
            }
            item {
                Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    OutlineButton("Show 20 more", { pages++ })
                }
            }
        }
    }
}

@Composable
private fun PathNode(n: Int, unlocked: Boolean, isCurrent: Boolean, stars: Int, frontier: Int, onClick: () -> Unit) {
    val c = LocalLoop.current
    val bias = biasFor(n)
    val desc = when {
        !unlocked -> "Level $n, locked"
        isCurrent -> "Level $n, current level"
        else -> "Level $n, completed with $stars stars"
    }
    val lit = n < frontier // the connector leaving this node is "powered" once the next level is open
    Box(Modifier.fillMaxWidth().height(ROW).padding(horizontal = 36.dp)) {
        Canvas(Modifier.fillMaxSize()) {
            val r = NODE.toPx() / 2f
            fun xOf(b: Float) = r + (size.width - 2f * r) * (b + 1f) / 2f
            val h = size.height
            val x = xOf(bias)
            val xPrev = if (n == 1) x else (xOf(biasFor(n - 1)) + x) / 2f
            val xNext = (xOf(biasFor(n + 1)) + x) / 2f
            val path = Path().apply {
                moveTo(xPrev, 0f)
                cubicTo(xPrev, h * 0.25f, x, h * 0.25f, x, h / 2f)
                cubicTo(x, h * 0.75f, xNext, h * 0.75f, xNext, h)
            }
            if (lit) drawPath(path, c.accent.copy(alpha = 0.18f), style = Stroke(16f, cap = StrokeCap.Round))
            drawPath(path, if (lit) c.accent else c.border.copy(alpha = 0.7f), style = Stroke(6f, cap = StrokeCap.Round))
        }
        val nodeMod = Modifier.align(BiasAlignment(bias, 0f)).size(NODE)
        when {
            !unlocked -> Box(
                nodeMod.clip(CircleShape).background(c.surface).border(2.dp, c.border, CircleShape).semantics { contentDescription = desc },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$n", color = c.textDim, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Icon(Icons.Rounded.Lock, null, tint = c.textDim, modifier = Modifier.size(14.dp))
                }
            }
            isCurrent -> CurrentNode(n, nodeMod.semantics { contentDescription = desc }, onClick)
            else -> Box(
                nodeMod.gamePress(label = desc, onClick = onClick).clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(c.accent, c.accent2)))
                    .border(2.dp, Color.White.copy(alpha = 0.45f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$n", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    StarRow(stars, 11.dp, spacing = 1.dp)
                }
            }
        }
    }
}

@Composable
private fun CurrentNode(n: Int, modifier: Modifier, onClick: () -> Unit) {
    val c = LocalLoop.current
    val animate = LocalAnimations.current
    val pulse by (if (animate) rememberInfiniteTransition(label = "node").animateFloat(
        0f, 1f, infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "p"
    ) else remember { mutableStateOf(0.5f) })
    Box(modifier, contentAlignment = Alignment.Center) {
        Box(
            Modifier.fillMaxSize().graphicsLayer { scaleX = 1f + 0.22f * pulse; scaleY = 1f + 0.22f * pulse; alpha = 0.55f * (1f - pulse) }
                .clip(CircleShape).background(c.gold)
        )
        Box(
            Modifier.fillMaxSize().gamePress(label = "Play level $n", onClick = onClick).clip(CircleShape)
                .background(Brush.verticalGradient(listOf(c.gold, Color(0xFFFF9A3D))))
                .border(2.dp, Color.White.copy(alpha = 0.7f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$n", color = Color(0xFF2A1900), fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Text("PLAY", color = Color(0xFF2A1900), fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
            }
        }
    }
}
