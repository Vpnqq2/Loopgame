package com.loopconnect.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.loopconnect.ui.*
import kotlin.math.max

@Composable
fun LevelSelectScreen(vm: GameViewModel, onBack: () -> Unit, onPlay: () -> Unit) {
    val c = LocalLoop.current
    val progress by vm.progress.collectAsStateWithLifecycle()
    var filter by rememberSaveable { mutableIntStateOf(0) }
    var pages by rememberSaveable { mutableIntStateOf(0) }
    val current = progress.highestUnlocked
    // Levels are generated on demand, so the list is unlimited: always show a bit past the frontier.
    val limit = max(100, current + 20) + pages * 20
    val levels = when (filter) {
        1 -> (1..30).toList()
        2 -> (31..70).toList()
        3 -> (71..limit).toList()
        else -> (1..limit).toList()
    }
    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("Level Selection", "${progress.levelsCompleted} completed", onBack)
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp))
                .background(c.surface).padding(4.dp)
        ) {
            listOf("All", "Easy", "Medium", "Hard").forEachIndexed { i, label ->
                val sel = filter == i
                Box(
                    Modifier.weight(1f).heightIn(min = 40.dp).clip(RoundedCornerShape(10.dp))
                        .background(if (sel) c.accent else c.surface)
                        .clickable(role = Role.Tab, onClickLabel = "Show $label levels") { filter = i },
                    contentAlignment = Alignment.Center
                ) { Text(label, color = if (sel) androidx.compose.ui.graphics.Color.White else c.textDim, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
            }
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(levels, key = { it }) { n ->
                LevelCell(n, progress.isUnlocked(n), n == current, progress.results[n]?.stars ?: 0) {
                    vm.startLevel(n)
                    onPlay()
                }
            }
            if (filter == 0 || filter == 3) {
                item(span = { GridItemSpan(4) }) {
                    Box(Modifier.fillMaxWidth().padding(top = 8.dp), contentAlignment = Alignment.Center) {
                        OutlineButton("Show 20 more", { pages++ })
                    }
                }
            }
        }
    }
}

@Composable
private fun LevelCell(n: Int, unlocked: Boolean, isCurrent: Boolean, stars: Int, onClick: () -> Unit) {
    val c = LocalLoop.current
    val shape = RoundedCornerShape(14.dp)
    val desc = when {
        !unlocked -> "Level $n, locked"
        isCurrent -> "Level $n, current level"
        else -> "Level $n, completed with $stars stars"
    }
    Column(
        Modifier.aspectRatio(1f).clip(shape)
            .background(if (isCurrent) Brush.linearGradient(listOf(c.accent.copy(alpha = 0.45f), c.accent2.copy(alpha = 0.35f))) else Brush.linearGradient(listOf(c.surface, c.surface)))
            .border(if (isCurrent) 2.dp else 1.dp, if (isCurrent) c.accent else c.border, shape)
            .clickable(enabled = unlocked, role = Role.Button, onClick = onClick)
            .semantics { contentDescription = desc },
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text("$n", color = if (unlocked) c.text else c.textDim, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        when {
            !unlocked -> Icon(Icons.Rounded.Lock, null, tint = c.textDim, modifier = Modifier.size(16.dp))
            stars > 0 -> StarRow(stars, 11.dp, spacing = 1.dp)
            else -> Spacer(Modifier.height(11.dp))
        }
    }
}
