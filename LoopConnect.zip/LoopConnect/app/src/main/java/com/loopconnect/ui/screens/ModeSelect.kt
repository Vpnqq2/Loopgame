package com.loopconnect.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.FlashOn
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Spa
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.loopconnect.engine.GameMode
import com.loopconnect.engine.ModeRules
import com.loopconnect.engine.ZenSize
import com.loopconnect.ui.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween

@Composable
fun ModeSelectScreen(vm: GameViewModel, onBack: () -> Unit, onClassic: () -> Unit, onChallenge: () -> Unit, onPlay: () -> Unit) {
    val c = LocalLoop.current
    val p by vm.progress.collectAsStateWithLifecycle()
    var dialog by rememberSaveable { mutableStateOf("") } // "", zen, rush
    var zenSize by rememberSaveable { mutableStateOf(ZenSize.MEDIUM.name) }
    val done = p.levelsCompleted

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("GAME MODES", "Pick how you want to play", onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            ModeCard(
                GameMode.CLASSIC, Icons.Rounded.GridView, c.accent,
                "Level ${p.highestUnlocked}  ·  ${p.levelsCompleted} completed", true, null, onClassic
            )
            ModeCard(GameMode.ZEN, Icons.Rounded.Spa, c.good, "${p.zenSolved} solved", true, null) { dialog = "zen" }
            ModeCard(
                GameMode.CHALLENGE, Icons.Rounded.Bolt, c.accent2, "Cleared ${p.challengeCleared}",
                done >= ModeRules.CHALLENGE_UNLOCK_LEVELS,
                "Complete ${ModeRules.CHALLENGE_UNLOCK_LEVELS} Classic levels to unlock", onChallenge
            )
            ModeCard(
                GameMode.SPARK, Icons.Rounded.FlashOn, c.gold, "Powered ${p.sparkCleared}",
                done >= ModeRules.SPARK_UNLOCK_LEVELS,
                "Complete ${ModeRules.SPARK_UNLOCK_LEVELS} Classic levels to unlock"
            ) { vm.startSpark(p.sparkCleared + 1); onPlay() }
            ModeCard(
                GameMode.RUSH, Icons.Rounded.Timer, Color(0xFFFF8A4D),
                if (p.rushRuns == 0) "No runs yet" else "Best ${p.rushBest}  ·  ${p.rushRuns} runs",
                done >= ModeRules.RUSH_UNLOCK_LEVELS,
                "Complete ${ModeRules.RUSH_UNLOCK_LEVELS} Classic levels to unlock"
            ) { dialog = "rush" }
            Spacer(Modifier.height(12.dp))
        }
    }

    when (dialog) {
        "zen" -> Dialog(onDismissRequest = { dialog = "" }) {
            LoopCard(Modifier.fillMaxWidth().popIn()) {
                Text("Zen", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(8.dp))
                Text("Relaxed puzzles with no timer, no move limit and no stars. Pick a board size.", color = c.textDim, fontSize = 14.sp, lineHeight = 20.sp)
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(50)).background(c.bgBottom.copy(alpha = 0.8f)).border(1.dp, c.border, RoundedCornerShape(50)).padding(4.dp)) {
                    ZenSize.values().forEach { size ->
                        val sel = size.name == zenSize
                        val a by animateFloatAsState(if (sel) 1f else 0f, tween(260), label = "seg")
                        Box(
                            Modifier.weight(1f).heightIn(min = 44.dp)
                                .gamePress(role = Role.RadioButton, label = "${size.label} board") { zenSize = size.name }
                                .clip(RoundedCornerShape(50))
                                .background(Brush.horizontalGradient(listOf(c.accent.copy(alpha = a), c.accent2.copy(alpha = a)))),
                            contentAlignment = Alignment.Center
                        ) { Text("${size.label}\n${size.w}×${size.h}", color = androidx.compose.ui.graphics.lerp(c.textDim, Color.White, a), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    }
                }
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlineButton("Cancel", { dialog = "" }, Modifier.weight(1f))
                    PrimaryButton("Start", { dialog = ""; vm.startZen(ZenSize.valueOf(zenSize)); onPlay() }, Modifier.weight(1f))
                }
            }
        }
        "rush" -> Dialog(onDismissRequest = { dialog = "" }) {
            LoopCard(Modifier.fillMaxWidth().popIn()) {
                Text("Rush", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(8.dp))
                Text(
                    "You get ${ModeRules.RUSH_START_MS / 1000} seconds. Every solved puzzle adds ${ModeRules.RUSH_BONUS_MS / 1000} seconds, " +
                        "and the puzzles get harder as you go. No hints. The clock stops while you pause or leave the app.",
                    color = c.textDim, fontSize = 14.sp, lineHeight = 20.sp
                )
                Spacer(Modifier.height(8.dp))
                Text(if (p.rushRuns == 0) "Set your first record!" else "Your best: ${p.rushBest}", color = c.gold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlineButton("Cancel", { dialog = "" }, Modifier.weight(1f))
                    PrimaryButton("Go!", { dialog = ""; vm.startRush(); onPlay() }, Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun ModeCard(
    mode: GameMode, icon: ImageVector, tint: Color, status: String,
    unlocked: Boolean, lockText: String?, onClick: () -> Unit
) {
    val c = LocalLoop.current
    LoopCard(
        Modifier.fillMaxWidth().staggerIn(mode.ordinal).alpha(if (unlocked) 1f else 0.55f)
            .gamePress(enabled = unlocked, label = if (unlocked) "Play ${mode.title}" else "${mode.title}, locked", onClick = onClick)
            .semantics { contentDescription = "${mode.title}. ${mode.tagline}. ${if (unlocked) status else lockText ?: ""}" }
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(60.dp).clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.4f), tint.copy(alpha = 0.12f))))
                    .border(1.5.dp, tint.copy(alpha = 0.7f), CircleShape),
                contentAlignment = Alignment.Center
            ) { Icon(if (unlocked) icon else Icons.Rounded.Lock, null, tint = tint, modifier = Modifier.size(30.dp)) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(mode.title, color = c.text, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                Text(mode.tagline, color = c.textDim, fontSize = 12.sp, lineHeight = 16.sp)
                Spacer(Modifier.height(4.dp))
                Text(if (unlocked) status else lockText ?: "", color = if (unlocked) tint else c.textDim, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
