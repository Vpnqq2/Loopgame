package com.loopconnect.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.loopconnect.data.AnimationMode
import com.loopconnect.data.ThemeId
import com.loopconnect.ui.*

@Composable
fun SettingsScreen(vm: GameViewModel, onBack: () -> Unit) {
    val c = LocalLoop.current
    val s by vm.settings.collectAsStateWithLifecycle()
    var dialog by rememberSaveable { mutableStateOf("") } // "", reset, privacy, about

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("Settings", null, onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            LoopCard(Modifier.fillMaxWidth()) {
                ToggleRow("Sound effects", s.sound) { vm.setSound(it) }
                ToggleRow("Music", s.music) { vm.setMusic(it) }
                ToggleRow("Haptic feedback", s.haptics) { vm.setHaptics(it) }
            }
            SectionTitle("Appearance")
            LoopCard(Modifier.fillMaxWidth()) {
                Text("Theme", color = c.text, fontSize = 15.sp)
                Spacer(Modifier.height(8.dp))
                Segments(ThemeId.values().map { it.label }, ThemeId.values().indexOf(s.theme)) { vm.setTheme(ThemeId.values()[it]) }
                Spacer(Modifier.height(14.dp))
                Text("Animation", color = c.text, fontSize = 15.sp)
                Spacer(Modifier.height(8.dp))
                Segments(AnimationMode.values().map { it.label }, AnimationMode.values().indexOf(s.animation)) { vm.setAnimation(AnimationMode.values()[it]) }
            }
            SectionTitle("Game")
            LoopCard(Modifier.fillMaxWidth()) {
                LinkRow("Reset Progress") { dialog = "reset" }
                LinkRow("Privacy Policy") { dialog = "privacy" }
                LinkRow("About") { dialog = "about" }
            }
            Spacer(Modifier.height(12.dp))
        }
    }

    when (dialog) {
        "reset" -> InfoDialog(
            "Reset progress?",
            "This permanently deletes your completed levels, statistics, daily streak and the saved game. Settings are kept.",
            confirm = "Reset", onConfirm = { vm.resetProgress(); dialog = "" }, onDismiss = { dialog = "" }
        )
        "privacy" -> InfoDialog(
            "Privacy",
            "Loop Connect works entirely offline. It has no accounts, no ads, no analytics and requests no permissions. Your progress and settings are stored only on this device and are removed when you uninstall the app.",
            confirm = null, onConfirm = {}, onDismiss = { dialog = "" }
        )
        "about" -> InfoDialog(
            "Loop Connect 1.0",
            "An original puzzle game. Every level is generated on your device from a verified solution, so levels never run out.",
            confirm = null, onConfirm = {}, onDismiss = { dialog = "" }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = LocalLoop.current.textDim, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp, top = 6.dp))
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalLoop.current
    Row(
        Modifier.fillMaxWidth().heightIn(min = 52.dp).clickable(role = Role.Switch) { onChange(!checked) },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = c.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked, onCheckedChange = null,
            colors = SwitchDefaults.colors(checkedTrackColor = c.accent, checkedThumbColor = Color.White)
        )
    }
}

@Composable
private fun LinkRow(label: String, onClick: () -> Unit) {
    val c = LocalLoop.current
    Row(Modifier.fillMaxWidth().heightIn(min = 52.dp).clickable(role = Role.Button, onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = c.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
        Text("›", color = c.textDim, fontSize = 20.sp)
    }
}

@Composable
private fun Segments(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val c = LocalLoop.current
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.bgBottom).padding(3.dp)) {
        labels.forEachIndexed { i, l ->
            Box(
                Modifier.weight(1f).heightIn(min = 44.dp).clip(RoundedCornerShape(10.dp))
                    .background(if (i == selected) c.accent else Color.Transparent)
                    .clickable(role = Role.RadioButton, onClickLabel = l) { onSelect(i) },
                contentAlignment = Alignment.Center
            ) { Text(l, color = if (i == selected) Color.White else c.textDim, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
        }
    }
}

@Composable
private fun InfoDialog(title: String, body: String, confirm: String?, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val c = LocalLoop.current
    Dialog(onDismissRequest = onDismiss) {
        LoopCard(Modifier.fillMaxWidth()) {
            Text(title, color = c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Text(body, color = c.textDim, fontSize = 14.sp, lineHeight = 20.sp)
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlineButton(if (confirm == null) "Close" else "Cancel", onDismiss, Modifier.weight(1f))
                if (confirm != null) PrimaryButton(confirm, onConfirm, Modifier.weight(1f))
            }
        }
    }
}
