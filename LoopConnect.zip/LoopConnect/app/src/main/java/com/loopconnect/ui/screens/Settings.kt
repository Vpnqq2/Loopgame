package com.loopconnect.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Animation
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PrivacyTip
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.loopconnect.data.AnimationMode
import com.loopconnect.data.ThemeId
import com.loopconnect.ui.*

@Composable
fun SettingsScreen(vm: GameViewModel, onBack: () -> Unit) {
    val c = LocalLoop.current
    val s by vm.settings.collectAsStateWithLifecycle()
    var dialog by rememberSaveable { mutableStateOf("") } // "", reset, privacy, about
    val ctx = LocalContext.current
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> vm.setNotifications(granted) }
    fun toggleNotifications(on: Boolean) {
        val needsAsk = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (on && needsAsk) permission.launch(Manifest.permission.POST_NOTIFICATIONS) else vm.setNotifications(on)
    }

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("SETTINGS", null, onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionTitle("AUDIO & FEEL")
            LoopCard(Modifier.fillMaxWidth()) {
                ToggleRow(Icons.Rounded.GraphicEq, c.accent, "Sound effects", s.sound) { vm.setSound(it) }
                ToggleRow(Icons.Rounded.MusicNote, c.accent2, "Music", s.music) { vm.setMusic(it) }
                ToggleRow(Icons.Rounded.Vibration, c.gold, "Haptic feedback", s.haptics) { vm.setHaptics(it) }
            }
            SectionTitle("NOTIFICATIONS & DATA")
            LoopCard(Modifier.fillMaxWidth()) {
                ToggleRow(Icons.Rounded.Notifications, c.gold, "Notifications", s.notifications) { toggleNotifications(it) }
                ToggleRow(Icons.Rounded.BarChart, c.good, "Share usage & crash data", s.analytics) { vm.setAnalytics(it) }
            }
            SectionTitle("APPEARANCE")
            LoopCard(Modifier.fillMaxWidth()) {
                RowTitle(Icons.Rounded.Palette, c.accent2, "Theme")
                Spacer(Modifier.height(10.dp))
                Segments(ThemeId.values().map { it.label }, ThemeId.values().indexOf(s.theme)) { vm.setTheme(ThemeId.values()[it]) }
                Spacer(Modifier.height(16.dp))
                RowTitle(Icons.Rounded.Animation, c.accent, "Animation")
                Spacer(Modifier.height(10.dp))
                Segments(AnimationMode.values().map { it.label }, AnimationMode.values().indexOf(s.animation)) { vm.setAnimation(AnimationMode.values()[it]) }
            }
            SectionTitle("GAME")
            LoopCard(Modifier.fillMaxWidth()) {
                LinkRow(Icons.Rounded.RestartAlt, c.bad, "Reset Progress") { dialog = "reset" }
                LinkRow(Icons.Rounded.PrivacyTip, c.good, "Privacy Policy") { dialog = "privacy" }
                LinkRow(Icons.Rounded.Info, c.accent, "About") { dialog = "about" }
            }
            Spacer(Modifier.height(16.dp))
        }
    }

    when (dialog) {
        "reset" -> InfoDialog(
            "Reset progress?",
            "This permanently deletes your completed levels, statistics, daily streak and the saved game. Settings are kept.",
            confirm = "Reset", onConfirm = { vm.resetProgress(); dialog = "" }, onDismiss = { dialog = "" }
        )
        "privacy" -> InfoDialog(
            "Privacy",
            "The game works fully offline and has no accounts. Progress and settings stay on this device. With your permission it uses Firebase for anonymous usage statistics and crash reports (switch off under Share usage & crash data) and for optional notifications (off until you enable them). The only ads come from Google AdMob: optional rewarded videos you request for a hint (limited per day), and an occasional full-screen ad between levels after your first levels. Loading ads uses the internet, and Google may process your advertising ID and device data under your consent choices.",
            confirm = null, onConfirm = {}, onDismiss = { dialog = "" }
        )
        "about" -> InfoDialog(
            "Loop Connect 1.0",
            "An original puzzle game. Every level is generated on your device from a verified solution, so levels never run out.",
            confirm = null, onConfirm = {}, onDismiss = { dialog = "" }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = LocalLoop.current.textDim, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp,
        modifier = Modifier.padding(start = 6.dp, top = 8.dp))
}

@Composable
private fun IconBadge(icon: ImageVector, tint: Color) {
    Box(
        Modifier.size(38.dp).clip(RoundedCornerShape(12.dp))
            .background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.35f), tint.copy(alpha = 0.12f)))),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp)) }
}

@Composable
private fun RowTitle(icon: ImageVector, tint: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconBadge(icon, tint)
        Spacer(Modifier.width(12.dp))
        Text(label, color = LocalLoop.current.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun GameToggle(checked: Boolean) {
    val c = LocalLoop.current
    val knob by animateDpAsState(if (checked) 22.dp else 2.dp, spring(dampingRatio = 0.6f, stiffness = 600f), label = "knob")
    Box(
        Modifier.size(width = 52.dp, height = 30.dp).clip(CircleShape)
            .background(if (checked) Brush.horizontalGradient(listOf(c.accent, c.accent2)) else Brush.horizontalGradient(listOf(c.border, c.border)))
            .border(1.dp, Color.White.copy(alpha = 0.2f), CircleShape)
    ) {
        Box(Modifier.offset(x = knob, y = 3.dp).size(24.dp).clip(CircleShape).background(Color.White))
    }
}

@Composable
private fun ToggleRow(icon: ImageVector, tint: Color, label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalLoop.current
    Row(
        Modifier.fillMaxWidth().heightIn(min = 56.dp)
            .gamePress(role = Role.Switch, label = label) { onChange(!checked) }
            .semantics { contentDescription = "$label, ${if (checked) "on" else "off"}" },
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBadge(icon, tint)
        Spacer(Modifier.width(12.dp))
        Text(label, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        GameToggle(checked)
    }
}

@Composable
private fun LinkRow(icon: ImageVector, tint: Color, label: String, onClick: () -> Unit) {
    val c = LocalLoop.current
    Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).gamePress(label = label, onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        IconBadge(icon, tint)
        Spacer(Modifier.width(12.dp))
        Text(label, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = c.textDim)
    }
}

@Composable
private fun Segments(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val c = LocalLoop.current
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(50)).background(c.bgBottom.copy(alpha = 0.8f)).border(1.dp, c.border, RoundedCornerShape(50)).padding(4.dp)) {
        labels.forEachIndexed { i, l ->
            val sel = i == selected
            Box(
                Modifier.weight(1f).heightIn(min = 42.dp)
                    .gamePress(role = Role.RadioButton, label = l) { onSelect(i) }
                    .clip(RoundedCornerShape(50))
                    .background(if (sel) Brush.horizontalGradient(listOf(c.accent, lerp2(c.accent, c.accent2))) else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))),
                contentAlignment = Alignment.Center
            ) { Text(l, color = if (sel) Color.White else c.textDim, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

private fun lerp2(a: Color, b: Color): Color = androidx.compose.ui.graphics.lerp(a, b, 0.55f)

@Composable
private fun InfoDialog(title: String, body: String, confirm: String?, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val c = LocalLoop.current
    Dialog(onDismissRequest = onDismiss) {
        LoopCard(Modifier.fillMaxWidth()) {
            Text(title, color = c.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(10.dp))
            Text(body, color = c.textDim, fontSize = 14.sp, lineHeight = 20.sp)
            Spacer(Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlineButton(if (confirm == null) "Close" else "Cancel", onDismiss, Modifier.weight(1f))
                if (confirm != null) PrimaryButton(confirm, onConfirm, Modifier.weight(1f))
            }
        }
    }
}
