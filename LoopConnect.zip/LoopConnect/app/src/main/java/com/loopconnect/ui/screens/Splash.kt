package com.loopconnect.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.loopconnect.ui.LocalAnimations
import com.loopconnect.ui.LocalLoop
import kotlinx.coroutines.delay
import java.util.concurrent.atomic.AtomicBoolean

private fun easeOutBackS(x: Float): Float {
    val c1 = 1.70158f
    val c3 = c1 + 1f
    val t = x - 1f
    return 1f + c3 * t * t * t + c1 * t * t
}

/** Animated launch screen: the logo's lines draw themselves, nodes pop in, then the title appears. */
@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val c = LocalLoop.current
    val animate = LocalAnimations.current
    val draw = remember { Animatable(if (animate) 0f else 1f) }
    val title = remember { Animatable(if (animate) 0f else 1f) }
    val finish by rememberUpdatedState(onFinished)
    val once = remember { AtomicBoolean(false) }
    fun finishOnce() { if (once.compareAndSet(false, true)) finish() }

    LaunchedEffect(Unit) {
        if (animate) {
            draw.animateTo(1f, tween(1300, easing = FastOutSlowInEasing))
            title.animateTo(1f, tween(600))
            delay(500)
        } else delay(250)
        finishOnce()
    }

    Box(
        Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { finishOnce() },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(260.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val r = size.width / 2f
                    val glow = 0.15f + 0.4f * draw.value
                    drawCircle(Brush.radialGradient(listOf(c.accent.copy(alpha = glow), c.accent2.copy(alpha = glow * 0.4f), Color.Transparent), center, r), r)
                }
                Canvas(Modifier.size(190.dp).semantics { contentDescription = "Loop Connect" }) { drawLogo(draw.value, c.accent, c.accent2, c.gold) }
            }
            Spacer(Modifier.height(8.dp))
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.graphicsLayer { alpha = title.value; translationY = (1f - title.value) * 24f }
            ) {
                Text(
                    "LOOP CONNECT",
                    style = TextStyle(
                        brush = Brush.horizontalGradient(listOf(c.accent, c.text, c.accent2)),
                        fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp
                    )
                )
                Spacer(Modifier.height(6.dp))
                Text("Rotate  ·  Connect  ·  Solve", color = c.textDim, fontSize = 14.sp, letterSpacing = 1.sp)
            }
        }
        Box(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 56.dp).width(140.dp).height(4.dp)
                .clip(RoundedCornerShape(2.dp)).background(c.border.copy(alpha = 0.6f))
        ) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(draw.value).background(Brush.horizontalGradient(listOf(c.accent, c.accent2))))
        }
    }
}

private fun DrawScope.drawLogo(progress: Float, accent: Color, accent2: Color, gold: Color) {
    val s = size.width / 108f
    val r = 24f * s
    val frameA = (progress * 3f).coerceIn(0f, 1f)
    drawRoundRect(Color(0xFF0A1022), cornerRadius = CornerRadius(r, r), alpha = frameA)
    drawRoundRect(Brush.linearGradient(listOf(accent, accent2, gold)), cornerRadius = CornerRadius(r, r), alpha = frameA, style = Stroke(3f * s))

    fun build(b: Path.() -> Unit) = Path().apply(b)
    val blue = Color(0xFF3DA5FF)
    val violet = Color(0xFFB06CFF)
    val yellow = Color(0xFFFFC93D)
    val pink = Color(0xFFFF6FA8)
    val lines = listOf(
        blue to build { moveTo(36 * s, 34 * s); lineTo(36 * s, 50 * s); quadraticBezierTo(36 * s, 56 * s, 42 * s, 56 * s); lineTo(54 * s, 56 * s) },
        violet to build { moveTo(54 * s, 56 * s); lineTo(54 * s, 42 * s); quadraticBezierTo(54 * s, 36 * s, 60 * s, 36 * s); lineTo(66 * s, 36 * s); quadraticBezierTo(72 * s, 36 * s, 72 * s, 42 * s); lineTo(72 * s, 48 * s) },
        yellow to build { moveTo(54 * s, 56 * s); lineTo(54 * s, 70 * s); quadraticBezierTo(54 * s, 76 * s, 60 * s, 76 * s); lineTo(72 * s, 76 * s) }
    )
    val fractions = FloatArray(3)
    lines.forEachIndexed { i, (color, path) ->
        val f = ((progress - 0.15f) * 1.7f - i * 0.25f).coerceIn(0f, 1f)
        fractions[i] = f
        if (f <= 0f) return@forEachIndexed
        val pm = PathMeasure()
        pm.setPath(path, false)
        val part = Path()
        pm.getSegment(0f, pm.length * f, part, true)
        drawPath(part, color.copy(alpha = 0.25f), style = Stroke(12f * s, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawPath(part, color, style = Stroke(6f * s, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
    fun node(color: Color, at: Offset, f: Float) {
        if (f <= 0f) return
        drawCircle(color.copy(alpha = 0.3f), 11f * s * easeOutBackS(f), at)
        drawCircle(color, 6f * s * easeOutBackS(f), at)
    }
    node(blue, Offset(36 * s, 34 * s), (fractions[0] * 8f).coerceIn(0f, 1f))
    node(pink, Offset(72 * s, 48 * s), ((fractions[1] - 0.85f) / 0.15f).coerceIn(0f, 1f))
    node(yellow, Offset(72 * s, 76 * s), ((fractions[2] - 0.85f) / 0.15f).coerceIn(0f, 1f))
}
