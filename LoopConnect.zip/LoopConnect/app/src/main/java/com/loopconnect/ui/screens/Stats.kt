package com.loopconnect.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.loopconnect.engine.Achievements
import com.loopconnect.ui.*
import java.text.NumberFormat

@Composable
fun StatsScreen(vm: GameViewModel, onBack: () -> Unit) {
    val c = LocalLoop.current
    val p by vm.progress.collectAsStateWithLifecycle()
    val nf = NumberFormat.getInstance()
    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("Statistics", null, onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Levels Completed", nf.format(p.levelsCompleted), Modifier.weight(1f))
                StatCard("Total Puzzles Solved", nf.format(p.totalSolved), Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Total Moves", nf.format(p.totalMoves), Modifier.weight(1f))
                StatCard("Best Performance", if (p.perfectLevels == 0) "—" else "${p.perfectLevels} perfect", Modifier.weight(1f))
            }
            val streak = p.streakOn(vm.today())
            StatCard("Daily Streak", "$streak day${if (streak == 1) "" else "s"}", Modifier.fillMaxWidth())

            Text("Achievements", color = c.text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
            Achievements.all.forEach { a ->
                val v = a.value(p).coerceAtMost(a.goal)
                val done = a.unlocked(p)
                LoopCard(Modifier.fillMaxWidth().semantics { contentDescription = "${a.title}, ${a.description}, ${if (done) "unlocked" else "locked, $v of ${a.goal}"}" }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.EmojiEvents, null, tint = if (done) c.gold else c.border, modifier = Modifier.size(34.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(a.title, color = c.text, fontWeight = FontWeight.SemiBold)
                            Text(a.description, color = c.textDim, fontSize = 12.sp)
                            if (!done) {
                                Spacer(Modifier.height(6.dp))
                                Box(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(c.border)) {
                                    Box(Modifier.fillMaxWidth(v.toFloat() / a.goal).fillMaxHeight().background(c.accent))
                                }
                            }
                        }
                        Spacer(Modifier.width(10.dp))
                        if (done) Icon(Icons.Rounded.Check, "Unlocked", tint = c.good)
                        else Icon(Icons.Rounded.Lock, "Locked", tint = c.textDim)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier) {
    val c = LocalLoop.current
    LoopCard(modifier.semantics(mergeDescendants = true) {}) {
        Text(label, color = c.textDim, fontSize = 12.sp)
        Spacer(Modifier.height(4.dp))
        Text(value, color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    }
}
