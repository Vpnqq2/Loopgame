package com.loopconnect.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.loopconnect.engine.Achievements
import com.loopconnect.ui.*
import java.text.NumberFormat

@Composable
fun StatsScreen(vm: GameViewModel, onBack: () -> Unit) {
    val c = LocalLoop.current
    val p by vm.progress.collectAsStateWithLifecycle()
    val nf = NumberFormat.getInstance()
    val streak = p.streakOn(vm.today())
    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("STATISTICS", null, onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Levels Completed", nf.format(p.levelsCompleted), Icons.Rounded.Flag, c.accent, Modifier.weight(1f))
                StatCard("Puzzles Solved", nf.format(p.totalSolved), Icons.Rounded.GridView, c.accent2, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Total Moves", nf.format(p.totalMoves), Icons.Rounded.TouchApp, c.good, Modifier.weight(1f))
                StatCard("Best Performance", if (p.perfectLevels == 0) "—" else "${p.perfectLevels} perfect", Icons.Rounded.Star, c.gold, Modifier.weight(1f))
            }
            StatCard("Daily Streak", "$streak day${if (streak == 1) "" else "s"}", Icons.Rounded.LocalFireDepartment, Color(0xFFFF8A4D), Modifier.fillMaxWidth())

            Text("ACHIEVEMENTS", color = c.textDim, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, modifier = Modifier.padding(start = 6.dp, top = 8.dp))
            Achievements.all.forEach { a ->
                val v = a.value(p).coerceAtMost(a.goal)
                val done = a.unlocked(p)
                LoopCard(Modifier.fillMaxWidth().semantics { contentDescription = "${a.title}, ${a.description}, ${if (done) "unlocked" else "locked, $v of ${a.goal}"}" }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(52.dp).clip(CircleShape)
                                .background(if (done) Brush.verticalGradient(listOf(c.gold, Color(0xFFFF9A3D))) else Brush.verticalGradient(listOf(c.surfaceHi, c.surface)))
                                .border(2.dp, if (done) Color.White.copy(alpha = 0.6f) else c.border, CircleShape),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Rounded.EmojiEvents, null, tint = if (done) Color(0xFF2A1900) else c.textDim, modifier = Modifier.size(28.dp)) }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(a.title, color = c.text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(a.description, color = c.textDim, fontSize = 12.sp)
                            if (!done) {
                                Spacer(Modifier.height(8.dp))
                                Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(c.bgBottom)) {
                                    Box(
                                        Modifier.fillMaxWidth(v.toFloat() / a.goal).fillMaxHeight().clip(RoundedCornerShape(4.dp))
                                            .background(Brush.horizontalGradient(listOf(c.accent, c.accent2)))
                                    )
                                }
                                Text("$v / ${a.goal}", color = c.textDim, fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp))
                            }
                        }
                        Spacer(Modifier.width(10.dp))
                        if (done) Icon(Icons.Rounded.Check, "Unlocked", tint = c.good) else Icon(Icons.Rounded.Lock, "Locked", tint = c.textDim)
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, icon: ImageVector, tint: Color, modifier: Modifier) {
    val c = LocalLoop.current
    LoopCard(modifier.semantics(mergeDescendants = true) {}) {
        Box(
            Modifier.size(34.dp).clip(RoundedCornerShape(11.dp))
                .background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.35f), tint.copy(alpha = 0.1f)))),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.height(10.dp))
        Text(value, color = c.text, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        Text(label, color = c.textDim, fontSize = 12.sp)
    }
}
