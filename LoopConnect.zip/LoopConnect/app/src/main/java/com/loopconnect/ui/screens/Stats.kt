package com.loopconnect.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Spa
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.loopconnect.engine.Achievements
import com.loopconnect.ui.*
import java.text.NumberFormat

@Composable
fun StatsScreen(vm: GameViewModel, onBack: () -> Unit, onAwards: () -> Unit) {
    val c = LocalLoop.current
    val p by vm.progress.collectAsStateWithLifecycle()
    val nf = NumberFormat.getInstance()
    val streak = p.streakOn(vm.today())
    val stars = p.results.values.sumOf { it.stars }
    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("STATISTICS", null, onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.staggerIn(0), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Levels Completed", nf.format(p.levelsCompleted), Icons.Rounded.Flag, c.accent, Modifier.weight(1f))
                StatCard("Puzzles Solved", nf.format(p.totalSolved), Icons.Rounded.GridView, c.accent2, Modifier.weight(1f))
            }
            Row(Modifier.staggerIn(1), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Total Moves", nf.format(p.totalMoves), Icons.Rounded.TouchApp, c.good, Modifier.weight(1f))
                StatCard("Total Stars", nf.format(stars), Icons.Rounded.Star, c.gold, Modifier.weight(1f))
            }
            Row(Modifier.staggerIn(2), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Perfect Levels", if (p.perfectLevels == 0) "—" else nf.format(p.perfectLevels), Icons.Rounded.EmojiEvents, c.gold, Modifier.weight(1f))
                StatCard("Hints Left", "${p.hints}", Icons.Rounded.Lightbulb, c.accent, Modifier.weight(1f))
            }
            Row(Modifier.staggerIn(3), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Best Rush", if (p.rushBest == 0) "—" else nf.format(p.rushBest), Icons.Rounded.Timer, c.gold, Modifier.weight(1f))
                StatCard("Challenges Cleared", nf.format(p.challengeCleared), Icons.Rounded.Bolt, c.accent2, Modifier.weight(1f))
            }
            Row(Modifier.staggerIn(4), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatCard("Zen Puzzles", nf.format(p.zenSolved), Icons.Rounded.Spa, c.good, Modifier.weight(1f))
                StatCard("Rush Runs", nf.format(p.rushRuns), Icons.Rounded.Timer, c.accent, Modifier.weight(1f))
            }
            StatCard("Daily Streak", "$streak day${if (streak == 1) "" else "s"}", Icons.Rounded.LocalFireDepartment, Color(0xFFFF8A4D), Modifier.fillMaxWidth().staggerIn(5))

            // Entry point to the separate Awards page
            LoopCard(Modifier.fillMaxWidth().staggerIn(6).gamePress(label = "Open awards", onClick = onAwards)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.EmojiEvents, null, tint = c.gold, modifier = Modifier.size(32.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Awards", color = c.text, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text("${Achievements.unlockedCount(p)} of ${Achievements.all.size} unlocked", color = c.textDim, fontSize = 12.sp)
                    }
                    Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = c.textDim)
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, icon: ImageVector, tint: Color, modifier: Modifier) {
    val c = LocalLoop.current
    LoopCard(modifier.semantics(mergeDescendants = true) {}) {
        Box(
            Modifier.size(34.dp).clip(RoundedCornerShape(11.dp))
                .background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.35f), tint.copy(alpha = 0.1f)))),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.height(10.dp))
        Text(value, color = c.text, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        Text(label, color = c.textDim, fontSize = 12.sp)
    }
}
