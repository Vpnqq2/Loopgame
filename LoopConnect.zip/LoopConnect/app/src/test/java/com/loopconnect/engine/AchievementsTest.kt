package com.loopconnect.engine

import org.junit.Assert.*
import org.junit.Test

class AchievementsTest {
    private fun completed(n: Int): Progress {
        var p = Progress()
        for (i in 1..n) p = p.withLevelCompleted(i, 10, 1)
        return p
    }

    @Test fun idsAreUniqueAndAllStartLocked() {
        assertEquals(Achievements.all.size, Achievements.all.map { it.id }.toSet().size)
        val fresh = Progress()
        assertTrue(Achievements.all.none { it.unlocked(fresh) })
        assertTrue(Achievements.newlyUnlocked(fresh).isEmpty())
    }

    @Test fun reachingGoalReportsNewUnlockOnlyOnce() {
        val p = completed(5)
        val newly = Achievements.newlyUnlocked(p).map { it.id }.toSet()
        assertEquals(setOf("first_win", "first"), newly)
        val after = p.withUnlocked(Achievements.newlyUnlocked(p))
        assertTrue(Achievements.newlyUnlocked(after).isEmpty())
    }

    @Test fun unlockPaysTierRewardAndRespectsCap() {
        val p = completed(5)
        val before = p.hints
        val after = p.withUnlocked(Achievements.newlyUnlocked(p)) // two bronze awards
        assertEquals(minOf(MAX_HINTS, before + 2), after.hints)
        val full = Progress().copy(hints = MAX_HINTS)
        assertEquals(MAX_HINTS, full.withUnlocked(Achievements.all.take(3)).hints)
    }

    @Test fun unlockedAwardsStayUnlockedAfterStreakResets() {
        var p = Progress()
        for (d in 100L..102L) p = p.withDailyCompleted(d)
        p = p.withUnlocked(Achievements.newlyUnlocked(p))
        val streak3 = Achievements.all.first { it.id == "streak3" }
        assertTrue(streak3.unlocked(p))
        p = p.withDailyCompleted(200) // streak restarts at 1
        assertEquals(1, p.dailyStreak)
        assertTrue(streak3.unlocked(p))
    }

    @Test fun progressValuesAreClampedForDisplay() {
        val a = Achievements.all.first { it.id == "first" }
        assertEquals(5, a.current(completed(12)))
        assertEquals(0, a.current(Progress()))
    }
}
