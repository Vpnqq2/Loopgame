package com.loopconnect.engine

import org.junit.Assert.*
import org.junit.Test

class AdPolicyTest {
    private val day = 20000L
    private val t0 = 1_000_000_000L
    private val min = 60_000L

    @Test fun rewardedHasDailyLimitAndCooldown() {
        var s = AdState()
        assertEquals(RewardedStatus.Available(3), AdPolicy.rewardedStatus(s, day, t0))
        s = s.rewardedEarned(t0, day)
        val cd = AdPolicy.rewardedStatus(s, day, t0 + min) as RewardedStatus.Cooldown
        assertEquals(AdPolicy.REWARDED_COOLDOWN_MS - min, cd.msLeft)
        assertEquals(RewardedStatus.Available(2), AdPolicy.rewardedStatus(s, day, t0 + 6 * min))
        s = s.rewardedEarned(t0 + 6 * min, day).rewardedEarned(t0 + 12 * min, day)
        assertEquals(RewardedStatus.DailyLimit, AdPolicy.rewardedStatus(s, day, t0 + 60 * min))
    }

    @Test fun dailyLimitResetsNextDay() {
        var s = AdState()
        repeat(3) { s = s.rewardedEarned(t0 + it * 10 * min, day) }
        assertEquals(RewardedStatus.DailyLimit, AdPolicy.rewardedStatus(s, day, t0 + 100 * min))
        assertTrue(AdPolicy.rewardedStatus(s, day + 1, t0 + 24 * 60 * min) is RewardedStatus.Available)
    }

    @Test fun movingTheClockBackDoesNotSkipTheCooldown() {
        val s = AdState().rewardedEarned(t0, day)
        assertTrue(AdPolicy.rewardedStatus(s, day, t0 - 10 * min) is RewardedStatus.Cooldown)
    }

    @Test fun interstitialNeverForNewPlayers() {
        val s = AdState(levelsSinceInterstitial = 10)
        assertFalse(AdPolicy.canShowInterstitial(s, day, t0, AdPolicy.FREE_LEVELS - 1))
        assertTrue(AdPolicy.canShowInterstitial(s, day, t0, AdPolicy.FREE_LEVELS))
    }

    @Test fun interstitialOnlyEveryFewLevelsAndResetsAfterShowing() {
        var s = AdState()
        repeat(AdPolicy.INTERSTITIAL_EVERY_LEVELS - 1) { s = s.levelCompleted() }
        assertFalse(AdPolicy.canShowInterstitial(s, day, t0, 20))
        s = s.levelCompleted()
        assertTrue(AdPolicy.canShowInterstitial(s, day, t0, 20))
        s = s.interstitialShown(t0, day)
        assertEquals(0, s.levelsSinceInterstitial)
        repeat(AdPolicy.INTERSTITIAL_EVERY_LEVELS) { s = s.levelCompleted() }
        // enough levels, but the minimum gap has not passed
        assertFalse(AdPolicy.canShowInterstitial(s, day, t0 + min, 20))
        assertTrue(AdPolicy.canShowInterstitial(s, day, t0 + AdPolicy.INTERSTITIAL_GAP_MS, 20))
    }

    @Test fun interstitialHasDailyCapAndWaitsAfterRewarded() {
        var s = AdState(levelsSinceInterstitial = 99)
        repeat(AdPolicy.INTERSTITIAL_PER_DAY) { s = s.interstitialShown(t0 + it * 10 * min, day).copy(levelsSinceInterstitial = 99) }
        assertFalse(AdPolicy.canShowInterstitial(s, day, t0 + 500 * min, 50))
        assertTrue(AdPolicy.canShowInterstitial(s, day + 1, t0 + 24 * 60 * min, 50))
        val r = AdState(levelsSinceInterstitial = 99).rewardedEarned(t0, day)
        assertFalse(AdPolicy.canShowInterstitial(r, day, t0 + min, 50))
    }

    @Test fun preloadOnlyOneLevelAhead() {
        val s = AdState(levelsSinceInterstitial = AdPolicy.INTERSTITIAL_EVERY_LEVELS - 2)
        assertFalse(AdPolicy.shouldPreloadInterstitial(s, day, 20))
        assertTrue(AdPolicy.shouldPreloadInterstitial(s.levelCompleted(), day, 20))
        assertFalse(AdPolicy.shouldPreloadInterstitial(s.levelCompleted(), day, 2))
    }

    @Test fun stateRoundTripsAndCorruptDataIsSafe() {
        val s = AdState(day, 2, 1, 123L, 456L, 3)
        assertEquals(s, AdState.decode(s.encode()))
        assertEquals(AdState(), AdState.decode("junk"))
        assertEquals(AdState(), AdState.decode(null))
    }
}
