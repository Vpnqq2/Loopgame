package com.loopconnect.engine

import org.junit.Assert.*
import org.junit.Test

class BoardAndSaveTest {
    private fun board(n: Int = 12) = PuzzleBoard(LevelGenerator.forLevel(n))

    @Test fun rotateUndoRestart() {
        val b = board()
        val start = b.masksCopy()
        val i = (0 until b.level.size).first { Tile.rotateCw(b.mask(it)) != b.mask(it) }
        assertTrue(b.rotate(i))
        assertEquals(1, b.moves)
        assertEquals(Tile.rotateCw(start[i]), b.mask(i))
        assertEquals(i, b.undo())
        assertArrayEquals(start, b.masksCopy())
        assertEquals(0, b.moves)
        b.rotate(i); b.rotate(i)
        b.restart()
        assertArrayEquals(start, b.masksCopy())
        assertEquals(0, b.moves)
        assertNull(b.undo())
    }

    @Test fun hintsLeadToCompletion() {
        val b = board(25)
        var guard = 0
        while (!b.isSolved() && guard++ < 1000) {
            val h = b.hint()!!
            assertTrue(h.taps in 1..3)
            repeat(h.taps) { b.rotate(h.tile) }
        }
        assertTrue(b.isSolved())
        assertNull(b.hint())
    }

    @Test fun symmetricAndEmptyTilesIgnoreTaps() {
        val level = LevelGenerator.forLevel(60)
        val b = PuzzleBoard(level)
        val sym = (0 until level.size).firstOrNull { b.mask(it) == 0 || b.mask(it) == 15 }
        if (sym != null) { assertFalse(b.rotate(sym)); assertEquals(0, b.moves) }
    }

    @Test fun saveRoundTripRestoresBoardAndMoves() {
        val b = board(18)
        val i = (0 until b.level.size).first { Tile.rotateCw(b.mask(it)) != b.mask(it) }
        b.rotate(i); b.rotate(i)
        val text = SaveCodec.encode(SaveCodec.snapshot(b, null))
        val restored = SaveCodec.restore(SaveCodec.decode(text)!!)!!
        assertArrayEquals(b.masksCopy(), restored.masksCopy())
        assertEquals(b.moves, restored.moves)
        assertEquals(b.level.spec, restored.level.spec)
        restored.undo(); restored.undo()
        assertArrayEquals(b.level.initialMasks, restored.masksCopy())
    }

    @Test fun dailyFlagSurvivesSave() {
        val level = LevelGenerator.daily(21000)
        val text = SaveCodec.encode(SaveCodec.snapshot(PuzzleBoard(level), 21000))
        assertEquals(21000L, SaveCodec.decode(text)!!.dailyDay)
    }

    @Test fun corruptSavesAreRejectedGracefully() {
        assertNull(SaveCodec.decode(null))
        assertNull(SaveCodec.decode(""))
        assertNull(SaveCodec.decode("garbage"))
        assertNull(SaveCodec.decode("v1;1;3;3;9;2;750;100;5;-1;;1,2,3"))
        val good = SaveCodec.encode(SaveCodec.snapshot(board(5), null))
        val parts = good.split(";").toMutableList()
        parts[11] = parts[11].split(",").mapIndexed { i, s -> if (i == 0) "99" else s }.joinToString(",")
        assertNull(SaveCodec.decode(parts.joinToString(";")))
        // a mask that is not a rotation of the solution tile is rejected on restore
        val saved = SaveCodec.decode(good)!!
        val level = LevelGenerator.build(saved.spec)!!
        val i = level.solved.indexOfFirst { Tile.degree(it) == 2 }
        val tampered = saved.masks.copyOf().also { it[i] = 15 }
        assertNull(SaveCodec.restore(saved.copy(masks = tampered)))
    }
}
