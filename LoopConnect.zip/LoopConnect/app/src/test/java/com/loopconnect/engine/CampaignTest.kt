package com.loopconnect.engine

import org.junit.Assert.*
import org.junit.Test

class CampaignTest {
    @Test fun everyCampaignLevelIsAnOrdinaryBoard() {
        for (n in 1..200) assertEquals("level $n", LevelGenerator.specFor(n), LevelGenerator.campaignSpec(n))
    }

    @Test fun boardsGetBiggerAndBusierAsTheCampaignProgresses() {
        fun avgPieces(range: IntRange) = range.map { LevelGenerator.forLevel(it).solved.count { m -> m != 0 } }.average()
        val early = avgPieces(1..10)
        val mid = avgPieces(31..40)
        val late = avgPieces(81..90)
        assertTrue("early $early < mid $mid", early + 10 < mid)
        assertTrue("mid $mid < late $late", mid + 10 < late)
    }

    @Test fun sizeNeverShrinksFromOneBlockOfTenLevelsToTheNext() {
        var previous = 0
        for (block in 0 until 12) {
            val spec = LevelGenerator.campaignSpec(block * 10 + 1)
            assertTrue("block $block", spec.width * spec.height >= previous)
            previous = spec.width * spec.height
        }
    }

    @Test fun savesFromTheOldPictureLevelsAreDroppedInsteadOfLoaded() {
        val masks = List(16) { 0 }.joinToString(",")
        assertNull(SaveCodec.decode("v4;5;4;4;0;3;900;300;123;-1;;$masks;0;0;2"))
        assertNotNull(SaveCodec.decode("v4;5;4;4;0;3;900;300;123;-1;;$masks;0;0;-1"))
        assertNotNull(SaveCodec.decode("v3;5;4;4;0;3;900;300;123;-1;;$masks;0;0"))
    }

    @Test fun saveRoundTrip() {
        val board = PuzzleBoard(LevelGenerator.forLevel(9))
        val back = SaveCodec.decode(SaveCodec.encode(SaveCodec.snapshot(board, null)))!!
        assertEquals(board.level.spec, back.spec)
        assertNotNull(SaveCodec.restore(back))
    }
}
