package com.loopconnect.engine

import org.junit.Assert.*
import org.junit.Test

class GameModesTest {
    @Test fun challengeMoveLimitAlwaysLeavesSlack() {
        for (par in 0..80) {
            val limit = ModeRules.moveLimit(par)
            assertTrue(limit >= par + 2)
        }
        assertEquals(10 + 3, ModeRules.moveLimit(10))
    }

    @Test fun challengeLevelsAreValidAndDifferFromCampaign() {
        for (n in 1..40) {
            val level = LevelGenerator.create(LevelGenerator.challengeSpec(n))
            assertTrue("challenge $n", LevelGenerator.verify(level))
            assertTrue(ModeRules.moveLimit(level.par) > level.par)
        }
        assertNotEquals(LevelGenerator.specFor(5).seed, LevelGenerator.challengeSpec(5).seed)
    }

    @Test fun zenPuzzlesAreValidForEverySizeAndObjective() {
        for (size in ZenSize.values()) {
            for (counter in 1..6) {
                val level = LevelGenerator.create(LevelGenerator.zenSpec(size, counter, 12345L + counter))
                assertTrue("zen ${size.name} $counter", LevelGenerator.verify(level))
                assertEquals(size.w, level.width)
                assertEquals(size.h, level.height)
            }
        }
        val objectives = (1..6).map { LevelGenerator.zenSpec(ZenSize.SMALL, it, 1L).objective }.toSet()
        assertEquals(setOf(Objective.NETWORK, Objective.LOOPS), objectives)
    }

    @Test fun rushRampsUpButIsCappedAndDeterministicPerSession() {
        assertEquals(1, ModeRules.rushDifficultyLevel(1))
        assertEquals(3, ModeRules.rushDifficultyLevel(2))
        assertEquals(ModeRules.RUSH_MAX_LEVEL, ModeRules.rushDifficultyLevel(500))
        var lastArea = 0
        for (i in 1..40) {
            val spec = LevelGenerator.rushSpec(i, 99L)
            assertTrue(spec.width * spec.height >= lastArea)
            lastArea = spec.width * spec.height
            assertTrue("rush $i", LevelGenerator.verify(LevelGenerator.create(spec)))
        }
        val a = LevelGenerator.create(LevelGenerator.rushSpec(5, 7L))
        val b = LevelGenerator.create(LevelGenerator.rushSpec(5, 7L))
        assertArrayEquals(a.initialMasks, b.initialMasks)
        assertNotEquals(a.signature, LevelGenerator.create(LevelGenerator.rushSpec(5, 8L)).signature)
    }

    @Test fun saveRemembersModeAndOldSavesDefaultToClassic() {
        val level = LevelGenerator.create(LevelGenerator.zenSpec(ZenSize.SMALL, 1, 5L))
        val text = SaveCodec.encode(SaveCodec.snapshot(PuzzleBoard(level), null, false, GameMode.ZEN))
        assertEquals(GameMode.ZEN, SaveCodec.decode(text)!!.mode)
        val v2 = text.split(";").dropLast(1).toMutableList().also { it[0] = "v2" }.joinToString(";")
        assertEquals(GameMode.CLASSIC, SaveCodec.decode(v2)!!.mode)
        val bad = text.split(";").toMutableList().also { it[13] = "99" }.joinToString(";")
        assertNull(SaveCodec.decode(bad))
    }

    @Test fun challengeLevelsUnlockInOrderAndPayHintsEveryFifth() {
        var p = Progress()
        assertTrue(p.challengeUnlocked(1)); assertFalse(p.challengeUnlocked(2))
        for (n in 1..4) p = p.withChallengeCleared(n)
        val before = p.hints
        p = p.withChallengeCleared(5)
        assertEquals(5, p.challengeCleared)
        assertEquals(minOf(MAX_HINTS, before + 1), p.hints)
        p = p.withChallengeCleared(2) // replay: no change to progress or hints
        assertEquals(5, p.challengeCleared)
        assertTrue(p.challengeUnlocked(6))
        assertFalse(p.challengeUnlocked(7))
    }

    @Test fun rushAndZenResultsAreRecorded() {
        var p = Progress().withRushResult(7).withRushResult(3)
        assertEquals(7, p.rushBest)
        assertEquals(2, p.rushRuns)
        assertEquals(10, p.rushTotal)
        assertEquals(10, p.totalSolved)
        p = p.withZenSolved().withZenSolved()
        assertEquals(2, p.zenSolved)
    }

    @Test fun modeAchievementsUnlockFromModeProgress() {
        val p = Progress(rushBest = 8, challengeCleared = 10, zenSolved = 50)
        val ids = Achievements.newlyUnlocked(p).map { it.id }.toSet()
        assertTrue(ids.containsAll(setOf("rush8", "challenge10", "zen50")))
        assertFalse("rush20" in ids)
        assertTrue(Achievements.all.any { it.category == AchievementCategory.MODES })
    }
}
