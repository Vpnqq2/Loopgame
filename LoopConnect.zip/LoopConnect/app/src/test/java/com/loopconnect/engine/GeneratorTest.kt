package com.loopconnect.engine

import org.junit.Assert.*
import org.junit.Test

class GeneratorTest {
    @Test fun everyLevelIsVerifiedAndSolvable() {
        for (n in 1..150) {
            val level = LevelGenerator.forLevel(n)
            assertTrue("level $n verify", LevelGenerator.verify(level))
            assertTrue("level $n solution obeys rules", Rules.isSolved(level.solved, level.width, level.height, level.spec.objective))
            assertFalse("level $n starts unsolved", Rules.isSolved(level.initialMasks, level.width, level.height, level.spec.objective))
            val r = Solver.solve(level)
            assertFalse("level $n not proven unsolvable", r.provenUnsolvable)
            r.masks?.let { assertTrue(Rules.isSolved(it, level.width, level.height, level.spec.objective)) }
        }
    }

    @Test fun scrambledBoardCanBeSolvedByRotationAlone() {
        val level = LevelGenerator.forLevel(40)
        val b = PuzzleBoard(level)
        for (i in 0 until level.size) repeat(b.tapsNeeded(i)) { b.rotate(i) }
        assertTrue(b.isSolved())
        assertEquals(level.par, b.moves)
    }

    @Test fun sameSpecRecreatesExactLevel() {
        val a = LevelGenerator.forLevel(33)
        val b = LevelGenerator.build(a.spec)!!
        assertArrayEquals(a.solved, b.solved)
        assertArrayEquals(a.initialMasks, b.initialMasks)
        assertEquals(a.signature, b.signature)
    }

    @Test fun dailyPuzzleIsConsistentPerDateAndDiffersAcrossDates() {
        val d1 = LevelGenerator.daily(20000)
        val d2 = LevelGenerator.daily(20000)
        assertArrayEquals(d1.initialMasks, d2.initialMasks)
        assertTrue(LevelGenerator.verify(d1))
        val sigs = (20000L..20009L).map { LevelGenerator.daily(it).signature }.toSet()
        assertTrue(sigs.size >= 9)
    }

    @Test fun difficultyIncreasesWithLevelNumber() {
        var lastArea = 0
        var lastBranch = 0
        for (n in 1..200) {
            val s = LevelGenerator.specFor(n)
            assertTrue(s.width * s.height >= lastArea)
            assertTrue(s.branchingPm >= lastBranch)
            lastArea = s.width * s.height
            lastBranch = s.branchingPm
        }
        fun avgOccupied(range: IntRange) = range.map { LevelGenerator.forLevel(it).solved.count { m -> m != 0 } }.average()
        assertTrue(avgOccupied(1..10) < avgOccupied(41..50))
        assertTrue(avgOccupied(41..50) < avgOccupied(91..100))
        val objectives = (1..100).map { LevelGenerator.specFor(it).objective }.toSet()
        assertEquals(setOf(Objective.NETWORK, Objective.LOOPS), objectives)
    }

    @Test fun unlimitedLevelNumbersWork() {
        for (n in listOf(500, 2_000, 99_999)) assertTrue(LevelGenerator.verify(LevelGenerator.forLevel(n)))
    }

    @Test fun recentLayoutsAreAvoided() {
        val seen = HashSet<Long>()
        repeat(20) {
            val level = LevelGenerator.forLevel(1, avoid = seen.toSet())
            assertTrue("layout repeated", seen.add(level.signature))
        }
    }

    @Test fun loopLevelsHaveNoLooseEndsInSolution() {
        val level = LevelGenerator.forLevel(20)
        assertEquals(Objective.LOOPS, level.spec.objective)
        assertTrue(level.solved.none { Tile.degree(it) == 1 })
    }

    @Test fun earlyLevelsUseOnlySimpleTiles() {
        val level = LevelGenerator.forLevel(2)
        assertTrue(level.solved.all { Tile.degree(it) <= 2 })
    }
}
