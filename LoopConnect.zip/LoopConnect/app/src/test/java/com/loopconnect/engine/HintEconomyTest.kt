package com.loopconnect.engine

import org.junit.Assert.*
import org.junit.Test

class HintEconomyTest {
    @Test fun startsWithThreeHintsAndSpendingStopsAtZero() {
        var p = Progress()
        assertEquals(START_HINTS, p.hints)
        repeat(3) { p = p.spendHint() }
        assertEquals(0, p.hints)
        assertEquals(0, p.spendHint().hints)
    }

    @Test fun oneHintEveryThreeNewLevelsAndOneForFirstThreeStars() {
        var p = Progress()
        p = p.withLevelCompleted(1, 10, 1).withLevelCompleted(2, 10, 1)
        assertEquals(3, p.hints)
        p = p.withLevelCompleted(3, 10, 1)
        assertEquals(4, p.hints)
        p = p.withLevelCompleted(4, 5, 3)
        assertEquals(5, p.hints)
        p = p.withLevelCompleted(4, 5, 3) // replaying a level already at 3 stars earns nothing
        assertEquals(5, p.hints)
    }

    @Test fun weeklyStreakGivesTwoHintsAndAdAddsOne() {
        var p = Progress().copy(hints = 0)
        for (d in 100L..106L) p = p.withDailyCompleted(d)
        assertEquals(WEEK_STREAK_HINTS, p.hints)
        assertEquals(WEEK_STREAK_HINTS + AD_HINTS, p.withHints(AD_HINTS).hints)
    }

    @Test fun balanceIsCapped() {
        assertEquals(MAX_HINTS, Progress().withHints(100).hints)
        val full = Progress().copy(hints = MAX_HINTS)
        assertEquals(MAX_HINTS, full.withLevelCompleted(1, 1, 3).hints)
    }

    @Test fun hintUsedSurvivesSaveAndOldSavesStillLoad() {
        val level = LevelGenerator.forLevel(7)
        val text = SaveCodec.encode(SaveCodec.snapshot(PuzzleBoard(level), null, hintUsed = true))
        assertTrue(SaveCodec.decode(text)!!.hintUsed)
        val v1 = text.split(";").dropLast(2).toMutableList().also { it[0] = "v1" }.joinToString(";")
        val old = SaveCodec.decode(v1)!!
        assertFalse(old.hintUsed)
        assertNotNull(SaveCodec.restore(old))
    }
}
