package com.loopconnect.engine

import org.junit.Assert.*
import org.junit.Test

class ProgressTest {
    @Test fun freshInstallStartsAtZeroAndLocked() {
        val p = Progress()
        assertEquals(0, p.levelsCompleted)
        assertEquals(0, p.totalSolved)
        assertEquals(0L, p.totalMoves)
        assertEquals(0, p.streakOn(100))
        assertEquals(1, p.highestUnlocked)
        assertTrue(Achievements.all.none { it.unlocked(p) })
    }

    @Test fun levelsUnlockSequentiallyAndKeepBestResult() {
        var p = Progress()
        assertTrue(p.isUnlocked(1)); assertFalse(p.isUnlocked(2))
        p = p.withLevelCompleted(1, 10, 1)
        assertTrue(p.isUnlocked(2)); assertEquals(2, p.highestUnlocked)
        p = p.withLevelCompleted(1, 6, 3).withLevelCompleted(1, 9, 2)
        assertEquals(LevelResult(3, 6), p.results[1])
        assertEquals(3, p.totalSolved)
        assertEquals(1, p.levelsCompleted)
    }

    @Test fun dailyStreakCountsConsecutiveDaysAndResets() {
        var p = Progress().withDailyCompleted(100)
        assertEquals(1, p.dailyStreak)
        p = p.withDailyCompleted(101).withDailyCompleted(102)
        assertEquals(3, p.streakOn(102))
        assertEquals(3, p.streakOn(103))
        assertEquals(0, p.streakOn(105))
        p = p.withDailyCompleted(102) // replaying the same day does not grow the streak
        assertEquals(3, p.dailyStreak)
        p = p.withDailyCompleted(110)
        assertEquals(1, p.dailyStreak)
    }

    @Test fun starsDependOnPar() {
        assertEquals(3, Scoring.stars(8, 8))
        assertEquals(2, Scoring.stars(11, 8))
        assertEquals(1, Scoring.stars(30, 8))
    }

    @Test fun recentSignaturesAreBounded() {
        var p = Progress()
        for (i in 1..100) p = p.withSignature(i.toLong())
        assertEquals(40, p.recentSignatures.size)
        assertEquals(100L, p.recentSignatures.last())
    }
}
