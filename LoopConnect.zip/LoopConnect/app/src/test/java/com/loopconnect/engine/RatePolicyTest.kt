package com.loopconnect.engine

import org.junit.Assert.*
import org.junit.Test

class RatePolicyTest {
    private val day = 24L * 60 * 60 * 1000
    private val t0 = 1_700_000_000_000L

    private fun ok(s: RateState = RateState(), levels: Int = 10, now: Long = t0, won: Boolean = true, session: Boolean = false, other: Boolean = false) =
        RatePolicy.shouldShow(s, levels, now, won, session, other)

    @Test fun firstTimeAfterEnoughLevelsAndAWin() = assertTrue(ok())
    @Test fun neverBeforeEnoughLevels() = assertFalse(ok(levels = RatePolicy.MIN_LEVELS - 1))
    @Test fun neverWithoutAWinThisSession() = assertFalse(ok(won = false))
    @Test fun onlyOncePerSession() = assertFalse(ok(session = true))
    @Test fun neverWhileAnotherPromptIsPending() = assertFalse(ok(other = true))
    @Test fun neverAfterRated() = assertFalse(ok(RateState(done = true)))

    @Test fun laterNeedsDaysAndLevels() {
        val s = RateState(shownCount = 1, lastShownMs = t0, lastShownLevels = 10)
        assertFalse(ok(s, levels = 20, now = t0 + day))
        assertFalse(ok(s, levels = 12, now = t0 + 5 * day))
        assertTrue(ok(s, levels = 15, now = t0 + 4 * day))
    }

    @Test fun stopsAfterThreeShows() =
        assertFalse(ok(RateState(shownCount = RatePolicy.MAX_SHOWS, lastShownMs = t0, lastShownLevels = 1), levels = 99, now = t0 + 30 * day))

    @Test fun clockMovedBackDoesNotBlockForever() {
        val s = RateState(shownCount = 1, lastShownMs = t0 + 100 * day, lastShownLevels = 5)
        assertTrue(ok(s, levels = 20, now = t0))
    }
}
