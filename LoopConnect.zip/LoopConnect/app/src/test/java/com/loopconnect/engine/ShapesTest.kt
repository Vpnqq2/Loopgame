package com.loopconnect.engine

import org.junit.Assert.*
import org.junit.Test

class ShapesTest {
    private fun connected(s: Shape): Boolean {
        val start = s.cells.indexOfFirst { it }
        val seen = BooleanArray(s.cells.size)
        val stack = ArrayDeque<Int>().apply { addLast(start) }
        seen[start] = true
        var n = 1
        while (stack.isNotEmpty()) {
            val c = stack.removeLast()
            for (d in Dir.ALL) {
                val nb = Rules.neighbor(c, d, s.width, s.height)
                if (nb >= 0 && s.cells[nb] && !seen[nb]) { seen[nb] = true; n++; stack.addLast(nb) }
            }
        }
        return n == s.filled
    }

    private fun shape(id: Int) = Shapes.get(id)!!

    @Test fun everyShapeIsOneConnectedPieceOfASupportedSize() {
        for (id in 1..300) {
            val s = shape(id)
            assertTrue("picture $id connected", connected(s))
            assertTrue("picture $id width ${s.width}", s.width in 4..9)
            assertTrue("picture $id height ${s.height}", s.height in 4..11)
            assertTrue("picture $id size ${s.filled}", s.filled in 10..48)
        }
    }

    @Test fun everyShapeIsMirrorSymmetric() {
        for (id in 1..300) {
            val s = shape(id)
            for (y in 0 until s.height) for (x in 0 until s.width)
                assertEquals("picture $id row $y", s.cells[y * s.width + x], s.cells[y * s.width + (s.width - 1 - x)])
        }
    }

    @Test fun noPictureEverRepeatsNotEvenFlipped() {
        fun canonical(s: Shape): String {
            val r = s.rows()
            val variants = listOf(r, r.map { it.reversed() }, r.reversed(), r.reversed().map { it.reversed() })
            return "${s.width}x${s.height}:" + variants.map { it.joinToString("/") }.sorted().first()
        }
        val keys = (1..500).map { canonical(shape(it)) }
        assertEquals(keys.size, keys.toSet().size)
    }

    @Test fun picturesGrowWithTheLevel() {
        fun avg(range: IntRange) = range.map { shape(it).filled }.average()
        assertTrue(avg(1..5) + 8 < avg(40..45))
    }

    @Test fun everyThirdLevelIsAPictureLevel() {
        assertEquals(1, Shapes.idFor(3)); assertEquals(2, Shapes.idFor(6)); assertEquals(33_333, Shapes.idFor(99_999))
        assertEquals(-1, Shapes.idFor(1)); assertEquals(-1, Shapes.idFor(4)); assertEquals(-1, Shapes.idFor(2))
        assertNull(Shapes.get(-1)); assertNull(Shapes.get(0))
    }

    @Test fun pictureLevelsFormExactlyTheirPictureWhenSolved() {
        for (n in (3..120 step 3)) {
            val level = LevelGenerator.forLevel(n)
            val shape = shape(level.spec.shapeId)
            assertEquals(shape.width, level.width)
            assertEquals(shape.height, level.height)
            for (i in level.solved.indices) assertEquals("level $n cell $i", shape.cells[i], level.solved[i] != 0)
            assertTrue("level $n valid", LevelGenerator.verify(level))
        }
    }

    @Test fun otherModesAreUnaffected() {
        for (n in 1..60) assertEquals(-1, LevelGenerator.specFor(n).shapeId)
        assertEquals(-1, LevelGenerator.challengeSpec(3).shapeId)
        assertEquals(-1, LevelGenerator.dailySpec(20000).shapeId)
    }

    @Test fun saveRoundTripKeepsThePicture() {
        val board = PuzzleBoard(LevelGenerator.forLevel(9))
        val text = SaveCodec.encode(SaveCodec.snapshot(board, null))
        val back = SaveCodec.decode(text)!!
        assertEquals(board.level.spec.shapeId, back.spec.shapeId)
        assertNotNull(SaveCodec.restore(back))
    }

    @Test fun oldV3SavesStillLoadAsPlainBoards() {
        val old = "v3;5;4;4;0;3;900;300;123;-1;;0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0;0;0"
        val g = SaveCodec.decode(old)
        assertNotNull(g)
        assertEquals(-1, g!!.spec.shapeId)
    }
}
