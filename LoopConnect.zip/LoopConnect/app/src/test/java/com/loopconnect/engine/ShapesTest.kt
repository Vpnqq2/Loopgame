package com.loopconnect.engine

import org.junit.Assert.*
import org.junit.Test

class ShapesTest {
    private fun connected(s: Shape): Boolean {
        val start = s.cells.indexOfFirst { it }
        val seen = BooleanArray(s.cells.size)
        val stack = ArrayDeque<Int>().apply { addLast(start) }
        seen[start] = true
        var n = 1
        while (stack.isNotEmpty()) {
            val c = stack.removeLast()
            for (d in Dir.ALL) {
                val nb = Rules.neighbor(c, d, s.width, s.height)
                if (nb >= 0 && s.cells[nb] && !seen[nb]) { seen[nb] = true; n++; stack.addLast(nb) }
            }
        }
        return n == s.filled
    }

    @Test fun everyShapeIsOneConnectedPieceOfASupportedSize() {
        assertEquals(Shapes.all.size, Shapes.all.map { it.name }.toSet().size)
        for (s in Shapes.all) {
            assertTrue("${s.name} connected", connected(s))
            assertTrue("${s.name} width", s.width in 3..8)
            assertTrue("${s.name} height", s.height in 3..11)
        }
    }

    @Test fun heartComesFirstThenMoreDetailedPictures() {
        assertEquals("Heart", Shapes.all[Shapes.idFor(3)].name)
        assertEquals(-1, Shapes.idFor(1)); assertEquals(-1, Shapes.idFor(4)); assertEquals(-1, Shapes.idFor(2))
        val names = (1..13).map { Shapes.all[Shapes.idFor(it * 3)].name }
        assertTrue("animals appear early", names.take(6).any { it in setOf("Kitten", "Fish", "Bunny") })
    }

    @Test fun pictureLevelsFormExactlyTheirPictureWhenSolved() {
        for (n in (3..120 step 3)) {
            val level = LevelGenerator.forLevel(n)
            val shape = Shapes.all[level.spec.shapeId]
            assertEquals(shape.width, level.width)
            assertEquals(shape.height, level.height)
            for (i in level.solved.indices) assertEquals("level $n cell $i", shape.cells[i], level.solved[i] != 0)
            assertTrue("level $n valid", LevelGenerator.verify(level))
        }
    }

    @Test fun otherModesAreUnaffected() {
        for (n in 1..60) assertEquals(-1, LevelGenerator.specFor(n).shapeId)
        assertEquals(-1, LevelGenerator.challengeSpec(3).shapeId)
        assertEquals(-1, LevelGenerator.dailySpec(20000).shapeId)
    }

    @Test fun saveRoundTripKeepsThePicture() {
        val board = PuzzleBoard(LevelGenerator.forLevel(9))
        val text = SaveCodec.encode(SaveCodec.snapshot(board, null))
        val back = SaveCodec.decode(text)!!
        assertEquals(board.level.spec.shapeId, back.spec.shapeId)
        assertNotNull(SaveCodec.restore(back))
    }

    @Test fun oldV3SavesStillLoadAsPlainBoards() {
        val old = "v3;5;4;4;0;3;900;300;123;-1;;0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0;0;0"
        val g = SaveCodec.decode(old)
        assertNotNull(g)
        assertEquals(-1, g!!.spec.shapeId)
    }
}
