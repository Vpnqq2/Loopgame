package com.loopconnect.engine

import org.junit.Assert.*
import org.junit.Test

class SparkTest {
    private val sample = listOf(1, 2, 3, 5, 8, 9, 12, 16, 25, 40, 80)

    @Test fun everyGeneratedLevelCanBeSolvedByWakingPiecesInOrder() {
        for (n in sample) {
            val level = LevelGenerator.createSpark(LevelGenerator.sparkSpec(n))
            assertTrue("level $n", LevelGenerator.verifySpark(level))
            assertTrue(level.par > 0)
        }
    }

    @Test fun generationIsDeterministicForASpec() {
        val a = LevelGenerator.createSpark(LevelGenerator.sparkSpec(14))
        val b = LevelGenerator.buildSpark(a.spec)!!
        assertArrayEquals(a.solved, b.solved)
        assertArrayEquals(a.initialMasks, b.initialMasks)
    }

    @Test fun sleepingPiecesDoNotTurnUntilPowered() {
        var checked = false
        for (n in sample) {
            val level = LevelGenerator.createSpark(LevelGenerator.sparkSpec(n))
            val b = PuzzleBoard(level, sparkSource = Spark.sourceOf(level))
            assertTrue(b.isAwake(b.sparkSource))
            val sleeping = (0 until level.size).firstOrNull { level.solved[it] != 0 && !b.isAwake(it) } ?: continue
            val before = b.masksCopy()
            assertFalse(b.rotate(sleeping))
            assertArrayEquals(before, b.masksCopy())
            assertEquals(0, b.moves)
            checked = true
        }
        assertTrue("expected at least one level with sleeping pieces", checked)
    }

    @Test fun poweredPiecesStayUnlockedAndUndoRestoresPower() {
        val level = LevelGenerator.createSpark(LevelGenerator.sparkSpec(20))
        val b = PuzzleBoard(level, sparkSource = Spark.sourceOf(level))
        val startAwake = b.awakeCopy()!!
        val awakeBefore = b.awakeCount
        // Turn powered pieces around; power already reached is never lost.
        var turned = 0
        for (i in 0 until level.size) if (b.isAwake(i) && b.rotate(i)) turned++
        assertTrue(b.awakeCount >= awakeBefore)
        repeat(turned) { b.undo() }
        assertArrayEquals(startAwake, b.awakeCopy()!!)
        assertEquals(0, b.moves)
    }

    @Test fun saveRoundTripKeepsPowerState() {
        val level = LevelGenerator.createSpark(LevelGenerator.sparkSpec(14))
        val b = PuzzleBoard(level, sparkSource = Spark.sourceOf(level))
        var n = 0
        for (i in 0 until level.size) {
            if (b.isAwake(i) && b.rotate(i)) n++
            if (n >= 6) break
        }
        val text = SaveCodec.encode(SaveCodec.snapshot(b, null, false, GameMode.SPARK))
        val restored = SaveCodec.restore(SaveCodec.decode(text)!!)!!
        assertArrayEquals(b.masksCopy(), restored.masksCopy())
        assertArrayEquals(b.awakeCopy()!!, restored.awakeCopy()!!)
        assertEquals(b.moves, restored.moves)
    }

    @Test fun hintAlwaysPointsAtAPoweredPiece() {
        for (n in sample) {
            val level = LevelGenerator.createSpark(LevelGenerator.sparkSpec(n))
            val b = PuzzleBoard(level, sparkSource = Spark.sourceOf(level))
            val h = b.hint()
            assertNotNull(h)
            assertTrue(b.isAwake(h!!.tile))
        }
    }

    @Test fun progressCountsSparkCircuitsInOrder() {
        val p = Progress().withSparkCleared(1).withSparkCleared(2).withSparkCleared(2)
        assertEquals(2, p.sparkCleared)
        assertEquals(3, p.totalSolved)
    }
}
