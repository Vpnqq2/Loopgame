package com.loopconnect.engine

import org.junit.Assert.*
import org.junit.Test

class TileAndRulesTest {
    @Test fun rotationCyclesClockwise() {
        assertEquals(Dir.E, Tile.rotateCw(Dir.N))
        assertEquals(Dir.S, Tile.rotateCw(Dir.E))
        assertEquals(Dir.W, Tile.rotateCw(Dir.S))
        assertEquals(Dir.N, Tile.rotateCw(Dir.W))
        for (m in 0..15) {
            assertEquals(m, Tile.rotateCw(m, 4))
            assertEquals(m, Tile.rotateCcw(Tile.rotateCw(m)))
            assertEquals(Tile.degree(m), Tile.degree(Tile.rotateCw(m)))
        }
    }

    @Test fun allTileKindsAndRotationCounts() {
        assertEquals(TileKind.EMPTY, Tile.kind(0))
        assertEquals(TileKind.END, Tile.kind(Dir.N))
        assertEquals(TileKind.STRAIGHT, Tile.kind(Dir.N or Dir.S))
        assertEquals(TileKind.CORNER, Tile.kind(Dir.N or Dir.E))
        assertEquals(TileKind.TEE, Tile.kind(Dir.N or Dir.E or Dir.S))
        assertEquals(TileKind.CROSS, Tile.kind(15))
        assertEquals(1, Tile.distinctRotations(0).size)
        assertEquals(4, Tile.distinctRotations(Dir.N).size)
        assertEquals(2, Tile.distinctRotations(Dir.N or Dir.S).size)
        assertEquals(4, Tile.distinctRotations(Dir.N or Dir.E).size)
        assertEquals(4, Tile.distinctRotations(Dir.N or Dir.E or Dir.S).size)
        assertEquals(1, Tile.distinctRotations(15).size)
    }

    @Test fun adjacentTilesConnectOnlyWhenSidesMatch() {
        // 3 wide, 3 high: horizontal pair at top-left
        val masks = IntArray(9)
        masks[0] = Dir.E
        masks[1] = Dir.W
        assertTrue(Rules.isMatched(masks, 3, 3, 0, Dir.E))
        assertTrue(Rules.isMatched(masks, 3, 3, 1, Dir.W))
        masks[1] = Dir.N or Dir.S
        assertFalse(Rules.isMatched(masks, 3, 3, 0, Dir.E))
        // open side facing the border never matches
        assertFalse(Rules.isMatched(intArrayOf(Dir.W, 0, 0, 0, 0, 0, 0, 0, 0), 3, 3, 0, Dir.W))
    }

    @Test fun completionDetection() {
        // a straight chain of three tiles, rest empty
        val ok = intArrayOf(Dir.E, Dir.E or Dir.W, Dir.W, 0, 0, 0, 0, 0, 0)
        assertTrue(Rules.isSolved(ok, 3, 3, Objective.NETWORK))
        val dangling = intArrayOf(Dir.E, Dir.N or Dir.S, Dir.W, 0, 0, 0, 0, 0, 0)
        assertFalse(Rules.isSolved(dangling, 3, 3, Objective.NETWORK))
        // two separate networks are not a single network
        val two = intArrayOf(Dir.E, Dir.W, 0, 0, 0, 0, Dir.E, Dir.W, 0)
        assertFalse(Rules.isSolved(two, 3, 3, Objective.NETWORK))
        assertFalse(Rules.isSolved(IntArray(9), 3, 3, Objective.NETWORK))
    }

    @Test fun loopObjectiveRejectsLooseEnds() {
        // 2x2 ring in the top-left of a 3x3 board
        val ring = intArrayOf(
            Dir.E or Dir.S, Dir.W or Dir.S, 0,
            Dir.N or Dir.E, Dir.N or Dir.W, 0,
            0, 0, 0
        )
        assertTrue(Rules.isSolved(ring, 3, 3, Objective.LOOPS))
        val chain = intArrayOf(Dir.E, Dir.E or Dir.W, Dir.W, 0, 0, 0, 0, 0, 0)
        assertTrue(Rules.isSolved(chain, 3, 3, Objective.NETWORK))
        assertFalse(Rules.isSolved(chain, 3, 3, Objective.LOOPS))
    }
}
