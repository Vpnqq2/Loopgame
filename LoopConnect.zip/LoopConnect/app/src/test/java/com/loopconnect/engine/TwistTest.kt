package com.loopconnect.engine

import org.junit.Assert.*
import org.junit.Test

class TwistTest {
    private fun rulesOf(n: Int) = LevelGenerator.campaignSpec(n).rules

    @Test fun everyRuleDebutsAloneOnItsIntroLevel() {
        for (t in Twist.values()) {
            assertEquals("${t.name} intro level", t.bit, rulesOf(t.introLevel))
            for (n in 1 until t.introLevel) assertFalse("${t.name} must not appear on level $n", Twist.has(rulesOf(n), t))
        }
    }

    @Test fun firstFiveLevelsHaveNoNewRules() {
        for (n in 1..5) assertEquals(0, rulesOf(n))
    }

    @Test fun laterLevelsMixSeveralRules() {
        assertTrue((1..120).any { Integer.bitCount(rulesOf(it)) >= 2 })
    }

    @Test fun otherModesNeverUseTheNewRules() {
        for (n in 1..80) {
            assertEquals(0, LevelGenerator.challengeSpec(n).rules)
            assertEquals(0, LevelGenerator.sparkSpec(n).rules)
            assertEquals(0, LevelGenerator.rushSpec(n, 7L).rules)
        }
        assertEquals(0, LevelGenerator.dailySpec(20000).rules)
        assertEquals(0, LevelGenerator.zenSpec(ZenSize.MEDIUM, 3, 1L).rules)
    }

    @Test fun everyCampaignLevelIsPlayableWithItsRules() {
        for (n in 1..160) {
            val level = LevelGenerator.forLevel(n)
            assertTrue("level $n verify", LevelGenerator.verify(level))
            assertTrue("level $n play check", LevelGenerator.verifyPlay(level))
            // A level may fall back to a plain board, but it never carries a rule it does not use.
            val r = level.spec.rules
            if (Twist.has(r, Twist.LOCKS)) assertTrue("level $n has locks", level.locked.any { it })
            if (Twist.has(r, Twist.TWINS)) assertTrue("level $n has twins", level.partner.any { it >= 0 })
            if (Twist.has(r, Twist.SHAPE)) assertTrue("level $n has walls", level.playable.any { !it })
        }
    }

    @Test fun lockedPiecesNeverTurnAndStartInTheirSolvedPosition() {
        val level = LevelGenerator.forLevel(Twist.LOCKS.introLevel)
        assertTrue(level.locked.any { it })
        val b = PuzzleBoard(level)
        for (i in 0 until level.size) if (level.locked[i]) {
            assertEquals(level.solved[i], level.initialMasks[i])
            assertFalse(b.rotate(i))
            assertEquals(level.solved[i], b.mask(i))
        }
        assertEquals(0, b.moves)
    }

    @Test fun hintsNeverPointAtALockedPiece() {
        for (n in listOf(6, 9, 12, 15, 18, 21, 30)) {
            val level = LevelGenerator.forLevel(n)
            val h = PuzzleBoard(level).hint() ?: continue
            assertFalse("level $n", level.locked[h.tile])
        }
    }

    @Test fun twinsTurnTogetherAndUndoTurnsThemBack() {
        val level = LevelGenerator.forLevel(Twist.TWINS.introLevel)
        val a = level.partner.indexOfFirst { it >= 0 }
        assertTrue(a >= 0)
        val p = level.partner[a]
        assertEquals(a, level.partner[p])
        val b = PuzzleBoard(level)
        val ma = b.mask(a)
        val mp = b.mask(p)
        assertTrue(b.rotate(a))
        assertEquals(Tile.rotateCw(ma), b.mask(a))
        assertEquals(Tile.rotateCw(mp), b.mask(p))
        assertEquals(1, b.moves)
        b.undo()
        assertEquals(ma, b.mask(a))
        assertEquals(mp, b.mask(p))
    }

    @Test fun twinsAreNeverSymmetricOrLocked() {
        for (n in 14..100) {
            val level = LevelGenerator.forLevel(n)
            for (i in 0 until level.size) if (level.partner[i] >= 0) {
                assertFalse(level.locked[i])
                assertNotEquals(level.solved[i], Tile.rotateCw(level.solved[i]))
            }
        }
    }

    @Test fun parCountsATwinPairOnce() {
        for (n in listOf(14, 18, 22, 26, 30)) {
            val level = LevelGenerator.forLevel(n)
            val b = PuzzleBoard(level)
            for (i in 0 until level.size) repeat(b.tapsNeeded(i)) { b.rotate(i) }
            assertTrue("level $n solved", b.isSolved())
            assertEquals("level $n par", level.par, b.moves)
        }
    }

    @Test fun wallsAreEmptyAndTheShapeIsOneConnectedBoard() {
        for (n in listOf(11, 16, 21, 26, 31, 36, 41, 46)) {
            val level = LevelGenerator.forLevel(n)
            if (!Twist.has(level.spec.rules, Twist.SHAPE)) continue
            assertTrue("level $n has walls", level.playable.any { !it })
            for (i in 0 until level.size) if (!level.playable[i]) assertEquals(0, level.solved[i])
            assertTrue(Rules.isConnected(level.solved, level.width, level.height))
        }
    }

    @Test fun windingLevelsStayWithinTheirDegreeLimit() {
        for (n in listOf(10, 15, 20, 25)) {
            val level = LevelGenerator.forLevel(n)
            if (!Twist.has(level.spec.rules, Twist.WINDING)) continue
            assertTrue("level $n", level.solved.all { Tile.degree(it) <= level.spec.maxDegree })
        }
    }

    @Test fun savesKeepTheRulesAndRejectMovedPadlocks() {
        val level = LevelGenerator.forLevel(12)
        val board = PuzzleBoard(level)
        val back = SaveCodec.decode(SaveCodec.encode(SaveCodec.snapshot(board, null)))!!
        assertEquals(level.spec, back.spec)
        assertNotNull(SaveCodec.restore(back))
        val i = level.locked.indexOfFirst { it }
        if (i >= 0) {
            val masks = back.masks.copyOf()
            masks[i] = Tile.rotateCw(masks[i])
            if (masks[i] != level.solved[i]) assertNull(SaveCodec.restore(back.copy(masks = masks)))
        }
    }

    @Test fun progressRemembersWhichRulesWereExplained() {
        val p = Progress().withTwistSeen(Twist.LOCKS.name)
        assertTrue(Twist.LOCKS.name in p.seenTwists)
        assertFalse(Twist.TWINS.name in p.seenTwists)
    }
}
