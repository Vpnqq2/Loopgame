package com.loopconnect.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.loopconnect.engine.Twist
import com.loopconnect.ui.*
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/*
 * Visual marks for the Classic rules (see Twist): stone wall blocks for odd board shapes, metal plates and padlocks
 * for locked pieces, glowing link badges for twin pieces. Shared by the game board, the tutorial boards and the
 * rule tips. Everything is animated from a few numbers ([MarkFx]) so the board only redraws, never recomposes.
 */

/**
 * Animation state for the marks. [ambient] loops 0..1 forever (glints, breathing, flowing dashes), [intro] is the board's
 * pop-in (0..1: padlocks snap shut at the end), [win] is the completion wave (0..1: padlocks break, links dissolve),
 * [denied] is a per-piece "you cannot turn this" pulse and [link] a per-piece twin pulse travelling to its partner.
 */
internal class MarkFx(
    val ambient: Float = 0f,
    val intro: Float = 1f,
    val win: Float = 0f,
    val denied: (Int) -> Float = { 0f },
    val link: (Int) -> Float = { 0f }
)

private const val TAU = (2.0 * PI).toFloat()

/** Completion progress (0..1) of one piece: the wave that crosses the board from the top-left corner. */
private fun tileWin(ui: GameUiState, fx: MarkFx, i: Int): Float {
    if (fx.win <= 0f) return 0f
    val denom = (ui.width + ui.height - 2).coerceAtLeast(1).toFloat()
    val dist = ((i % ui.width) + (i / ui.width)) / denom
    return (fx.win * 1.7f - dist * 0.7f).coerceIn(0f, 1f)
}

private fun DrawScope.cellCenter(ui: GameUiState, cell: Float, i: Int) =
    Offset((i % ui.width) * cell + cell / 2f, (i / ui.width) * cell + cell / 2f)

/** Colour index (0, 1, 2 ...) of every twin piece, so both pieces of a pair share a colour. -1 for pieces without a twin. */
internal fun pairColorIndex(partner: IntArray): IntArray {
    val idx = IntArray(partner.size) { -1 }
    var next = 0
    for (i in partner.indices) {
        val p = partner[i]
        if (p > i && idx[i] < 0) { idx[i] = next; idx[p] = next; next++ }
    }
    return idx
}

internal fun twinPalette(c: LoopColors): List<Color> = listOf(c.gold, c.pop1, c.pop2, c.accent2)

/** Everything that sits behind the line art: stone walls, locked plates, twin plates and the energy line between twins. */
internal fun DrawScope.drawPlates(ui: GameUiState, cell: Float, c: LoopColors, fx: MarkFx = MarkFx()) {
    val n = ui.width * ui.height
    val pad = cell * 0.07f
    val side = cell - pad * 2
    val corner = CornerRadius(cell * 0.2f)
    fun topLeft(i: Int) = Offset((i % ui.width) * cell + pad, (i / ui.width) * cell + pad)

    // Walls: a dark stone block with a lit top edge, a shaded bottom edge and a crack.
    ui.playable?.let { pl ->
        for (i in 0 until n) {
            if (pl.getOrNull(i) != false) continue
            val tl = topLeft(i)
            val fade = 1f - 0.45f * tileWin(ui, fx, i)
            drawRoundRect(
                Brush.verticalGradient(listOf(c.textDim.copy(alpha = 0.26f * fade), c.textDim.copy(alpha = 0.08f * fade)), tl.y, tl.y + side),
                tl, Size(side, side), corner
            )
            drawRoundRect(c.textDim.copy(alpha = 0.34f * fade), tl, Size(side, side), corner, style = Stroke(cell * 0.025f))
            drawLine(
                Color.White.copy(alpha = 0.18f * fade), Offset(tl.x + cell * 0.14f, tl.y + cell * 0.045f),
                Offset(tl.x + side - cell * 0.14f, tl.y + cell * 0.045f), cell * 0.025f, StrokeCap.Round
            )
            drawLine(
                Color.Black.copy(alpha = 0.22f * fade), Offset(tl.x + cell * 0.14f, tl.y + side - cell * 0.03f),
                Offset(tl.x + side - cell * 0.14f, tl.y + side - cell * 0.03f), cell * 0.03f, StrokeCap.Round
            )
            val m = cell * 0.14f
            val cx = (i % ui.width) * cell + cell / 2
            val cy = (i / ui.width) * cell + cell / 2
            val crack = Path().apply {
                moveTo(cx - m, cy - m * 0.9f); lineTo(cx - m * 0.1f, cy - m * 0.2f)
                lineTo(cx + m * 0.25f, cy - m * 0.5f); lineTo(cx + m, cy + m * 0.9f)
            }
            drawPath(crack, c.textDim.copy(alpha = 0.34f * fade), style = Stroke(cell * 0.025f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }

    // Locked pieces: a metal plate with rivets that breathes softly and turns green when the level is solved.
    ui.locked?.let { lk ->
        for (i in 0 until n) {
            if (lk.getOrNull(i) != true) continue
            val t = tileWin(ui, fx, i)
            val col = lerp(c.gold, c.good, t)
            val tl = topLeft(i)
            val breathe = 0.5f + 0.5f * sin(TAU * (fx.ambient + i * 0.17f))
            drawRoundRect(
                Brush.verticalGradient(listOf(col.copy(alpha = 0.18f), col.copy(alpha = 0.04f)), tl.y, tl.y + side),
                tl, Size(side, side), corner
            )
            drawRoundRect(col.copy(alpha = 0.40f + 0.18f * breathe * (1f - t) + 0.25f * t), tl, Size(side, side), corner, style = Stroke(cell * 0.032f))
            val inset = cell * 0.07f
            val rivet = lerp(col, Color.White, 0.45f).copy(alpha = 0.85f * (1f - t))
            for (dx in 0..1) for (dy in 0..1) {
                drawCircle(rivet, cell * 0.026f, Offset(tl.x + inset + dx * (side - 2 * inset), tl.y + inset + dy * (side - 2 * inset)))
            }
        }
    }

    // Twin pieces: a tinted glass plate that pulses, joined to its partner by a dashed line of flowing energy.
    ui.partner?.let { pt ->
        val colors = twinPalette(c)
        val idx = pairColorIndex(pt)
        for (i in 0 until n) {
            val p = pt.getOrNull(i) ?: -1
            if (p < 0) continue
            val col = colors[idx[i].coerceAtLeast(0) % colors.size]
            val t = tileWin(ui, fx, i)
            val now = lerp(col, c.good, t)
            val tl = topLeft(i)
            val beat = 0.5f + 0.5f * sin(TAU * fx.ambient + idx[i] * 1.3f)
            drawRoundRect(
                Brush.verticalGradient(listOf(now.copy(alpha = 0.20f), now.copy(alpha = 0.05f)), tl.y, tl.y + side),
                tl, Size(side, side), corner
            )
            drawRoundRect(now.copy(alpha = 0.55f + 0.2f * beat), tl, Size(side, side), corner, style = Stroke(cell * 0.04f))
            if (p > i) {
                val dash = cell * 0.12f
                drawLine(
                    col.copy(alpha = 0.40f * (1f - t)), cellCenter(ui, cell, i), cellCenter(ui, cell, p), cell * 0.035f,
                    StrokeCap.Round, PathEffect.dashPathEffect(floatArrayOf(dash, dash), -fx.ambient * dash * 2f * 4f)
                )
            }
        }
    }
}

/** Padlocks and link badges, drawn on top of the line art in the top-right corner of a piece. */
internal fun DrawScope.drawBadges(ui: GameUiState, cell: Float, c: LoopColors, fx: MarkFx = MarkFx()) {
    val n = ui.width * ui.height
    fun badge(i: Int) = Offset((i % ui.width) * cell + cell * 0.77f, (i / ui.width) * cell + cell * 0.23f)

    ui.locked?.let { lk ->
        val s = cell * 0.27f
        for (i in 0 until n) {
            if (lk.getOrNull(i) != true) continue
            val t = tileWin(ui, fx, i)
            val ctr = badge(i)
            if (t > 0f) { breakPadlock(ctr, s, t, c, cell); continue }
            val d = fx.denied(i)
            drawCircle(c.bgBottom.copy(alpha = 0.88f), cell * 0.17f, ctr)
            // the shackle drops shut at the end of the board's intro
            val close = ((fx.intro - 0.55f) / 0.45f).coerceIn(0f, 1f)
            val glint = (fx.ambient + i * 0.13f) % 1f
            withTransform({ rotate(sin(d * 18f) * 14f * d, ctr) }) {
                drawPadlock(ctr, s, c.gold, lerp(c.gold, Color.White, 0.35f), lift = (1f - close) * 0.22f * s, glint = if (glint < 0.2f) glint / 0.2f else -1f)
            }
            if (d > 0f) drawCircle(c.bad.copy(alpha = 0.6f * d), cell * (0.17f + 0.12f * (1f - d)), ctr, style = Stroke(cell * 0.03f))
        }
    }

    ui.partner?.let { pt ->
        val colors = twinPalette(c)
        val idx = pairColorIndex(pt)
        for (i in 0 until n) {
            val p = pt.getOrNull(i) ?: -1
            if (p < 0) continue
            val col = colors[idx[i].coerceAtLeast(0) % colors.size]
            val t = tileWin(ui, fx, i)
            val ctr = badge(i)
            if (t <= 0f) {
                drawCircle(c.bgBottom.copy(alpha = 0.88f), cell * 0.17f, ctr)
                drawLinkGlyph(ctr, cell * 0.075f, col)
            } else {
                // the link dissolves: the rings drift apart and fade while a few sparks fly out
                drawLinkGlyph(ctr, cell * 0.075f, lerp(col, c.good, t), spread = t * 1.4f, alpha = 1f - t)
                for (k in 0 until 5) {
                    val ang = TAU * k / 5f + 0.6f
                    val r = cell * (0.05f + 0.22f * t)
                    drawCircle(Color.White.copy(alpha = 0.8f * (1f - t)), cell * 0.02f, Offset(ctr.x + cos(ang) * r, ctr.y + sin(ang) * r))
                }
            }
            // tap pulse: a bright bead runs from this piece to its twin
            val lp = fx.link(i)
            if (lp > 0f && lp < 1f && p > i) {
                val a = cellCenter(ui, cell, i)
                val b = cellCenter(ui, cell, p)
                val pos = Offset(a.x + (b.x - a.x) * lp, a.y + (b.y - a.y) * lp)
                val glow = sin(PI.toFloat() * lp)
                drawCircle(col.copy(alpha = 0.30f * glow), cell * 0.17f, pos)
                drawCircle(Color.White.copy(alpha = 0.95f * glow), cell * 0.05f, pos)
                drawCircle(col.copy(alpha = glow), cell * 0.085f, pos, style = Stroke(cell * 0.025f))
            }
        }
    }
}

/**
 * The padlock breaks when the level is solved ([t] 0..1): a flash ring, the shackle springs up and spins away, the
 * body splits in two and falls, sparks fly out and a green tick stays behind.
 */
private fun DrawScope.breakPadlock(ctr: Offset, s: Float, t: Float, c: LoopColors, cell: Float) {
    val e = 1f - (1f - t) * (1f - t)
    val a = (1f - t).coerceIn(0f, 1f)
    val gold = c.gold
    val bodyW = s * 0.82f
    val bodyH = s * 0.55f
    val bodyTop = ctr.y - s * 0.02f
    val left = ctr.x - bodyW / 2
    val leg = s * 0.24f
    val archY = ctr.y - s * 0.20f

    drawCircle(c.bgBottom.copy(alpha = 0.88f * a), cell * 0.17f, ctr)
    drawCircle(Color.White.copy(alpha = 0.55f * sin(PI.toFloat() * t)), cell * (0.12f + 0.30f * e), ctr, style = Stroke(cell * 0.03f))

    withTransform({ translate(s * 0.25f * e, -s * 1.1f * e); rotate(70f * e, Offset(ctr.x, archY)) }) {
        val arch = Path().apply {
            moveTo(ctr.x - leg, bodyTop)
            lineTo(ctr.x - leg, archY)
            arcTo(Rect(ctr.x - leg, archY - leg, ctr.x + leg, archY + leg), 180f, 180f, false)
            lineTo(ctr.x + leg, bodyTop)
        }
        drawPath(arch, lerp(gold, Color.White, 0.35f).copy(alpha = a), style = Stroke(s * 0.11f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
    for (half in 0..1) {
        val dir = if (half == 0) -1f else 1f
        withTransform({
            translate(dir * s * 0.55f * e, s * 0.9f * e * e)
            rotate(dir * 40f * e, Offset(ctr.x + dir * bodyW * 0.25f, bodyTop + bodyH / 2))
        }) {
            clipRect(
                if (half == 0) left else ctr.x, bodyTop - 1f,
                if (half == 0) ctr.x else left + bodyW, bodyTop + bodyH + 1f
            ) {
                drawRoundRect(gold.copy(alpha = a), Offset(left, bodyTop), Size(bodyW, bodyH), CornerRadius(s * 0.14f))
            }
        }
    }
    for (k in 0 until 8) {
        val ang = TAU * k / 8f + 0.4f
        val r = s * (0.2f + 0.9f * e)
        val col = if (k % 2 == 0) Color.White else gold
        drawCircle(col.copy(alpha = a), s * 0.05f * (1f - t * 0.5f), Offset(ctr.x + cos(ang) * r, ctr.y + sin(ang) * r))
    }
    val r = cell * 0.075f
    val tick = Path().apply {
        moveTo(ctr.x - r * 0.45f, ctr.y); lineTo(ctr.x - r * 0.1f, ctr.y + r * 0.35f); lineTo(ctr.x + r * 0.5f, ctr.y - r * 0.35f)
    }
    drawCircle(c.good.copy(alpha = 0.22f * t), r * 1.5f, ctr)
    drawPath(tick, c.good.copy(alpha = t), style = Stroke(cell * 0.03f, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

/** Two interlocked rings: the twin-link symbol. [r] is the radius of one ring, [spread] pulls the rings apart. */
internal fun DrawScope.drawLinkGlyph(ctr: Offset, r: Float, color: Color, spread: Float = 0f, alpha: Float = 1f) {
    val off = r * (0.7f + spread)
    drawCircle(color.copy(alpha = alpha), r, Offset(ctr.x - off, ctr.y), style = Stroke(r * 0.6f))
    drawCircle(color.copy(alpha = alpha), r, Offset(ctr.x + off, ctr.y), style = Stroke(r * 0.6f))
}

/** A small padlock centred on [ctr], about [s] tall. [lift] raises the shackle (open lock), [glint] 0..1 sweeps a shine across the body. */
internal fun DrawScope.drawPadlock(ctr: Offset, s: Float, body: Color, shackle: Color, lift: Float = 0f, glint: Float = -1f) {
    val bodyW = s * 0.82f
    val bodyH = s * 0.55f
    val bodyTop = ctr.y - s * 0.02f
    val leg = s * 0.24f
    val archY = ctr.y - s * 0.20f - lift
    val arch = Path().apply {
        moveTo(ctr.x - leg, bodyTop)
        lineTo(ctr.x - leg, archY)
        arcTo(Rect(ctr.x - leg, archY - leg, ctr.x + leg, archY + leg), 180f, 180f, false)
        lineTo(ctr.x + leg, bodyTop)
    }
    drawPath(arch, shackle, style = Stroke(s * 0.11f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    drawRoundRect(body, Offset(ctr.x - bodyW / 2, bodyTop), Size(bodyW, bodyH), CornerRadius(s * 0.14f))
    drawRoundRect(Color.White.copy(alpha = 0.22f), Offset(ctr.x - bodyW / 2 + s * 0.05f, bodyTop + s * 0.04f), Size(bodyW - s * 0.1f, bodyH * 0.28f), CornerRadius(s * 0.1f))
    drawCircle(Color.Black.copy(alpha = 0.45f), s * 0.07f, Offset(ctr.x, bodyTop + bodyH * 0.5f))
    if (glint in 0f..1f) {
        val x = ctr.x - bodyW / 2 + bodyW * glint
        drawLine(Color.White.copy(alpha = 0.75f * sin(PI.toFloat() * glint)), Offset(x, bodyTop + bodyH * 0.1f), Offset(x - bodyW * 0.18f, bodyTop + bodyH * 0.9f), s * 0.06f, StrokeCap.Round)
    }
}

/** The first-time instruction for a new Classic rule: a small picture, the rule in one or two sentences, one button. */
@Composable
fun TwistTipDialog(twist: Twist, onDismiss: () -> Unit) {
    val c = LocalLoop.current
    Dialog(onDismissRequest = onDismiss) {
        LoopCard(Modifier.fillMaxWidth().popIn()) {
            Text(
                "NEW RULE", color = c.gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(6.dp))
            Text(
                twist.title, color = c.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(14.dp))
            TwistArt(twist, Modifier.align(Alignment.CenterHorizontally).size(190.dp, 96.dp))
            Spacer(Modifier.height(14.dp))
            Text(twist.tip, color = c.textDim, fontSize = 15.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(18.dp))
            PrimaryButton("Got it", onDismiss, Modifier.fillMaxWidth())
        }
    }
}

/** A tiny picture of each rule, drawn with the same marks as the board. */
@Composable
private fun TwistArt(twist: Twist, modifier: Modifier) {
    val c = LocalLoop.current
    val loop = rememberInfiniteTransition(label = "art")
    val t by loop.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = LinearEasing), RepeatMode.Restart), label = "t")
    Canvas(modifier) {
        val line = c.accent
        val stroke = size.height * 0.07f
        fun seg(a: Offset, b: Offset, col: Color = line) = drawLine(col, a, b, stroke, StrokeCap.Round)
        when (twist) {
            Twist.LOCKS -> {
                val cell = size.height * 0.62f
                val x0 = (size.width - cell * 3) / 2
                val y0 = (size.height - cell) / 2
                val cy = y0 + cell / 2
                seg(Offset(x0 + cell * 0.1f, cy), Offset(x0 + cell * 2.9f, cy))
                val plate = Offset(x0 + cell + cell * 0.07f, y0 + cell * 0.07f)
                drawRoundRect(c.gold.copy(alpha = 0.10f), plate, Size(cell * 0.86f, cell * 0.86f), CornerRadius(cell * 0.2f))
                drawRoundRect(c.gold.copy(alpha = 0.55f), plate, Size(cell * 0.86f, cell * 0.86f), CornerRadius(cell * 0.2f), style = Stroke(cell * 0.04f))
                seg(Offset(x0 + cell * 1.1f, cy), Offset(x0 + cell * 1.9f, cy))
                val open = if (t < 0.5f) 0f else (1f - ((t - 0.5f) / 0.5f)) * 0.25f * cell * 0.55f
                drawPadlock(Offset(x0 + cell * 1.5f, y0 - cell * 0.02f), cell * 0.55f, c.gold, lerp(c.gold, Color.White, 0.35f), lift = open, glint = if (t < 0.4f) t / 0.4f else -1f)
            }
            Twist.TWINS -> {
                val cell = size.height * 0.62f
                val gap = size.width * 0.34f
                val xa = size.width / 2 - gap / 2 - cell / 2
                val xb = size.width / 2 + gap / 2 - cell / 2
                val y0 = (size.height - cell) / 2
                val col = c.gold
                val dash = Stroke(stroke * 0.7f, cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(stroke * 1.2f, stroke * 1.8f)))
                drawLine(col.copy(alpha = 0.8f), Offset(xa + cell, y0 + cell / 2), Offset(xb, y0 + cell / 2), strokeWidth = dash.width, cap = StrokeCap.Round, pathEffect = dash.pathEffect)
                run {
                    val bead = Offset(xa + cell + (xb - xa - cell) * t, y0 + cell / 2)
                    drawCircle(col.copy(alpha = 0.30f), cell * 0.12f, bead)
                    drawCircle(Color.White.copy(alpha = 0.95f), cell * 0.04f, bead)
                }
                for (x in listOf(xa, xb)) {
                    drawRoundRect(col.copy(alpha = 0.10f), Offset(x, y0), Size(cell, cell), CornerRadius(cell * 0.2f))
                    drawRoundRect(col.copy(alpha = 0.75f), Offset(x, y0), Size(cell, cell), CornerRadius(cell * 0.2f), style = Stroke(cell * 0.05f))
                    seg(Offset(x + cell * 0.5f, y0 + cell * 0.2f), Offset(x + cell * 0.5f, y0 + cell * 0.8f))
                    drawLinkGlyph(Offset(x + cell * 0.80f, y0 + cell * 0.20f), cell * 0.075f, col)
                }
            }
            Twist.SHAPE -> {
                val cols = 4
                val rows = 3
                val cell = size.height / (rows + 0.4f)
                val x0 = (size.width - cell * cols) / 2
                val y0 = (size.height - cell * rows) / 2
                for (r in 0 until rows) for (k in 0 until cols) {
                    val wall = (r == 0 && k == cols - 1) || (r == rows - 1 && k == 0)
                    val tl = Offset(x0 + k * cell + cell * 0.07f, y0 + r * cell + cell * 0.07f)
                    val sd = Size(cell * 0.86f, cell * 0.86f)
                    if (wall) {
                        drawRoundRect(c.textDim.copy(alpha = 0.16f), tl, sd, CornerRadius(cell * 0.2f))
                        drawRoundRect(c.textDim.copy(alpha = 0.35f), tl, sd, CornerRadius(cell * 0.2f), style = Stroke(cell * 0.03f))
                    } else {
                        drawRoundRect(c.accent.copy(alpha = 0.18f), tl, sd, CornerRadius(cell * 0.2f))
                        drawCircle(c.accent, cell * 0.09f, Offset(x0 + k * cell + cell / 2, y0 + r * cell + cell / 2))
                    }
                }
            }
            Twist.WINDING -> {
                val w = size.width
                val h = size.height
                val path = Path().apply {
                    moveTo(w * 0.08f, h * 0.2f)
                    lineTo(w * 0.40f, h * 0.2f)
                    lineTo(w * 0.40f, h * 0.8f)
                    lineTo(w * 0.62f, h * 0.8f)
                    lineTo(w * 0.62f, h * 0.2f)
                    lineTo(w * 0.92f, h * 0.2f)
                }
                drawPath(path, line.copy(alpha = 0.28f), style = Stroke(stroke * 2.6f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawPath(path, line, style = Stroke(stroke, cap = StrokeCap.Round, join = StrokeJoin.Round))
                drawCircle(c.gold, stroke * 1.3f, Offset(w * 0.08f, h * 0.2f))
                drawCircle(c.gold, stroke * 1.3f, Offset(w * 0.92f, h * 0.2f))
            }
        }
    }
}
