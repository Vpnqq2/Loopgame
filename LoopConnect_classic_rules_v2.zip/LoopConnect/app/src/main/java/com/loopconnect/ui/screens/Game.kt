package com.loopconnect.ui.screens

import android.os.Build
import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.drawscope.scale
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.activity.compose.BackHandler
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Timer
import com.loopconnect.engine.GameMode
import com.loopconnect.engine.ModeRules
import com.loopconnect.ads.AdManager
import com.loopconnect.engine.AdPolicy
import com.loopconnect.engine.RewardedStatus
import com.loopconnect.ads.findActivity
import com.loopconnect.data.AnimationMode
import com.loopconnect.engine.Dir
import com.loopconnect.engine.Rules
import com.loopconnect.engine.Tile
import com.loopconnect.engine.TileKind
import com.loopconnect.engine.Twist
import com.loopconnect.ui.*
import kotlinx.coroutines.launch
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun GameScreen(vm: GameViewModel, ads: AdManager, onBack: () -> Unit, onSettings: () -> Unit, onHome: () -> Unit) {
    val c = LocalLoop.current
    val ui by vm.ui.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    var paused by rememberSaveable { mutableStateOf(false) }
    var showAd by rememberSaveable { mutableStateOf(false) }
    // After "Next Level" the level map plays its unlock animation before the next puzzle starts.
    var showMap by rememberSaveable { mutableStateOf(false) }
    val context = LocalContext.current
    val view = LocalView.current
    val rushLive by vm.rushLive.collectAsStateWithLifecycle()
    val tip by vm.tip.collectAsStateWithLifecycle()
    val rushFinished by vm.rushFinished.collectAsStateWithLifecycle()
    // In a Rush run the back gesture opens the pause menu instead of silently abandoning the run.
    val topBack: () -> Unit = if (rushLive) { { paused = true } } else onBack
    BackHandler(enabled = rushLive) { paused = true }
    BackHandler(enabled = showMap) { showMap = false }
    LaunchedEffect(ui.completed) { if (!ui.completed) showMap = false }
    LaunchedEffect(paused, showAd) { vm.setUiPaused(paused || showAd) }

    LaunchedEffect(Unit) { vm.ensureLoaded() }
    // Load ads one step ahead, and only when the limits would actually allow showing them.
    LaunchedEffect(ui.key, ui.ready) { if (ui.ready && vm.shouldPreloadInterstitial()) ads.loadInterstitial() }
    LaunchedEffect(progress.hints) {
        if (progress.hints <= 1 && vm.rewardedStatus(System.currentTimeMillis()) is RewardedStatus.Available) ads.load()
    }
    LaunchedEffect(ui.solved) {
        if (ui.solved && settings.haptics) {
            view.performHapticFeedback(
                if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.LONG_PRESS
            )
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            ScreenTopBar(
                title = when {
                    !ui.ready -> "LOOP CONNECT"
                    ui.isDaily -> "DAILY PUZZLE"
                    ui.mode == GameMode.ZEN -> "ZEN"
                    ui.mode == GameMode.RUSH -> "RUSH"
                    ui.mode == GameMode.CHALLENGE -> "CHALLENGE ${ui.levelNumber}"
                    ui.mode == GameMode.SPARK -> "SPARK ${ui.levelNumber}"
                    else -> "LEVEL ${ui.levelNumber}"
                },
                subtitle = if (ui.ready) ui.objective.title else null,
                onBack = topBack,
                trailing = {
                    GlassIconButton(Icons.Rounded.Pause, "Pause menu", { paused = true })
                }
            )
            when {
                ui.error != null -> Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                ) {
                    Text(ui.error ?: "", color = c.text, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(16.dp))
                    PrimaryButton("Try again", { vm.continueGame() })
                }
                !ui.ready -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = c.accent)
                }
                else -> {
                    if (ui.mode == GameMode.RUSH) RushHud(vm, Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                    else InfoCard(ui, Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                    BoxWithConstraints(
                        Modifier.weight(1f).fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center
                    ) {
                        val tile = minOf(maxWidth / ui.width, maxHeight / ui.height, 96.dp)
                        Box(Modifier.size(tile * ui.width, tile * ui.height)) {
                            PuzzleBoardView(
                                ui, settings.animation.rotateMs, Modifier.fillMaxSize()
                            ) { i ->
                                if (vm.rotate(i) && settings.haptics) {
                                    view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                                }
                            }
                            val hint = ui.hint
                            if (hint != null) HintRing(ui.width, ui.height, hint.tile, Modifier.fillMaxSize())
                        }
                    }
                    val hint = ui.hint
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(
                            if (hint != null) "Tap the highlighted piece ${hint.taps} time${if (hint.taps == 1) "" else "s"}"
                            else if (ui.mode == GameMode.RUSH) "Solve as many as you can before time runs out"
                            else if (ui.mode == GameMode.SPARK) "Only lit pieces turn. Link them to wake the dark ones"
                            else if (ui.mode == GameMode.CLASSIC && !ui.isDaily && ui.twists != 0) Twist.list(ui.twists).last().reminder
                            else ui.objective.hint,
                            color = if (hint != null) c.gold else c.textDim, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp).clip(RoundedCornerShape(50))
                                .background(c.surface.copy(alpha = 0.8f)).padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        CircleAction(Icons.AutoMirrored.Rounded.Undo, "Undo", { vm.undo() }, enabled = ui.canUndo && !ui.solved && !ui.failed)
                        CircleAction(
                            Icons.Rounded.Lightbulb, "Hint",
                            { if (progress.hints > 0) vm.hint() else showAd = true },
                            enabled = !ui.solved && !ui.failed && ui.mode != GameMode.RUSH, highlight = ui.hint != null,
                            badge = if (progress.hints > 0) "${progress.hints}" else "+"
                        )
                        CircleAction(Icons.Rounded.Refresh, "Restart", { vm.restart() }, enabled = !ui.solved)
                    }
                }
            }
        }

        if (ui.completed) {
            // Campaign and Challenge levels sit on a map; Zen has no levels and the daily puzzle returns to its calendar.
            val hasMap = !ui.isDaily && (ui.mode == GameMode.CLASSIC || ui.mode == GameMode.CHALLENGE)
            val goNext: () -> Unit = {
                // Decide before loading: nextLevel() replaces the UI state immediately.
                val classic = ui.mode == GameMode.CLASSIC
                val showInterstitial = classic && vm.canShowInterstitial()
                vm.nextLevel()
                // Interstitial: never mid-level, only when moving on to the next level, and only if the policy allows it.
                val activity = context.findActivity()
                if (activity != null && showInterstitial) ads.showInterstitial(activity) { vm.onInterstitialShown() }
            }
            CompleteOverlay(ui, settings.animation != AnimationMode.OFF,
                onNext = { if (hasMap) showMap = true else goNext() },
                onReplay = { vm.replay() }, onBack = onBack)
            if (hasMap && showMap) {
                LevelMapTransition(
                    from = ui.levelNumber,
                    stars = ui.stars,
                    newUnlock = ui.unlockedNext,
                    mode = ui.mode,
                    progress = progress,
                    animated = settings.animation != AnimationMode.OFF,
                    onCelebrate = {
                        if (settings.haptics) {
                            view.performHapticFeedback(
                                if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.LONG_PRESS
                            )
                        }
                        vm.sound.playLevelUnlock()
                    },
                    onPlay = { showMap = false; goNext() }
                )
            }
        }
        if (ui.failed && !ui.solved) {
            FailOverlay(ui, onRetry = { vm.restart() }, onBack = onBack)
        }
        // First time a Classic rule appears: one short instruction before the player starts.
        val newRule = tip
        if (newRule != null && ui.ready && !ui.completed) TwistTipDialog(newRule, onDismiss = { vm.dismissTip() })
        if (rushFinished) {
            RushResultOverlay(vm, onAgain = { vm.startRush() }, onExit = { vm.abandonRush(); onBack() })
        }
        if (showAd) {
            OutOfHintsDialog(
                ads = ads,
                vm = vm,
                onWatch = {
                    val activity = context.findActivity()
                    if (activity != null) ads.show(activity, onRewarded = { vm.grantAdHint(); showAd = false }, onUnavailable = {})
                },
                onDismiss = { showAd = false }
            )
        }
        if (paused) {
            Dialog(onDismissRequest = { paused = false }) {
                LoopCard(Modifier.fillMaxWidth().popIn()) {
                    Text("PAUSED", color = c.text, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp,
                        modifier = Modifier.align(Alignment.CenterHorizontally))
                    Spacer(Modifier.height(16.dp))
                    PrimaryButton("Resume", { paused = false }, Modifier.fillMaxWidth(), icon = Icons.Rounded.PlayArrow)
                    Spacer(Modifier.height(10.dp))
                    OutlineButton("Restart Level", { vm.restart(); paused = false }, Modifier.fillMaxWidth(), icon = Icons.Rounded.Refresh)
                    Spacer(Modifier.height(10.dp))
                    OutlineButton("Settings", { paused = false; onSettings() }, Modifier.fillMaxWidth(), icon = Icons.Rounded.Settings)
                    Spacer(Modifier.height(10.dp))
                    OutlineButton(if (rushLive) "Quit run" else "Main Menu", { paused = false; if (ui.mode == GameMode.RUSH) vm.abandonRush(); onHome() }, Modifier.fillMaxWidth(), icon = Icons.Rounded.Home)
                }
            }
        }
    }
}

@Composable
private fun InfoCard(ui: GameUiState, modifier: Modifier) {
    val c = LocalLoop.current
    val sparky = ui.mode == GameMode.SPARK
    val shown = if (sparky) ui.awakeCount else ui.satisfied
    val target = if (ui.occupied == 0) 0f else shown.toFloat() / ui.occupied
    val fraction by animateFloatAsState(target, tween(450), label = "progress")
    val done = ui.occupied > 0 && shown == ui.occupied
    LoopCard(modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.width(if (ui.mode == GameMode.CHALLENGE) 100.dp else 68.dp).semantics(mergeDescendants = true) {}) {
                Text(if (ui.mode == GameMode.CHALLENGE) "MOVES / LIMIT" else "MOVES", color = c.textDim, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                val low = ui.mode == GameMode.CHALLENGE && ui.moveLimit - ui.moves <= 2
                Text(
                    if (ui.mode == GameMode.CHALLENGE) "${ui.moves}/${ui.moveLimit}" else "${ui.moves}",
                    color = if (low) c.bad else c.text, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold
                )
            }
            Box(Modifier.width(1.dp).height(44.dp).background(c.border))
            Column(Modifier.weight(1f).padding(horizontal = 14.dp).semantics(mergeDescendants = true) {
                contentDescription = "Progress ${ui.satisfied} of ${ui.occupied} pieces connected"
            }) {
                Row {
                    Text(if (sparky) "POWERED" else "PROGRESS", color = c.textDim, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, modifier = Modifier.weight(1f))
                    Text("$shown/${ui.occupied}", color = if (done) c.good else c.text, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp)).background(c.bgBottom)) {
                    Box(
                        Modifier.fillMaxWidth(fraction).fillMaxHeight().clip(RoundedCornerShape(6.dp))
                            .background(Brush.horizontalGradient(listOf(c.accent, if (done) c.good else c.accent2)))
                    )
                }
            }
            if (ui.mode == GameMode.CLASSIC) {
                Box(Modifier.width(1.dp).height(44.dp).background(c.border))
                Column(Modifier.padding(start = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.Star, null, tint = c.gold, modifier = Modifier.size(24.dp))
                    Text("PAR ${ui.par}", color = c.textDim, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
            }
        }
    }
}

/** Component id (lowest tile index) of every tile, connected through matched sides. -1 for empty tiles. */
internal fun components(masks: IntArray, w: Int, h: Int): IntArray {
    val comp = IntArray(masks.size) { -1 }
    for (s in masks.indices) {
        if (masks[s] == 0 || comp[s] >= 0) continue
        comp[s] = s
        val st = ArrayDeque<Int>()
        st.addLast(s)
        while (st.isNotEmpty()) {
            val cur = st.removeLast()
            for (d in Dir.ALL) {
                if (!Rules.isMatched(masks, w, h, cur, d)) continue
                val n = Rules.neighbor(cur, d, w, h)
                if (comp[n] < 0) { comp[n] = s; st.addLast(n) }
            }
        }
    }
    return comp
}

/** The puzzle board: custom Canvas drawing with spring rotation, intro pop-in and a completion wave. */
@Composable
fun PuzzleBoardView(ui: GameUiState, animMs: Int, modifier: Modifier, onTap: (Int) -> Unit) {
    val c = LocalLoop.current
    val n = ui.width * ui.height
    val offsets = remember(ui.key, n) { List(n) { Animatable(0f) } }
    val flash = remember(ui.key, n) { List(n) { Animatable(0f) } }   // soft light burst when a piece turns
    val prev = remember(ui.key, n) { arrayOf(ui.masks) }
    val tap by rememberUpdatedState(onTap)
    val comps = remember(ui.masks) { components(ui.masks, ui.width, ui.height) }
    val intro = remember(ui.key, n) { Animatable(if (animMs > 0) 0f else 1f) }
    val win = remember(ui.key, n) { Animatable(0f) }
    val palette = listOf(c.accent, c.gold, c.accent2, c.pop1, c.pop2)

    // Spark mode: 0 = asleep (dim, locked), 1 = powered. Power spreads outward from the source with a small delay per step.
    val lit = remember(ui.key, n) { List(n) { Animatable(if (ui.awake?.getOrNull(it) == false) 0f else 1f) } }
    val latest by rememberUpdatedState(ui)
    val scope = rememberCoroutineScope()
    // Classic rule marks: a looping clock for glints and flowing links, a "cannot turn" pulse per padlock, a twin pulse per pair.
    val denied = remember(ui.key, n) { List(n) { Animatable(0f) } }
    val linkPulse = remember(ui.key, n) { List(n) { Animatable(0f) } }
    val markClock: State<Float> = if (LocalAnimations.current && (ui.locked != null || ui.partner != null)) {
        rememberInfiniteTransition(label = "marks").animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "m")
    } else remember { mutableStateOf(0f) }
    val sparkT: State<Float> = if (ui.sparkSource >= 0 && LocalAnimations.current) {
        rememberInfiniteTransition(label = "spark").animateFloat(0f, 1f, infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "t")
    } else remember { mutableStateOf(0f) }
    LaunchedEffect(ui.awake) {
        val aw = ui.awake ?: return@LaunchedEffect
        val src = ui.sparkSource
        for (i in 0 until n) {
            val target = if (aw.getOrNull(i) == false) 0f else 1f
            if (lit[i].targetValue == target) continue
            val d = if (src >= 0) abs(i % ui.width - src % ui.width) + abs(i / ui.width - src / ui.width) else 0
            launch {
                if (animMs > 0) { delay(d * 50L); lit[i].animateTo(target, tween(380, easing = FastOutSlowInEasing)) } else lit[i].snapTo(target)
            }
        }
    }

    LaunchedEffect(ui.key, n) {
        if (animMs > 0) intro.animateTo(1f, tween(800, easing = LinearEasing)) else intro.snapTo(1f)
    }
    LaunchedEffect(ui.solved, ui.key) {
        if (ui.solved) {
            if (animMs > 0) { win.snapTo(0f); win.animateTo(1f, tween(1100, easing = LinearEasing)) } else win.snapTo(1f)
        } else win.snapTo(0f)
    }
    LaunchedEffect(ui.masks) {
        val old = prev[0]
        if (old !== ui.masks && old.size == ui.masks.size) {
            for (i in 0 until n) {
                if (old[i] == ui.masks[i]) continue
                val delta = when {
                    Tile.rotateCw(old[i]) == ui.masks[i] -> -90f
                    Tile.rotateCcw(old[i]) == ui.masks[i] -> 90f
                    else -> 0f
                }
                if (animMs > 0 && delta != 0f) launch { flash[i].snapTo(1f); flash[i].animateTo(0f, tween(380)) }
                // twins: a bead of light runs from the lower piece to its partner
                if (animMs > 0 && delta != 0f && (ui.partner?.getOrNull(i) ?: -1) > i) launch { linkPulse[i].snapTo(0f); linkPulse[i].animateTo(1f, tween(450, easing = LinearEasing)) }
                launch {
                    if (animMs > 0 && delta != 0f) {
                        // Continue from the current visual angle so rapid taps never jump or end tilted.
                        offsets[i].snapTo(offsets[i].value + delta)
                        offsets[i].animateTo(0f, tween(animMs, easing = FastOutSlowInEasing))
                    } else offsets[i].snapTo(0f)
                }
            }
        }
        prev[0] = ui.masks
    }

    Canvas(
        modifier
            .pointerInput(ui.width, ui.height, ui.solved) {
                detectTapGestures { p ->
                    val col = (p.x / (size.width / ui.width.toFloat())).toInt()
                    val row = (p.y / (size.height / ui.height.toFloat())).toInt()
                    if (col in 0 until ui.width && row in 0 until ui.height) {
                        val idx = row * ui.width + col
                        // A piece that has not been powered yet shakes instead of turning.
                        if (latest.awake?.getOrNull(idx) == false && latest.masks.getOrNull(idx) != 0) {
                            scope.launch { offsets[idx].snapTo(12f); offsets[idx].animateTo(0f, spring(dampingRatio = 0.2f, stiffness = 450f)) }
                        }
                        // A padlocked piece shakes too, so it is clear it is fixed.
                        if (latest.locked?.getOrNull(idx) == true) {
                            scope.launch { offsets[idx].snapTo(12f); offsets[idx].animateTo(0f, spring(dampingRatio = 0.2f, stiffness = 450f)) }
                            scope.launch { denied[idx].snapTo(1f); denied[idx].animateTo(0f, tween(550)) }
                        }
                        tap(idx)
                    }
                }
            }
            .semantics {
                contentDescription = "Puzzle board, ${ui.width} by ${ui.height}. ${ui.satisfied} of ${ui.occupied} pieces connected. Tap a piece to rotate it."
            }
    ) {
        val cell = size.width / ui.width
        val denom = (ui.width + ui.height - 2).coerceAtLeast(1).toFloat()
        val iv = intro.value
        val wv = win.value
        val fx = MarkFx(markClock.value, iv, wv, { denied[it].value }, { linkPulse[it].value })
        drawPlates(ui, cell, c, fx)
        // Three passes (glow, core, highlight) over the whole board: a neighbour's glow can
        // never paint over this tile's line, so paths join cleanly across invisible cell borders.
        for (pass in 0..2) {
            for (i in 0 until n) {
                if (ui.masks[i] == 0) continue
                val dist = ((i % ui.width) + (i / ui.width)) / denom
                val pop = (iv * 1.7f - dist * 0.7f).coerceIn(0f, 1f)
                val wave = if (ui.solved) (wv * 1.7f - dist * 0.7f).coerceIn(0f, 1f) else 0f
                drawPiece(pass, ui, comps, palette, i, cell, offsets[i].value, pop, wave, c, lit[i].value, sparkT.value)
            }
        }
        drawBadges(ui, cell, c, fx)
        // Rotation FX: a very light glow blooms over a piece as it turns and fades away.
        for (i in 0 until n) {
            val f = flash[i].value
            if (f <= 0.01f) continue
            val ctr = Offset((i % ui.width) * cell + cell / 2f, (i / ui.width) * cell + cell / 2f)
            val r = cell * (0.40f + 0.24f * (1f - f))
            drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.30f * f), c.accent.copy(alpha = 0.10f * f), Color.Transparent), ctr, r), r, ctr)
        }
    }
}

/**
 * Draws only the line art of one piece. Cells have no visible background or border; the grid
 * exists purely as invisible geometry for placement and touch. Geometry is never scaled, so
 * every line meets its neighbour exactly at the cell edge.
 */
internal fun DrawScope.drawPiece(
    pass: Int, ui: GameUiState, comps: IntArray, palette: List<Color>, i: Int, cell: Float,
    angle: Float, pop: Float, wave: Float, c: LoopColors, lit: Float = 1f, sparkT: Float = 0f
) {
    val m = ui.masks[i]
    if (m == 0 || pop <= 0f) return
    val w = ui.width
    val h = ui.height
    val cx = (i % w) * cell + cell / 2
    val cy = (i / w) * cell + cell / 2
    val pulse = kotlin.math.sin(PI.toFloat() * wave)
    val glowMul = (1f + pulse) * lit
    val stroke = cell * 0.12f
    val base = palette[comps[i].coerceAtLeast(0) % palette.size]
    val tint = lerp(lerp(base, c.good, wave), Color.White, pulse * 0.45f)
    val bad = c.bad.copy(alpha = 0.9f)
    // Spark mode: a piece that is not powered yet is drawn dim and never shows the red "unmatched" warning.
    val sleepy = 1f - lit
    val dim = c.textDim.copy(alpha = 0.5f)
    fun shade(col: Color) = if (sleepy <= 0f) col else lerp(col, dim, sleepy)
    val allOk = sleepy > 0.5f || Dir.ALL.all { !Tile.has(m, it) || Rules.isMatched(ui.masks, w, h, i, it) }
    fun Color.fade(f: Float) = copy(alpha = (alpha * f * pop).coerceIn(0f, 1f))
    fun mid(d: Int, f: Float = 1f) = Offset(cx + Dir.dx(d) * cell / 2 * f, cy + Dir.dy(d) * cell / 2 * f)

    rotate(angle, Offset(cx, cy)) {
        val kind = Tile.kind(m)
        if (kind == TileKind.CORNER) {
            val sides = Dir.ALL.filter { Tile.has(m, it) }
            val ok = sleepy > 0.5f || sides.all { Rules.isMatched(ui.masks, w, h, i, it) }
            val path = Path().apply {
                moveTo(mid(sides[0]).x, mid(sides[0]).y)
                quadraticBezierTo(cx, cy, mid(sides[1]).x, mid(sides[1]).y)
            }
            val col = shade(if (ok) tint else bad)
            when (pass) {
                0 -> if (ok) {
                    drawPath(path, col.fade(0.10f * glowMul), style = Stroke(stroke * 3.2f, cap = StrokeCap.Round))
                    drawPath(path, col.fade(0.20f * glowMul), style = Stroke(stroke * 2f, cap = StrokeCap.Round))
                }
                1 -> drawPath(path, col.fade(1f), style = Stroke(stroke, cap = StrokeCap.Round))
                else -> if (ok) drawPath(path, Color.White.fade(0.28f * lit), style = Stroke(stroke * 0.32f, cap = StrokeCap.Round))
            }
        } else {
            for (d in Dir.ALL) {
                if (!Tile.has(m, d)) continue
                val ok = sleepy > 0.5f || Rules.isMatched(ui.masks, w, h, i, d)
                val end = mid(d, if (ok) 1f else 0.8f)
                val col = shade(if (ok) tint else bad)
                when (pass) {
                    0 -> if (ok) {
                        drawLine(col.fade(0.10f * glowMul), Offset(cx, cy), end, stroke * 3.2f, StrokeCap.Round)
                        drawLine(col.fade(0.20f * glowMul), Offset(cx, cy), end, stroke * 2f, StrokeCap.Round)
                    }
                    1 -> drawLine(col.fade(1f), Offset(cx, cy), end, stroke, StrokeCap.Round)
                    else -> if (ok) drawLine(Color.White.fade(0.28f * lit), Offset(cx, cy), end, stroke * 0.32f, StrokeCap.Round)
                }
            }
            val col = shade(if (allOk) tint else bad)
            when (kind) {
                TileKind.END -> when (pass) {
                    0 -> drawCircle(col.fade(0.25f * lit), stroke * 1.9f, Offset(cx, cy))
                    1 -> drawCircle(col.fade(1f), stroke * 1.2f, Offset(cx, cy))
                    else -> drawCircle(Color.White.fade(0.35f * lit), stroke * 0.45f, Offset(cx - stroke * 0.25f, cy - stroke * 0.25f))
                }
                TileKind.TEE, TileKind.CROSS -> when (pass) {
                    1 -> drawCircle(col.fade(1f), stroke * 0.9f, Offset(cx, cy))
                    2 -> drawCircle(Color.White.fade(0.35f * lit), stroke * 0.35f, Offset(cx, cy))
                    else -> Unit
                }
                else -> Unit
            }
        }
    }

    // Spark mode: a pulsing golden ring marks the power source.
    if (pass == 2 && i == ui.sparkSource) {
        val a = pop.coerceIn(0f, 1f)
        val r = stroke * (2.1f + 0.4f * sparkT)
        drawCircle(c.gold.copy(alpha = 0.16f * a), r, Offset(cx, cy))
        drawCircle(c.gold.copy(alpha = (0.95f - 0.45f * sparkT) * a), r, Offset(cx, cy), style = Stroke(stroke * 0.38f))
    }
}

@Composable
private fun HintRing(w: Int, h: Int, tile: Int, modifier: Modifier) {
    val c = LocalLoop.current
    val t = rememberInfiniteTransition(label = "hint")
    val alpha by t.animateFloat(0.35f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "alpha")
    Canvas(modifier) {
        val cell = size.width / w
        val x = (tile % w) * cell
        val y = (tile / w) * cell
        drawRoundRect(
            c.gold.copy(alpha = alpha), Offset(x + cell * 0.03f, y + cell * 0.03f),
            Size(cell * 0.94f, cell * 0.94f), CornerRadius(cell * 0.22f), style = Stroke(cell * 0.05f)
        )
    }
}

@Composable
private fun CompleteOverlay(ui: GameUiState, animated: Boolean, onNext: () -> Unit, onReplay: () -> Unit, onBack: () -> Unit) {
    val c = LocalLoop.current
    val classic = ui.mode == GameMode.CLASSIC
    val appear = remember { Animatable(if (animated) 0f else 1f) }
    val starScales = remember { List(3) { Animatable(if (animated) 0f else 1f) } }
    val sfx = LocalSfx.current
    LaunchedEffect(Unit) {
        if (animated) {
            launch { appear.animateTo(1f, tween(450, easing = FastOutSlowInEasing)) }
            val pops = if (classic) ui.stars else 1
            for (i in 0 until pops) {
                delay(280L)
                sfx?.playStar(i)
                launch { starScales[i].animateTo(1f, spring(dampingRatio = 0.38f, stiffness = 260f)) }
            }
        }
    }
    Box(
        Modifier.fillMaxSize().drawBehind { drawRect(Color.Black.copy(alpha = 0.72f * appear.value)) }
            .clickable(enabled = false) {},
        contentAlignment = Alignment.Center
    ) {
        if (animated) Confetti(Modifier.fillMaxSize())
        Column(
            Modifier.padding(28.dp).fillMaxWidth().graphicsLayer {
                alpha = appear.value
                translationY = (1f - appear.value) * 48f
            },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (classic) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.semantics { contentDescription = "${ui.stars} of 3 stars" }
                ) {
                    for (i in 0 until 3) {
                        val earned = i < ui.stars
                        Icon(
                            Icons.Rounded.Star, null, tint = if (earned) c.gold else c.border,
                            modifier = Modifier.size(56.dp).graphicsLayer {
                                if (earned) {
                                    val sc = starScales[i].value
                                    scaleX = sc; scaleY = sc
                                    rotationZ = (1f - sc) * -50f
                                }
                            }
                        )
                    }
                }
            } else {
                Icon(
                    Icons.Rounded.EmojiEvents, null, tint = c.gold,
                    modifier = Modifier.size(76.dp).graphicsLayer {
                        val sc = starScales[0].value
                        scaleX = sc; scaleY = sc
                        rotationZ = (1f - sc) * -50f
                    }
                )
            }
            Spacer(Modifier.height(14.dp))
            Text(
                when {
                    ui.isDaily -> "Daily Complete!"
                    ui.mode == GameMode.ZEN -> "Puzzle Solved"
                    ui.mode == GameMode.CHALLENGE -> "Challenge Cleared!"
                    ui.mode == GameMode.SPARK -> "Grid Powered!"
                    else -> "Level Complete!"
                },
                color = c.text, fontSize = 30.sp, fontWeight = FontWeight.Bold
            )
            Text(
                when {
                    ui.mode == GameMode.ZEN -> "Nicely done"
                    ui.mode == GameMode.SPARK -> "Every piece is lit"
                    ui.mode == GameMode.CHALLENGE -> "${ui.moveLimit - ui.moves} moves to spare"
                    ui.newBest -> "New best!"
                    else -> "Great job!"
                },
                color = c.textDim, fontSize = 16.sp
            )
            Spacer(Modifier.height(20.dp))
            LoopCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Stat("Moves", "${ui.moves}")
                    when {
                        ui.mode == GameMode.ZEN || ui.mode == GameMode.SPARK -> Stat("Par", "${ui.par}")
                        ui.mode == GameMode.CHALLENGE -> { Stat("Limit", "${ui.moveLimit}"); Stat("Par", "${ui.par}") }
                        else -> {
                            Stat(if (ui.isDaily) "Streak" else "Best", if (ui.isDaily) "${ui.streak} d" else "${ui.bestMoves ?: ui.moves}")
                            Stat("Par", "${ui.par}")
                        }
                    }
                }
            }
            Spacer(Modifier.height(22.dp))
            if (ui.isDaily) PrimaryButton("Back to Daily", onBack, Modifier.fillMaxWidth())
            else PrimaryButton(
                when (ui.mode) { GameMode.ZEN -> "New Puzzle"; GameMode.CHALLENGE -> "Next Challenge"; GameMode.SPARK -> "Next Circuit"; else -> "Next Level" },
                onNext, Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            OutlineButton("Replay", onReplay, Modifier.fillMaxWidth(), icon = Icons.Rounded.Refresh)
        }
    }
}

/** Challenge failure: the move limit was reached before the puzzle was solved. */
@Composable
private fun FailOverlay(ui: GameUiState, onRetry: () -> Unit, onBack: () -> Unit) {
    val c = LocalLoop.current
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.75f)).clickable(enabled = false) {},
        contentAlignment = Alignment.Center
    ) {
        Column(Modifier.padding(28.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Rounded.Refresh, null, tint = c.bad, modifier = Modifier.size(64.dp))
            Spacer(Modifier.height(12.dp))
            Text("Out of moves", color = c.text, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("The limit for this puzzle is ${ui.moveLimit} moves. Plan your turns and try again.", color = c.textDim, fontSize = 15.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(24.dp))
            PrimaryButton("Try again", onRetry, Modifier.fillMaxWidth(), icon = Icons.Rounded.Refresh)
            Spacer(Modifier.height(10.dp))
            OutlineButton("Back", onBack, Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun RushResultOverlay(vm: GameViewModel, onAgain: () -> Unit, onExit: () -> Unit) {
    val c = LocalLoop.current
    val r by vm.rush.collectAsStateWithLifecycle()
    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.78f)).clickable(enabled = false) {},
        contentAlignment = Alignment.Center
    ) {
        Column(Modifier.padding(28.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Rounded.Timer, null, tint = c.gold, modifier = Modifier.size(64.dp))
            Spacer(Modifier.height(8.dp))
            Text("TIME'S UP", color = c.text, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
            Spacer(Modifier.height(16.dp))
            Text("${r.score}", color = c.gold, fontSize = 72.sp, fontWeight = FontWeight.ExtraBold)
            Text(if (r.score == 1) "puzzle solved" else "puzzles solved", color = c.textDim, fontSize = 15.sp)
            Spacer(Modifier.height(6.dp))
            Text(if (r.newBest) "New best!" else "Best: ${r.best}", color = if (r.newBest) c.good else c.textDim, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(26.dp))
            PrimaryButton("Play again", onAgain, Modifier.fillMaxWidth(), icon = Icons.Rounded.Refresh)
            Spacer(Modifier.height(10.dp))
            OutlineButton("Back", onExit, Modifier.fillMaxWidth())
        }
    }
}

/** Timer HUD for Rush. It collects the clock itself so only this small card redraws every 100 ms. */
@Composable
private fun RushHud(vm: GameViewModel, modifier: Modifier) {
    val c = LocalLoop.current
    val r by vm.rush.collectAsStateWithLifecycle()
    val sec = ((r.timeLeftMs + 999) / 1000).toInt()
    val low = r.timeLeftMs < 10_000
    val fraction = (r.timeLeftMs.toFloat() / ModeRules.RUSH_MAX_MS).coerceIn(0f, 1f)
    LoopCard(modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(96.dp)) {
                Column(Modifier.semantics(mergeDescendants = true) { contentDescription = "Time left $sec seconds" }) {
                    Text("TIME", color = c.textDim, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Text("${sec / 60}:${(sec % 60).toString().padStart(2, '0')}", color = if (low) c.bad else c.text, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                }
                BonusFlash(r.bonusId, r.bonusMs, Modifier.align(Alignment.TopEnd))
            }
            Box(Modifier.width(1.dp).height(44.dp).background(c.border))
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text("TIME BANK", color = c.textDim, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp)).background(c.bgBottom)) {
                    Box(
                        Modifier.fillMaxWidth(fraction).fillMaxHeight().clip(RoundedCornerShape(6.dp))
                            .background(Brush.horizontalGradient(listOf(if (low) c.bad else c.accent, if (low) c.gold else c.accent2)))
                    )
                }
            }
            Box(Modifier.width(1.dp).height(44.dp).background(c.border))
            Column(Modifier.padding(start = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("SOLVED", color = c.textDim, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Text("${r.score}", color = c.gold, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
private fun BonusFlash(id: Int, ms: Long, modifier: Modifier) {
    val c = LocalLoop.current
    val a = remember(id) { Animatable(0f) }
    LaunchedEffect(id) { if (id > 0) a.animateTo(1f, tween(900)) }
    if (id > 0 && a.value < 1f) {
        Text(
            "+${ms / 1000}s", color = c.good, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp,
            modifier = modifier.graphicsLayer { alpha = 1f - a.value; translationY = -40f * a.value }
        )
    }
}

@Composable
private fun Stat(label: String, value: String) {
    val c = LocalLoop.current
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = c.textDim, fontSize = 12.sp)
        Text(value, color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    }
}

private class Particle(val x: Float, val phase: Float, val speed: Float, val color: Int, val rot: Float)

@Composable
internal fun Confetti(modifier: Modifier) {
    val c = LocalLoop.current
    val t by rememberInfiniteTransition(label = "confetti").animateFloat(0f, 1f, infiniteRepeatable(tween(4200, easing = LinearEasing)), label = "t")
    val parts = remember { val r = Random(7); List(46) { Particle(r.nextFloat(), r.nextFloat(), 0.6f + r.nextFloat() * 0.6f, r.nextInt(5), r.nextFloat() * 360f) } }
    val colors = listOf(c.gold, c.accent, c.accent2, c.good, c.bad)
    Canvas(modifier) {
        for (p in parts) {
            val prog = (t * p.speed + p.phase) % 1f
            val px = p.x * size.width + sin(prog * 12.5f + p.phase * 6f) * 14f
            val py = prog * size.height
            rotate(p.rot + prog * 360f, Offset(px, py)) {
                drawRect(colors[p.color], Offset(px, py), Size(8f, 14f))
            }
        }
    }
}

@Composable
private fun OutOfHintsDialog(ads: AdManager, vm: GameViewModel, onWatch: () -> Unit, onDismiss: () -> Unit) {
    val c = LocalLoop.current
    val ready by ads.ready.collectAsStateWithLifecycle()
    val adState by vm.adState.collectAsStateWithLifecycle()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(1000); now = System.currentTimeMillis() } }
    val status = AdPolicy.rewardedStatus(adState, vm.today(), now)
    LaunchedEffect(status is RewardedStatus.Available) { if (status is RewardedStatus.Available) ads.load() }

    Dialog(onDismissRequest = onDismiss) {
        LoopCard(Modifier.fillMaxWidth().popIn()) {
            Text("Out of hints", color = c.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(8.dp))
            Text(
                "Earn hints by completing levels (one per 3 levels, one for a 3-star result, two for a 7-day daily streak) " +
                    "and by unlocking awards. Using a hint caps that level at 2 stars.",
                color = c.textDim, fontSize = 14.sp, lineHeight = 20.sp
            )
            Spacer(Modifier.height(10.dp))
            val (label, note, enabled) = when (status) {
                is RewardedStatus.Available -> Triple(
                    if (ready) "Watch ad  ·  +1 hint" else "Loading ad…",
                    "${status.leftToday} hint ad${if (status.leftToday == 1) "" else "s"} left today",
                    ready
                )
                is RewardedStatus.Cooldown -> {
                    val sec = ((status.msLeft + 999) / 1000).toInt()
                    Triple("Next ad in ${sec / 60}:${(sec % 60).toString().padStart(2, '0')}", "Please wait a little between ads", false)
                }
                RewardedStatus.DailyLimit -> Triple("Daily limit reached", "You've used today's hint ads. They come back tomorrow.", false)
            }
            Text(note, color = if (status is RewardedStatus.Available) c.accent else c.bad, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(16.dp))
            PrimaryButton(label, onWatch, Modifier.fillMaxWidth(), enabled = enabled)
            Spacer(Modifier.height(10.dp))
            OutlineButton("Not now", onDismiss, Modifier.fillMaxWidth())
        }
    }
}
